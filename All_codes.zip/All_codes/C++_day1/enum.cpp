//#include<stdio.h>
//enum week{Mon, Tue, Wed, Thur, Fri, Sat, Sun};
//int main()
//{
//    enum week day;
//    day = Wed;
//    printf("%d",day);
//    return 0;
//}

#include <stdio.h>
#include <string.h>

#define Zoom 1
#define Crop 2
#define Rotate 3
#define Enhabce 4

 
//enum week { Mon = 15, Tue = 16, Wed = 150, Thur = 19, Fri = 25, Sat = 60, Sun = 99 };
 enum photoOps { zoom = 1, crop, rotate, enhance};
int main() {
    enum photoOps pOps; //string literal
//    char temp[8];
	int temp;
//    int pOps;
//    int dayNumber;
    char *pOp[] = {"","zoom", "crop", "rotate", "enhance"};
    printf("Enter: \n");
    printf("1- Zoom \t 2- Crop \n 3- Rotate \t 4- Enhance \n");
    printf("Enter your choice: ");
    scanf("%d", &temp);
    printf("%s", pOp[temp]);
    strcpy(pOps, pOp[temp]);
    printf("%s", pOps);
//	pOps = *pOp[temp];
	
//    printf("\n %d \n",pOps);
 
//    printf("Enter a number between 0 and 6: ");
//    scanf("%d", &dayNumber);
// 
//    if (dayNumber >= 0 && dayNumber <= 6) {
//        printf("The day is: %s\n", days[dayNumber]);
//    } else {
//        printf("Invalid input. Please enter a number between 0 and 6.\n");
//    }
 
    return 0;
}
