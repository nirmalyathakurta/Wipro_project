#include<stdio.h>
int x;
void autos(){
	auto int b=5;
	printf("%d auto\n",b);
}
void registers(){
	register char b='A';
	printf("%d register\n",b);
}

void externs(){
	extern int x;
	printf("%d externs\n",x);
	x=6;
		printf("%d externs\n",x);
}
void statics(){
	 int i=0;
for(i=0;i<10;i++){
	static int g=20;
	int h=20;
	g++;
	h++;
	printf("g=%d\n",g);
		printf("h=%d\n",h);
}
}
void main(){
	autos();
	externs();
	registers();
	statics();
}
