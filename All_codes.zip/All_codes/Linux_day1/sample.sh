#!/bin/bash
 
PS3="Select Option "
 
select ch in Apple Orange Peach Quit
do
    case $ch in
        "Apple")
            echo "$ch - that's an Apple";;
        "Orange")
           echo "$ch - Orange?";;
        "Peach")
           echo "$ch - Peach";;
        "Quit")
           echo "over and out"
           break;;
        *)
           echo "Ooops";;
    esac
done
