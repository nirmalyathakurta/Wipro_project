#!/bin/bash

touch ex.txt


echo "to terminate loop use 'stop' "

while true; do
	echo "enter the value : $count "
	read input
	if [ "$input" = "stop" ]; then
		echo "stopping the loop."
		break
	fi	
	echo "you entered  $count : $input"
	echo "$input" >>ex.txt
	
done
