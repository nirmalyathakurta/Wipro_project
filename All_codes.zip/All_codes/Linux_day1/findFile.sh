#!/bin/bash

PS3="Select Option: "

select ch in "List Files" "Find Word in Files" "List Files Sorted by Size" "Quit" 
	do
		case $ch in
        		"List Files")
            			echo "Files in the current directory: "
            			ls;;
        		"Find Word in Files")
            			echo "Enter the word to search: "
            			read search_word
            			echo "Searching for '$search_word' in files... "
            			grep -rn "$search_word" .;;
	        	"List Files Sorted by Size")
            			echo "Files sorted by size: "
            			ls -l | awk '{print $5, $9}' | sort -n;;
	        	"Quit")
	            		echo "Exiting..."
            			break;;
			*)
            			echo "Invalid option";;
       		esac
	done

