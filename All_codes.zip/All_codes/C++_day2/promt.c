#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#define MAX_DATA_SIZE 100

void connecting_to_ip(char *ip) {
    printf("Connecting to IP address: %s\n", ip);
}

void get_data(char *data) {
    printf("Enter the data: ");
    scanf("%s", data); 
    printf("Reading data: %s\n", data);
}

void check_connection(char *data) {
    printf("Checking connection\n");
}

void reset_connection(char *data) {
    printf("Resetting connection\n");
}

void send_data(char *data) {
    printf("Sending data\n");
}

void disconnect(char *data) {
    printf("Disconnecting\n");
}

int main() {
    char command[25];
    char ip[25];
    char data[MAX_DATA_SIZE];

    printf("Enter command: ");
    scanf("%s", command);

    if (strcmp(command, "connecting_to_ip") == 0) {
        printf("Enter IP address: ");
        scanf("%s", ip);
        connecting_to_ip(ip);
    } 
    else if (strcmp(command, "get_data") == 0) {
        get_data(data);
    } 
    else if (strcmp(command, "check_connection") == 0) {
        check_connection(data);
    } 
    else if (strcmp(command, "reset_connection") == 0) {
        reset_connection(data);
    } 
    else if (strcmp(command, "send_data") == 0) {
        send_data(data);
    } 
    else if (strcmp(command, "disconnect") == 0) {
        disconnect(data);
    } 
    else {
        printf("Invalid command\n");
    }

    return 0;
}
