#include <stdio.h>
#include <math.h>
#include <time.h>
#include <stdlib.h>
int main()
{
    float a;
    clock_t time_req;
    
    // arr[10] - time taken to multiply all element
    int arr[10] = {2,4,6,8,10,12,14,16,18,20};
    float multiply = 1;
    time_req = clock();
    for(int i = 0; i<10; i++)
    {
        multiply *= arr[i];
    }
    time_req = clock() - time_req;
    printf("Processor time taken for multiplication : %f seconds\n", (float)time_req/CLOCKS_PER_SEC);

    // Without using pow function
    time_req = clock();
    for (int i = 0; i < 200000; i++) {
        // a = log(i * i * i * i);
        a = log (i/i);
    }
    time_req = clock() - time_req;
    printf("Processor time taken for Division: %f "
           "seconds\n",
           (float)time_req / CLOCKS_PER_SEC);
    // Using pow function
    time_req = clock();
    for (int i = 0; i < 200000; i++) {
        a = log(pow(i, 4));
    }
    time_req = clock() - time_req;
    printf("Processor time taken in pow function: %f " "seconds\n",
           (float)time_req / CLOCKS_PER_SEC);
    return 0;
}
