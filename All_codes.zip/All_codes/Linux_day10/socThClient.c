#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <arpa/inet.h>
#include <string.h>

#define PORT 8080

struct device {
    int busid;
    int scale;
    int devid;
    float rawdata;
};

int main() {
    int client_socket = socket(AF_INET, SOCK_STREAM, 0);
    if (client_socket == -1) {
        perror("socket");
        exit(1);
    }

    struct sockaddr_in server_address;
    server_address.sin_family = AF_INET;
    server_address.sin_port = htons(PORT);
    server_address.sin_addr.s_addr = INADDR_ANY;

    if (connect(client_socket, (struct sockaddr*)&server_address, sizeof(server_address)) == -1) {
        perror("connect");
        exit(1);
    }

    while(1) {
        int devid = rand() % 10;
        int busid = rand() % 10;

        printf("[Client] Sending devid: %d & busid: %d\n", devid, busid);
        send(client_socket, &devid, sizeof(int), 0);
        send(client_socket, &busid, sizeof(int), 0);

        struct device received_data;
        recv(client_socket, &received_data, sizeof(struct device), 0);
        
        printf("[Client] Received data:\n");
        printf("Bus ID: %d\n", received_data.busid);
        printf("Dev ID: %d\n", received_data.devid);
        printf("Scaled Data: %d\n", received_data.scale);
        printf("Raw Data: %f\n", received_data.rawdata);
        usleep(500000);
    }

    close(client_socket);
    return 0;
}