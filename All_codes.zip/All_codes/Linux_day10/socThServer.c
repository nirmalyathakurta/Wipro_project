#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <pthread.h>
#include <sys/ipc.h>
#include <semaphore.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <arpa/inet.h>
#include <sys/shm.h>
#include <sys/types.h>
#include <string.h>

#define PORT 8080

struct device {
    int busid;
    int scale;
    int devid;
    float rawdata;
};

struct device *shm_ptr;
sem_t sem;
pthread_t generate_thread, client_threads[5];
int num_connections = 0;

void* generate_data(void* arg) {
    while (1) {
        sem_wait(&sem);
        
        shm_ptr->busid = rand() % 10;
        shm_ptr->scale = rand() % 100;
        shm_ptr->devid = rand() % 5;
        shm_ptr->rawdata = (float)rand() / (float)(RAND_MAX / 1000.0);
    
        sem_post(&sem);
        usleep(500000);
    }
    return NULL;
}

void* handle_client(void* arg) {
    int client_socket = *((int*)arg);

    while (1) {
        int devid, busid;
        if (recv(client_socket, &devid, sizeof(int), 0) <= 0) {
            close(client_socket);
            return NULL;
        }
        
        if (recv(client_socket, &busid, sizeof(int), 0) <= 0) {
            close(client_socket);
            return NULL;
        }

        printf("\n[Server] Receiving devid: %d & busid: %d\n",devid, busid);
        sem_wait(&sem);

        struct device data_to_send;
        data_to_send.busid = rand() % 10; 
        data_to_send.scale = rand() % 100; 
        data_to_send.devid = rand() % 5; 
        data_to_send.rawdata = (float)rand() / (float)(RAND_MAX / 1000.0);
        
        sem_post(&sem);

        send(client_socket, &data_to_send, sizeof(struct device), 0);
        usleep(500000);
    }
    return NULL;
}

void* accept_connections(void* arg) {
    int server_socket = *((int*)arg);
    struct sockaddr_in client_address;
    int addrlen = sizeof(client_address);

    while (1) {
        int client_socket = accept(server_socket, (struct sockaddr *)&client_address, (socklen_t*)&addrlen);
        if (client_socket == -1) {
            perror("accept");
            continue;
        }

        printf("[Server] Accepted connection from %s:%d\n", inet_ntoa(client_address.sin_addr), ntohs(client_address.sin_port));

        pthread_t client_thread;
        pthread_create(&client_thread, NULL, handle_client, &client_socket);

        num_connections++;
        if (num_connections / 5 == 0) {
            pthread_create(&client_threads[0], NULL, accept_connections, &server_socket);
            // int additional_threads = num_connections / 5 - 1;
            // for (int i = 0; i < additional_threads; ++i) {
            //     pthread_create(&client_threads[i], NULL, accept_connections, &server_socket);
            // }
        } 
        // else if (num_connections / 5 == 1) {
        //     pthread_create(&client_threads[num_connections / 5], NULL, accept_connections, &server_socket);
        // }
    }
    return NULL;
}

int main() {
    key_t key = 1234;
    int shmid = shmget(key, sizeof(struct device), IPC_CREAT | 0666);
    if (shmid == -1) {
        perror("shmget");
        exit(1);
    }

    shm_ptr = (struct device*)shmat(shmid, NULL, 0);
    if (shm_ptr == (struct device*)(-1)) {
        perror("shmat");
        exit(1);
    }

    if (sem_init(&sem, 0, 1) != 0) {
        perror("sem_init");
        exit(1);
    }

    srand(time(NULL));

    pthread_create(&generate_thread, NULL, generate_data, NULL);

    int server_socket = socket(AF_INET, SOCK_STREAM, 0);
    if (server_socket == -1) {
        perror("socket");
        exit(1);
    }

    struct sockaddr_in server_address;
    server_address.sin_family = AF_INET;
    server_address.sin_addr.s_addr = INADDR_ANY;
    server_address.sin_port = htons(PORT);

    if (bind(server_socket, (struct sockaddr *)&server_address, sizeof(server_address)) == -1) {
        perror("bind");
        exit(1);
    }

    if (listen(server_socket, 5) == -1) {
        perror("listen");
        exit(1);
    }

    printf("[Server] Waiting for client connections...\n");

    pthread_create(&client_threads[0], NULL, accept_connections, &server_socket);

    pthread_join(generate_thread, NULL);

    shmdt(shm_ptr);

    shmctl(shmid, IPC_RMID, NULL);

    sem_destroy(&sem);

    return 0;
}