#include <bits/stdc++.h>
using namespace std;

struct node {
  int age;
  char* name;
  int key;
  struct node *left;
  struct node *right;
};
//Addnode
struct node *newnode(int age, char *name) {
    struct node* nn = new node;
    nn->age=age;
    nn->name=name;
    nn->left=NULL;
    nn->right=NULL;
    return (nn);
}
//Print Tree – InorderTraversal
void printtree_IO(struct node *temp) {
    if(temp != NULL) {
        printtree_IO(temp->left);
        cout<< "left "<<temp->age<<endl;
        printtree_IO(temp->right);
        cout<< "Right "<<temp->age<<endl;
    }

}
 
//Print Tree – PostorderTraversal
void printtree_PO(struct node *temp) {
    if(temp != NULL) {
        printtree_PO(temp->left);
        cout<< "left "<<temp->age<<endl;
        printtree_PO(temp->right);
        cout<< "right "<<temp->age<<endl;
        cout<< "Post Order Traversal"<<endl;
    }
}

node* deletion(struct node* root, int key) {
    
    if (root == NULL) return NULL;
        if(root->left==NULL && root->right==NULL) {
            if(root->age==key) return NULL;
            else return root;
        }
 
    queue<struct node*> q;
    q.push(root);
 
    struct node* temp;
    struct node* key_node = NULL;
 
    // Do level order traversal to find deepest
    // node(temp) and node to be deleted (key_node)
    while (!q.empty()) {
        temp = q.front();
        q.pop();
 
        if (temp->age == key)
            key_node = temp;
 
        if (temp->left)
            q.push(temp->left);
 
        if (temp->right)
            q.push(temp->right);
    }
 
    if (key_node != NULL) {
        int x = temp->age;
        key_node->age = x;
       // deletDeepest(root, temp);
    }
    return root;
}

int height(node* root) {
    if(root == nullptr) return NULL;
    else {
        int left_height = height(root->left);
        int right_height = height(root->right);
    
        return max(left_height,right_height)+1;
    }
}

// print each nodes present at each level
// start with the root node of tree
// use queue to store nodes  at each level
// insert nodes in queue
// take variable for traking level
// loop while the queue is not empty
// follow this until all level of tree tranvered
 
void printNodesatEachLevel(node* root) {
    if(root == nullptr) {
        cout<<"tree is empty."<<endl;
 
    }
 
    queue<node*> q;
    q.push(root);
    int level =0;
 
    while(!q.empty()) {
        int nodecount = q.size();
        cout<<"level"<<level<<": "<<nodecount<<" nodes"<<endl;
 
        while(nodecount>0) {
            node* node = q.front();
            q.pop();
 
            if(node->left != nullptr) {
                q.push(node->left); 
            }
 
            if(node->right != nullptr) {
                q.push(node->right);
            }
            
            nodecount--;
        }
        
        level++;
    }
}

int main() {
    
    struct node *root=newnode(20,"tester");
    root->left=newnode(18,"OOPS");
    root->right=newnode(20,"PushPopStack");
    root->left->left=newnode(19,"OOPS");
    root->right->right=newnode(22,"PushPopStack");
    cout<< "Inorder Read tree"<<"\n";
    printtree_IO(root);
    printtree_PO(root);
    cout<<endl;
 
    printNodesatEachLevel(root);
 
    cout<<endl;
    cout<<"height of tree:  "<<height(root)<<endl;
 
    int key = 18;
    root=deletion(root,key);
 
    cout<<"\nafter deletion"<<endl;
    printtree_IO(root);
    cout<<endl;
    printtree_PO(root);

    return 0;

}