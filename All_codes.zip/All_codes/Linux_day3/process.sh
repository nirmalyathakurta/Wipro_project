#!/bin/bash

# Function to find the PID of a process
find_pid() {
    pid=$(pgrep "$1")
    echo "PID of $1 is: $pid"
}

# Function to kill a process by PID
kill_process() {
    pid="$1"
    kill -9 "$pid"
    echo "Process with PID $pid killed"
}

# Function to search for a given text in files
search_text_in_files() {
    text="$1"
    files=$(grep -rl "$text" .)
    echo "Files containing '$text':"
    echo "$files"
}

# Main loop
while true; do
    echo "Select an option:"
    echo "1. Find PID of a process"
    echo "2. Kill a process"
    echo "3. Search for text in files"
    echo "4. Exit"
    read -r option

    case $option in
        1)
            echo "Enter process name:"
            read -r process_name
            find_pid "$process_name"
            ;;
        2)
            echo "Enter PID of the process to kill:"
            read -r pid_to_kill
            kill_process "$pid_to_kill"
            ;;
        3)
            echo "Enter text to search for:"
            read -r search_text
            search_text_in_files "$search_text"
            ;;
        4)
            echo "Exiting..."
            break
            ;;
        *)
            echo "Invalid option"
            ;;
    esac
done
