#!/bin/bash

# Function to retrieve memory utilization information
get_memory_utilization() {
    echo "Memory Utilization Information:"
    free -h
}

# Function to retrieve CPU utilization information
get_cpu_utilization() {
    echo "CPU Utilization Information:"
    top -bn1 | grep "Cpu(s)"
}

# Function to retrieve disk utilization information
get_disk_utilization() {
    echo "Disk Utilization Information:"
    df -h
}

# Main script
echo "System Utilization Information:"

# Retrieve memory utilization information
get_memory_utilization

# Retrieve CPU utilization information
get_cpu_utilization

# Retrieve disk utilization information
get_disk_utilization
