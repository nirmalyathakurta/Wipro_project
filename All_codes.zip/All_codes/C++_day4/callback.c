#include<stdio.h>

int x=2,y=8;
void add() {
  printf("%d\n",x+y);
}
int main(void) {
  void(*ptr)()= &add;
  CallBack(ptr);
  return 0;
}
 
//Callback function :
void CallBack(void(*ptr)()) {
  (*ptr)(); /* This is a callback to add function*/
}