#include <bits/stdc++.h>
using namespace std;

template <typename T> T diff(T i, T j) { return i=j; }
int main() {
    cout<<diff<int>(10,11)<<endl;
    cout<<diff<char>('y','z')<<endl;
}