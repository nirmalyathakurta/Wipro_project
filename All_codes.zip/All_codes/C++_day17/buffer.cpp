#include <fstream>
#include<iostream>
#include <string>
using namespace std;

int main() {
    fstream file;
    file.open("fname.txt",ios::out);
    string strvar;
    streambuf* strbufout = cout.rdbuf();
    streambuf* strbufin = cin.rdbuf();
 
    streambuf*strmfile= file.rdbuf();
    cout.rdbuf(strmfile);
    cout  << "File data written!" << endl;
    cout.rdbuf(strbufout);
    cout<< "Written to screen !" << endl;
    file.close();
    return 0;
}