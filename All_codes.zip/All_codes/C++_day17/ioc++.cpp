#include <bits/stdc++.h>
using namespace std;
int main() {
    //Output to a file code
    ofstream ofs;
    string inpt;
    ofs.open("test.txt"); //Default open in output mode.
    while(ofs){
        getline(cin,inpt);
        if(inpt== "0")  break;
        ofs<<inpt<< "\n";
    }
    ofs.close();
    //Input from file(Read)
    ifstream inptf;
    inptf.open("test.txt");
    while(getline(inptf,inpt)) {
        cout<< inpt<< "\n";
    }
    
    inptf.close();
    return 0;
}