#include <bits/stdc++.h>
using namespace std;

class Employee {
public:
    int empid;
    string empname;
    string designation;
    bool isManager;
    Employee* next;

    Employee(int empid, string empname, string designation, bool isManager, Employee* next = nullptr)
        : empid(empid), empname(empname), designation(designation), isManager(isManager), next(next) {}

    virtual void displayDetails() {
        cout << "Employee id: " << empid << endl;
        cout << "Employee Name: " << empname << endl;
        cout << "Employee Designation: " << designation << endl;
    }

    virtual void promote(string Post) {}

    virtual void Demote(string Post) {}

    virtual void displayDetails(bool isManager) {}
};

class Manager : public Employee {
public:
    Manager(int empid, string empname, string designation, bool isManager, Employee* next = nullptr)
        : Employee(empid, empname, designation, isManager, next) {}

    void displayDetails() {
        Employee::displayDetails();
    }

    void displayDetails(bool isManager) {
        cout << "Manager Details:" << endl;
        Employee::displayDetails();
    }

    void promote(string Post) {
        cout << "Promoted to: " << Post << endl;
        designation = Post;
    }

    void Demote(string Post) {
        cout << "Demoted to: " << Post << endl;
        designation = Post;
    }
};

class EmployeeList {
private:
    Employee* head;

public:
    EmployeeList() : head(nullptr) {}

    void addEmployee(Employee* newEmployee) {
        stringstream ss;
        streambuf* oldCout = cout.rdbuf();
        cout.rdbuf(ss.rdbuf());
        newEmployee->displayDetails();
        cout.rdbuf(oldCout);
        ofstream file("fname.txt", ios::app); 
        if (file.is_open()) {
            file << ss.str() << endl << endl;
            file.close();
        } else {
            cout << "Unable to open file 'fname.txt' for storing data." << endl;
            return;
        }

        
        if (head == nullptr) {
            head = newEmployee;
        } else {
            Employee* current = head;
            while (current->next != nullptr) {
                current = current->next;
            }
            current->next = newEmployee;
        }
    }

    void displayEmployees() {
      string display;
      ifstream file;
      file.open("fname.txt");
      cout<< "Reading from file: \n";
      while(getline(file,display)){
        cout<< display << "\n";
      }
    }

    void promoteEmployee(int empid, string newDesignation) {
        Employee* current = head;
        while (current != nullptr) {
            if (current->empid == empid) {
                current->promote(newDesignation);
                break;
            }
            current = current->next;
        }
    }

    void demoteEmployee(int empid, string newDesignation) {
        Employee* current = head;
        while (current != nullptr) {
            if (current->empid == empid) {
                current->Demote(newDesignation);
                break;
            }
            current = current->next;
        }
    }

    void deleteEmployee()
    {
        int id;
        cout << "\nEnter the Employee ID you want to delete: ";
        cin >> id;
    
        string line;
        ifstream inFile("fname.txt");
        ofstream tempFile("temp.txt");
    
        bool found = false;
        while (getline(inFile, line))
        {
            if (line.find("Employee id: " + to_string(id)) != string::npos)
            {
                found = true;
                for (int i = 0; i < 3; ++i)
                    getline(inFile, line);
            }
            else
            {
                tempFile << line << endl;
            }
        }
        inFile.close();
        tempFile.close();
    
        if (found)
        {
            remove("fname.txt");
            rename("temp.txt", "fname.txt");
            cout << "\nEmployee deleted successfully.";
        }
        else
        {
            remove("temp.txt");
            cout << "\nEmployee not found.";
        }
    }
};

int main() {
    EmployeeList empList;
    string name;
    int choice;
    int id;
    string designation;
    string isManager;

    empList.displayEmployees();

    do {
        cout << "\nEnter: \n1- Add Employee \n2- Display Employee List \n3- Promote \n4- Demote \n5- Delete Employee \n6- Exit \nYour Choice: ";
        cin >> choice;
        if (choice == 1) {
            cout << "Enter the ID: ";
            cin >> id;
            cout << "Enter the name: ";
            cin.ignore();
            getline(cin, name);
            cout << "Enter the designation: ";
            getline(cin, designation);
            cout << "Is this employee a manager? (yes/no): ";
            getline(cin, isManager);
            if (isManager == "yes") {
                empList.addEmployee(new Manager(id, name, designation, true));
                cout << "Manager added successfully" << endl;
            } else if (isManager == "no") {
                empList.addEmployee(new Manager(id, name, designation, false));
                cout << "Employee added successfully" << endl;
            } else {
                cout << "Invalid answer" << endl;
            }
        } else if (choice == 2) {
            empList.displayEmployees();
        } else if (choice == 3) {
            cout << "\nEnter Employee ID to Promote: ";
            cin >> id;
            cout << "\nEnter Designation to Promote: ";
            cin.ignore();
            getline(cin, designation);
            empList.promoteEmployee(id, designation);
        } else if (choice == 4) {
            cout << "\nEnter Employee ID to Demote: ";
            cin >> id;
            cout << "\nEnter Designation to Demote: ";
            cin.ignore();
            getline(cin, designation);
            empList.demoteEmployee(id, designation);
        } else if (choice == 5) {
            empList.deleteEmployee();
        } else if (choice == 6) {
            cout << "\nExiting ....." << endl;
        } else {
            cout << "\nInvalid Input!!!" << endl;
        }
    } while (choice != 6);

    return 0;
}