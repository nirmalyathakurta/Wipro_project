#include <bits/stdc++.h>
using namespace std;

void addContact(ofstream &ofs) {
    int age;
    string name, email;
    
    cout << "Enter name: ";
    cin.ignore(); // Clear input buffer
    getline(cin,name);

    cout << "Enter age: ";
    cin>>age;
    
    cout << "Enter email address: ";
    cin.ignore();
    getline(cin, email);
    
    ofs << "Name: " << name << endl;
    ofs << "Age: " << age << endl;
    ofs << "Email: " << email << endl;
    
    cout << "Contact added successfully!" << endl;
}

void listContacts(ifstream &ifs) {
    string line;
    
    while (getline(ifs, line)) {
        cout << line << endl;
    }
}

bool deleteContact(const string& filename, int count) {
    if (count <= 0) { 
        cerr << "Invalid count. Please enter a positive number." << endl;
        return false;
    }
    
    
    ifstream ifs(filename);
    if (!ifs) {
        cerr << "Error opening file for reading!" << endl;
        return false;
    }
    ofstream ofs("temp.txt");
    if (!ofs) {
        cerr << "Error opening temp file for writing!" << endl;
        ifs.close();
        return false;
    }
    
    string line;
    int currentCount = 1;
    bool skipped = false; 

    
    while (getline(ifs, line)) {
        
        if (currentCount == count && !skipped) {
            skipped = true;
            
            while (getline(ifs, line) && !line.empty()) {
                
            }
            continue;
        }
        
        
        ofs << line << endl;
        
        // Check if an empty line was read (end of a contact)
        if (line.empty()) {
            currentCount++;
            skipped = false; // Reset the skip flag for the next contact
        }
    }
    
    // Close the files
    ifs.close();
    ofs.close();
    
    // Remove the original file and rename the temporary file
    if (remove(filename.c_str()) != 0) {
        cerr << "Error deleting original file!" << endl;
        return false;
    }
    if (rename("temp.txt", filename.c_str()) != 0) {
        cerr << "Error renaming temp file!" << endl;
        return false;
    }
    
    cout << "Contact number " << count << " deleted successfully!" << endl;
    return true;
}

int main() {
    ofstream ofs;
    ifstream ifs;
    
    while (true) {
        cout << "Menu:\n1. Add contact\n2. List contacts\n3. Delete Contact\n4. Exit\nEnter your choice: ";
        int choice;
        cin >> choice;
            
        switch (choice) {
            case 1:
                ofs.open("contacts.txt", ios::app); // Open file in append mode
                if (!ofs) {
                    cerr << "Error opening file for writing!" << endl;
                    return 1;
                }
                addContact(ofs);
                ofs.close();
                
                // After adding a contact, read and print all contacts
                ifs.open("contacts.txt");
                if (!ifs) {
                    cerr << "Error opening file for reading!" << endl;
                    return 1;
                }
                listContacts(ifs);
                ifs.close();
                break;
                
            case 2:
                ifs.open("contacts.txt");
                if (!ifs) {
                    cerr << "Error opening file for reading!" << endl;
                    return 1;
                }
                listContacts(ifs);
                ifs.close();
                break;
            
            case 3: 
                int count;
                cout<<"Enter contact number: ";
                cin>>count;
                if(!deleteContact("contacts.txt",count)) {
                    cout<<"Error opening file"<<endl;
                    return 1;
                }
                break;

            case 4:
                cout << "Exiting program." << endl;
                return 0;
                
            default:
                cout << "Invalid choice! Please try again." << endl;
        }
    }
}