#include <bits/stdc++.h>
using namespace std;

struct mavl {
    int age;
    struct mavl *l;
    struct mavl *r;
}*r;

class mavltree {

public:
    int height(mavl *);
    int getrldiff(mavl *);

    mavl * leftleftrot(mavl *);
    mavl * rightrightrot(mavl *);
    mavl * leftrightrot(mavl *);
    mavl * rightleftrot(mavl *);
    mavl* balanceTree(mavl*);

    mavl* insert(mavl *, int);
    void inorder(mavl *);
    void printtree(mavl *, int);

    mavltree() {
        r = NULL;
    }

    void insert(int age) {
        r = insert(r, age);
    }

    void inorderTraversal() {
        inorder(r);
    }

    void print() {
        printtree(r, 1);
    }

    void performLeftLeftRotation() {
        r = leftleftrot(r);
    }

    void performRightRightRotation() {
        r = rightrightrot(r);
    }

    void performLeftRightRotation() {
        r = leftrightrot(r);
    }

    void performRightLeftRotation() {
        r = rightleftrot(r);
    }

   
};

//
// Height of the tree. Calcluate the height of the tree by traversing
// thru the left and right subtrees and returns the maximum +1 of the 
// left and right subtrees 
//
int mavltree::height(mavl *avlt) {
    int h = 0;
    if (avlt != NULL) {
        int leftht = height(avlt->l);
        int rightlt = height(avlt->r);
        int fullheight = max(leftht, rightlt);
        h = fullheight + 1;
    }

    return h;
}

//
// To get the difference between left and right tree
// 1) Get Height of left and right. 
// 2) Use these values to get the balancing factor
//
int mavltree::getrldiff(mavl *avlt) {
    int leftheight = height(avlt->l);
    int rightheight = height(avlt->r);
    int balancefactor = leftheight - rightheight;
    return balancefactor;
}


mavl* mavltree::leftleftrot(mavl *parent) {
    mavl *tnode = parent->l;
    parent->l = tnode->r;
    tnode->r = parent;

    return tnode;
}

mavl* mavltree::rightrightrot(mavl *parent) {
    mavl *tnode = parent->r;
    parent->r = tnode->l;
    tnode->l = parent;

    return tnode;
}

mavl* mavltree::leftrightrot(mavl *parent) {
    parent->l = rightrightrot(parent->l);

    return leftleftrot(parent);
}

mavl* mavltree::rightleftrot(mavl *parent) {
    parent->r = rightrightrot(parent->r);
    return leftleftrot(parent);
}

mavl* mavltree::balanceTree(mavl* avlt) {
    int balanceFactor = getrldiff(avlt);

    if(balanceFactor > 1) {
        if(getrldiff(avlt->l) > 0) avlt = leftleftrot(avlt);
        else avlt = leftrightrot(avlt);
    }

    if(balanceFactor < -1) {
        if(getrldiff(avlt->r) > 0) avlt = rightleftrot(avlt);
        else avlt = rightrightrot(avlt);
    }

    return avlt;
        
}

mavl* mavltree::insert(mavl *avlt, int age) {
    if (avlt == NULL) {
        avlt = new mavl;
        avlt->age = age;
        avlt->l = NULL;
        avlt->r = NULL;
        return avlt;
    } 
    
    else if (age < avlt->age) {
        avlt->l = insert(avlt->l, age);
        avlt = balanceTree(avlt);
       
    }

    else if (age >= avlt->age) {
        avlt->r = insert(avlt->r, age);
        avlt = balanceTree(avlt);

    }
    
    return avlt;

}

void mavltree::inorder(mavl *avlt) {
    if (avlt == NULL) return;
    inorder(avlt->l);
    cout << avlt->age << " ";
    inorder(avlt->r);
}

void mavltree::printtree(mavl *avlt, int level) {
    if (avlt != NULL) {

        printtree(avlt->r, level + 1);
        cout<<"    ";
        if(avlt == r) cout<<"Root-> ";
        for (int i = 0; i < level && avlt != r; i++)  cout << "    ";
        cout << avlt->age << "\n";
        printtree(avlt->l, level + 1);
    }
   
}

int main() {
    mavltree avl;

    // Insert elements into the AVL tree
    avl.insert(30);
    avl.insert(25);
    avl.insert(47);
    avl.insert(13);
    avl.insert(25);
    avl.insert(55);
    avl.insert(60);
    avl.insert(105);
    avl.insert(45);
    avl.insert(20);
    
    cout<<"\nBalanced Avl tree: "<<endl<<endl;
    avl.print(); 
    cout<<endl;

    cout << "\nInorder Traversal:" << endl;
    avl.inorderTraversal();
    cout << endl<<endl;

    cout << "\nPerforming Left-Left Rotation:" << endl<<endl;
    avl.performLeftLeftRotation();
    avl.print();
    cout << endl;

    cout << "\nPerforming Right-Right Rotation:" << endl<<endl;
    avl.performRightRightRotation();
    avl.print();
    cout << endl;

    cout << "\nPerforming Left-Right Rotation:" << endl<<endl;
    avl.performLeftRightRotation();
    avl.print();
    cout << endl;

    cout << "\nPerforming Right-Left Rotation:" << endl<<endl;;
    avl.performRightLeftRotation();
    avl.print();
    cout << endl;


    return 0;
}