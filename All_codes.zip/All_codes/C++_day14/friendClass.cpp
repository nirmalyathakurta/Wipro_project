#include <bits/stdc++.h>

using namespace std;
 
Class A {

	private :

		int x;

	protected:

		int y;
 
	public :

		Xfunc() { x = 15; y=20; };
 
	friend class B;

};

Class B {
 
public :

  void showvalues (A& a) {

	cout << "value of x in Class A is " << a.x;
 
    cout << "value of y in Class A is " << a.y;

	}	

};
 
int main() {

A mA;

B frnd;
 
Frnd.showvalues(mA);

Return 0;

}
 
 
//Friend Code sample 2

/* Class myclass {

	private:

		int x;

	protected:

		int y;

	public:

		func() {

			x = 11;y=12;

		 }

	friend void myfunc( myclass& mfrnd);

};

Class tc { 

private: 

	int x;

Protected:

	int y;

	friend void myfunc(myclass& mfrnd);

};
 
Friend Void myfunc(myclass &mfrnd)

{

	cout << “X value in Myclass is “ <<  mfrnd.x;

	cout << “Y value in Myclass is “ <<  mfrnd.y;

}
 
Int main()

{

    myclass mc;

    tc mtc;
 
Myfunc(mc);

Myfunc(mtc);

 
 
 
}
 
 
//Friend Code 3 Member functions of other classes
 
#include <iostream>

Using namespace std;

Class fruit;

Class fc {

	public :

	void fcMbrFunc(fruit& orange);

};

Class fruit {

Private:

Int a;

Protected:

	int b;

Public :

	fruit()

	{

	a=5;b=6; 

}

Friend 	void fc::fcMbrFunc(fruit& orange);

};
 
 
Void  fc::fcMbrFunc(fruit& orange){

	cout << “Value of a “ << orange.a;

	cout << “Value of a “ << orange.b;

}
 
Int main() {

	fruit o;

	fc p;

	p.fcMbrFunc(o);

}; */
