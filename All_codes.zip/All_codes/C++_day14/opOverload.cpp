#include <bits/stdc++.h>
using namespace std;

class Overload {
    protected:
        int num1;
    
    public:
        Overload(int num): num1(num) {}

        bool operator > (const Overload& num2) {
            return this->num1 > num2.num1;
        }

        bool operator < (const Overload& num2) {
            return this->num1 < num2.num1;
        }

        Overload operator + (const Overload& num2) {
            return Overload(this->num1 + num2.num1);
        }

        Overload operator - (const Overload& num2) {
            return Overload(this->num1 - num2.num1);
        }

        bool operator >= (const Overload& num2) {
            return this->num1 >= num2.num1;
        }

        bool operator <= (const Overload& num2) {
            return this->num1 <= num2.num1;
        }

        friend ostream& operator<< (ostream& os, const Overload& obj) {
            os<<obj.num1;
            return os;
        }
};

int main() {
    Overload num1(10);
    Overload num2(5);

    if(num1 > num2) {
        cout<<"num1 is greater than num2"<<endl;
    }

    if(num1 < num2) {
        cout<<"num1 is less than num2"<<endl;
    }

    if(num1 >= num2) {
        cout<<"num1 is greater than equals to num2"<<endl;
    }

    if(num1 <= num2) {
        cout<<"num1 is less than equals to num2"<<endl;
    }

    Overload sum = num1 + num2;
    cout<<"Sum of num1 and num2 is: "<<sum<<endl;

    Overload difference = num1 - num2;
    cout<<"Difference of num1 and num2 is: "<<difference<<endl;

    return 0;

}