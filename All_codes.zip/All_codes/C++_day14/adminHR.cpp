#include <bits/stdc++.h>
using namespace std;

class Employee {
protected:
    string name;
    int ID;
    Employee* reportingManager;

public:  
 Employee(const string& empName,int empID): name(empName), ID(empID), reportingManager(nullptr) {}

    virtual void updatestatus(){}

    virtual void promote(const string& newDesignation) {
        cout << "Employee " << name << " " << ID << " has been promoted to " << newDesignation << "." << endl;
    }

    virtual void demote(const string& newDesignation) {
        cout << "Employee " << name << " " << ID << " has been demoted to " << newDesignation << "." << endl;
    }

    string getName(){
        return name;
    }  

    int getID(){
        return ID;
    }

    void setReportingManager(Employee* manager) {
        this->reportingManager = manager;
    }

    void displayManager() {
        if(reportingManager != nullptr){
            cout << name << " " << ID << " has " << reportingManager->getName() << " " << reportingManager->getID() << " as the reporting manager" << endl;
        }
        else{
            cout << name << " " << ID << " currently has no reporting manager" << endl;
        }
    }

    virtual void displayDetails() {
        cout << "Employee " << name << " " << ID << endl;
    }

    virtual void displayDetails(bool isNull) {
        if(isNull){
            cout << "No Employee exists in the company" << endl;
        }
        else{
            displayDetails();
        }
    }

    friend class HR;
    friend class Admin;
};

class HR {
    public:
        static void paySalary(Employee* emp, double amount) {
            cout<<"HR has paid salary Rs."<<amount<<" to "<<emp->getName()<<" "<<emp->getID()<<endl;
        }

        static void paybonus(Employee* emp, double bonus) {
            cout<<"HR has paid bonus Rs."<<bonus<<" to "<<emp->getName()<<" "<<emp->getID()<<endl;
        }
};

class Admin {
    public:
        static void enableAccess(Employee* emp) {
            cout<<"Admin has enabled access for "<<emp->getName()<<" "<<emp->getID()<<endl;
        }

        static void disableAccess(Employee* emp) {
            cout<<"Admin has disabled access for "<<emp->getName()<<" "<<emp->getID()<<endl;
        }
};

class Manager : public Employee {
protected:
    string designation;

public:
    Manager(const string& empName, const int& empID, const string& empDesignation): Employee(empName, empID), designation(empDesignation) {}

    void updatestatus() override{
        cout << designation << " " << name << " " << ID << " is receiving daily status updates." << endl;
    }

    void promote(const string& newDesignation) override{
        cout << designation << " " << name << " " << ID << " has been promoted to " << newDesignation << "." << endl;
        designation = newDesignation;
    }

    void demote(const string& newDesignation) override{
        cout << designation << " " << name << " " << ID << " has been demoted to " << newDesignation << "." << endl;
        designation = newDesignation;
    }

    void displayDetails() override{
        cout << designation << " " << name << " " << ID << endl;
    }
};

struct Node { 
 Employee* data;
    Node* next;
};

class employeeList {
private:
    Node* head;

    void swap(Node* a, Node* b){
        Employee* temp = a->data;
        a->data = b->data;
        b->data = temp;
    }

public:
    employeeList(): head(nullptr) {}

    void addemployee(Employee* emp) {
        Node* newNode = new Node;
        newNode->data = emp;
        newNode->next = head;
        head = newNode;
    }

    void displayAllEmployee() {
        Node* current = head;
        while(current != nullptr){
            current->data->displayDetails();
            current = current->next;
        }
    }

    void bubbleSortByID() {
        int n = 0;
        Node* current = head;
        while(current != nullptr) {
            n++;
            current = current->next;
        }

        for(int i = 0; i < n - 1; i++) {
            Node* current = head;
            for(int j = 0; j < n - i - 1; j++){
                if(current->data->getID() > current->next->data->getID()){
                    swap(current, current->next);
                }
                current = current->next;
            }
        }
    }

    void bubbleSortByName() {
        int n = 0;
        Node* current = head;
        while(current != nullptr){
            n++;
            current = current->next;
        }

        for(int i = 0; i < n - 1; i++) {
            Node* current = head;
            for(int j = 0; j < n - i - 1; j++) {
                if(current->data->getName() > current->next->data->getName()) {
                    swap(current, current->next);
                }
                current = current->next;
            }
        }
    }
};

int main(){
    employeeList empList;
    char name[10]; 
    string designation;
    int ID;
    char choice;

    do {
        cout << "Enter Employee name: ";
        cin>>name;
        cout << "Enter Employee ID: ";
        cin >> ID;
        cin.ignore();
        cout << "Enter Employee designation: ";
        getline(cin,designation);

        Employee* emp = new Manager(name, ID, designation);
        empList.addemployee(emp);

        cout << "Do you want to promote or demote this Employee? (p/d/n): ";
        cin >> choice;

        if(choice == 'p' || choice == 'P') {
            string newDesignation;
            cout << "Enter new designation for promotion: ";
            cin.ignore();
            getline(cin,newDesignation);
            emp->promote(newDesignation);
        }
        else if(choice == 'd' || choice == 'D') {
            string newDesignation;
            cout << "Enter new designation for demotion: ";
            cin.ignore();
            getline(cin,newDesignation);
            emp->demote(newDesignation);
        }

        cout<<"Do you want to perform HR or Admin actions? (h/a/n): ";
        cin>>choice;
        if(choice=='h' || choice=='H') {
            char action;
            cout<<"Choose HR actions: (s) Pay salary, (b) Pay bonus: ";
            cin>>action;

            if(action == 's' || action == 'S') {
                double salaryAmt;
                cout<<"Enter salary amount: ";
                cin>>salaryAmt;
                HR::paySalary(emp, salaryAmt);
            }

            else if(action == 'b' || action == 'B') {
                double bonusAmt;
                cout<<"Enter bonus amount: ";
                cin>>bonusAmt;
                HR::paySalary(emp, bonusAmt);
            }
        }

        else if(choice == 'a' || choice == 'A') {
            char action;
            cout<<"Choose Admin actions: (e) Enable Access, (d) Disable Access";
            cin>>action;
            if(action == 'e' || action == 'E') {
                Admin::enableAccess(emp);
            }

            else if(action == 'd' || action == 'D') {
                Admin::disableAccess(emp);
            }
        }

        cout << "Do you want to add another Employee? (y/n): ";
        cin >> choice;
    } while(choice == 'y' || choice == 'Y');

    cout << "Sorting employees by ID:" << endl;
    empList.bubbleSortByID();
    empList.displayAllEmployee();

    cout << "Sorting employees by name:" << endl;
    empList.bubbleSortByName();
    empList.displayAllEmployee();

    return 0;
}