#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <time.h>
#include <sys/shm.h>
#include <sys/types.h>
#include <sys/ipc.h>

#define SIZE 1024

void kill(char* s) {
    perror(s);
    exit(1);
}

typedef struct processData {
    time_t timestamp;
    float value;
    struct processData* next;
} process;

int main() {
    srand(time(NULL));
    key_t key = 1234;

    int shmid2 = shmget(key, SIZE, IPC_CREAT | 0666);

    if(shmid2==-1) kill("shmget");

    process* ptr2 = shmat(shmid2, NULL, 0);
    if(ptr2==(void*)-1) kill("shmat");

    while (1) {     
        printf("Linked List Data:\n");
        process* current = ptr2;
        while (current != NULL) {
            printf("Time: %ld, Value: %.2f\n", current->timestamp, current->value);
            current = current->next;
        }
        usleep(500000); 
    }
    

    if(shmdt(ptr2) == -1) kill("shmdt");

    return 0;
}