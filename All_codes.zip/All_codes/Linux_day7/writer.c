#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <sys/shm.h>
#include <sys/types.h>
#include <sys/ipc.h>

#define SIZE 1024

void kill(char* s) {
    perror(s);
    exit(1);
}

int main() {
    key_t key= 1234;

    int shmid1 = shmget(key, SIZE, IPC_CREAT | 0666);

    if(shmid1==-1) kill("shmget");

    float* ptr1 = shmat(shmid1, NULL, 0);
    if(ptr1 == (void*)-1) kill("shmat");

    while(1) {
        float raw_data = rand() % 100;
        *ptr1= raw_data;
        usleep(500000);
    }

    if(shmdt(ptr1) == -1) kill("shmdt");
    if(shmctl(shmid1, IPC_RMID, NULL) == -1) kill("shmdt");

    return 0;
}