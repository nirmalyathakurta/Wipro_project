/*

	Program to read/write from a file.

	a) To write a structure to a file

	b) To Read a structure from a file

*/
 
#include <stdio.h>
#include<string.h>
#include <stdlib.h>
 
struct fruit {

		int fid;

		char fruitname[20];

		char source[20];

};
 
 
int main () {

	/* FILE Entity */

	FILE *fp;

	int err;	/* This will tell us if there are any errors that have happened when we run a function */
 
	fp = fopen("fruits.lst","wb");

	if (fp == NULL) {

		fprintf(stderr,"Can't open file");

		exit(-1);

	}
 
	/* fill up data into the structure */	

	struct fruit ft;

	ft.fid=1;

	strcpy(ft.fruitname,"Apple");
	strcpy(ft.source ,"Simla");
 
	/* Write to the file */
 
	err=fwrite(&ft,sizeof(struct fruit),1,fp);
 
	/* Check for errors */	

	if (err) {

		printf("Data Written to file \n");

	}

	else {
 
		printf("Can't write data to file\n");

	}

	fclose(fp);
    return 0;
 
}
 
void readfile() {

	/* To read a file and fill up data strcuture */

	FILE *fp;
 
	fp =fopen("fruits.lst","wb+");

	if (fp == NULL) {

		fprintf(stderr,"Can't open file \n");

		exit(1);

	}
 
	struct fruit ft;
 
	do {	

		fread(&ft,sizeof(ft),1,fp);

		printf("%d->%s is from %s",ft.fid, ft.fruitname,ft.source);
 
	} while(!EOF);

	fclose(fp);

}
