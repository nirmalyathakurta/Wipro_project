
#include <stdlib.h>
#include <string.h>
#define NUM_DAYS 10
#define MAX_DATE_LENGTH 11
#define MAX_LOCATION_LENGTH 20
typedef struct{
	char date[MAX_DATE_LENGTH];
	char location[MAX_LOCATION_LENGTH];
	char temperature[3];
	struct WeatherData *prev; 
    struct WeatherData * next;
}WeatherData;
 
WeatherData* createNode(char date[], char location[], char temperature[]){
    WeatherData* newNode = (WeatherData*)malloc(sizeof(WeatherData));
    if(newNode== NULL){
        printf("Memory allocation failed");
    }
    strcpy(newNode->date,date);
    strcpy(newNode->location,location);
    strcpy(newNode->temperature,temperature);
    newNode->prev=NULL;
    newNode->next =NULL;
    return newNode;
}
void insertNode(WeatherData** head, char date[], char location[], char temperature[]){
    WeatherData* newNode = createNode(date, location, temperature);
    if(*head == NULL){
        *head = newNode;
        return;
    }
    WeatherData *curr = *head;
    while (curr->next!= NULL)
    {
        curr = curr->next;
    }
    curr->next = newNode;
    newNode->prev=curr;
}
void search_location(WeatherData* head, char location[]){
    WeatherData* curr= head;
    int found =0;
    while(curr!= NULL){
        if(strcmp(location, curr->location)==0){
            printf("Date: %s, Temperature: %s\n", curr->date, curr->temperature);
            found=1;
        }
        curr= curr->next;
    }
    if(!found){
        printf("no data found");
    }
}
void delete_location(WeatherData** head, char location[]){
    WeatherData* curr=*head;
    while(curr!=NULL){
    	if(strcmp(location,curr->location)==0){
    		if(curr->prev==NULL){
    			*head=curr->next;
			}
			else
			{
				curr->prev=curr->next;
			}
			if(curr->next!=NULL){
				curr->next=curr->prev;
			}
			free(curr);
			printf("%s Deleted successfully",location);
		}
		curr=curr->next;
	}
}
void print_data(WeatherData* head){
    WeatherData* curr = head;
    while (curr!= NULL)
    {
        printf("Date: %s, location: %s, Temperature: %s\n", curr->date, curr->location, curr->temperature);
        curr= curr->next;
    }
}
// void readWeatherData(WeatherData *data){
// 	int i;
// 	printf("enter weather data:\n");
// 	for( i=0;i<NUM_DAYS;i++){
// 		printf("Date %d (YYYY-MM-DD): ",i+1);
// 		scanf("%s",data[i].date);
// 		printf("Location %d :",i+1);
// 		scanf("%s",data[i].location);
// 		printf("Temperature %d:", i+1);
// 		scanf("%s",data[i].temperature);
 
//	}
//}
int main() {
	WeatherData* head = NULL;
    printf("enter weather data:\n");
    int i;
    for( i=0;i<10;i++){
        char date[MAX_DATE_LENGTH];
        char location[MAX_LOCATION_LENGTH];
        char temperature[3];
        printf("Date %d (YYYY-MM-DD):",i+1);
        scanf("%s",date);
        printf("Location %d: ", i+1);
        scanf("%s", location);
        printf("temperature %d: ",i+1);
        scanf("%s", temperature);
        insertNode(&head, date,location,temperature);
    }
print_data(head);

/*	 = {
        {"2024-04-01", "Location1", "25"},
        {"2024-04-01", "Location2", "27c"},
        {"2024-04-02", "Location1", "28c"},
        {"2024-04-02", "Location2", "35c"},
        {"2024-04-03", "Location5", "29c"},
        {"2024-04-04", "Location6", "30c"},
        {"2024-04-06", "Location10", "32c"},
        {"2024-04-07", "Location1", "25"},
        {"2024-04-09", "Location3", "36c"},
        {"2024-04-11", "Location1", "27c"}
};*/
    //readWeatherData(weatherData);
/*
char inputlocation[MAX_LOCATION_LEGNTH];
    char input_location = (char)malloc(MAX_LOCATION_LENGTH * sizeof(char));
    if (input_location == NULL) {
        printf("Memory allocation failed.");
        return 1;
    }
*/
char searchLocation[MAX_LOCATION_LENGTH];
printf("Enter location to search: ");
scanf("%s", searchLocation);
printf("Weather data for %s location\n", searchLocation);
search_location(head,searchLocation);
char deletelocation[MAX_LOCATION_LENGTH];
printf("Enter location to delete: ");
scanf("%s", deletelocation);
delete_location(&head, deletelocation);
print_data(head);
// 	char inputlocation[MAX_LOCATION_LENGTH];
//     printf("Enter the location: ");
//     scanf("%s", &inputlocation);
//     // Search for the entered location in the array
//     int found = 0;
//     for ( i = 0; i < NUM_DAYS; i++) {
//         if (strcmp(inputlocation, weatherData[i].location) == 0) {
//             printf("\nData for %s:\n", inputlocation);
//             printf("Date: %s\n", weatherData[i].date);
//             printf("Temperature: %s\n", weatherData[i].temperature);
//             found = 1;
//             break;
//         }
//     }
// 	char inputdate[MAX_DATE_LENGTH];
// 	 printf("Enter the Date: ");
//     scanf("%s", inputdate);

//     for ( i = 0; i < NUM_DAYS; i++) {
//         if (strcmp(inputdate, weatherData[i].date) == 0) {
//             printf("\nData for %s:\n", inputdate);
//             printf("location: %s\n", weatherData[i].location);
//             printf("Temperature: %s\n", weatherData[i].temperature);
//             found = 1;
//             break;
//         }
//     }
//     char inputtemperature[3];
//      printf("Enter the temperature: ");
//     scanf("%s", inputdate);
//      for ( i = 0; i < NUM_DAYS;
    newNode->next =NULL;
    return newNode;
}
void insertNode(WeatherData** head, char date[], char location[], char temperature[]){
    WeatherData* newNode = createNode(date, location, temperature);
    if(*head == NULL){
        *head = newNode;
        return;
    }
    WeatherData *curr = *head;
    while (curr->next!= NULL)
    {
        curr = curr->next;
    }
    curr->next = newNode;
    newNode->prev=curr;
}
void search_location(WeatherData* head, char location[]){
    WeatherData* curr= head;
    int found =0;
    while(curr!= NULL){
        if(strcmp(location, curr->location)==0) {
            printf("Date: %s, Temperature: %s\n", curr->date, curr->temperature);
            found=1;
        }
        curr= curr->next;
    }
    if(!found){
        printf("no data found");
    }
}
void delete_location(WeatherData** head, char location[]) {
    WeatherData* curr=*head;
    while(curr!=NULL){
    	if(strcmp(location,curr->location)==0) 
    		if(curr->prev==NULL) {
    			*head=curr->next;
			}
			else
			{
				curr->prev=curr->next;
			}
			if(curr->next!=NULL) {
				curr->next=curr->prev;
			}
			free(curr);
			printf("%s Deleted successfully",location);
		}
		curr=curr->next;
	}
}
void print_data(WeatherData* head) { 
    WeatherData* curr = head;
    while (curr!= NULL)
    {
        printf("Date: %s, location: %s, Temperature: %s\n", curr->date, curr->location, curr->temperature);
        curr= curr->next;
    }
}
// void readWeatherData(WeatherData *data){
// 	int i;
// 	printf("enter weather data:\n");
// 	for( i=0;i<NUM_DAYS;i++){
// 		printf("Date %d (YYYY-MM-DD): ",i+1);
// 		scanf("%s",data[i].date);
// 		printf("Location %d :",i+1);
// 		scanf("%s",data[i].location);
// 		printf("Temperature %d:", i+1);
// 		scanf("%s",data[i].temperature);
 
//	}
//}
int main() {
	WeatherData* head = NULL;
    printf("enter weather data:\n");
    int i;
    for( i=0;i<10;i++){
        char date[MAX_DATE_LENGTH];
        char location[MAX_LOCATION_LENGTH];
        char temperature[3];
        printf("Date %d (YYYY-MM-DD):",i+1);
        scanf("%s",date);
        printf("Location %d: ", i+1);
        scanf("%s", location);
        printf("temperature %d: ",i+1);
        scanf("%s", temperature);
        insertNode(&head, date,location,temperature);
    }
print_data(head);

/*	 = {
        {"2024-04-01", "Location1", "25"},
        {"2024-04-01", "Location2", "27c"},
        {"2024-04-02", "Location1", "28c"},
        {"2024-04-02", "Location2", "35c"},
        {"2024-04-03", "Location5", "29c"},
        {"2024-04-04", "Location6", "30c"},
        {"2024-04-06", "Location10", "32c"},
        {"2024-04-07", "Location1", "25"},
        {"2024-04-09", "Location3", "36c"},
        {"2024-04-11", "Location1", "27c"}
};*/
    //readWeatherData(weatherData);
/*
char inputlocation[MAX_LOCATION_LEGNTH];
    char input_location = (char)malloc(MAX_LOCATION_LENGTH * sizeof(char));
    if (input_location == NULL) {
        printf("Memory allocation failed.");
        return 1;
    }
*/
char searchLocation[MAX_LOCATION_LENGTH];
printf("Enter location to search: ");
scanf("%s", searchLocation);
printf("Weather data for %s location\n", searchLocation);
search_location(head,searchLocation);
char deletelocation[MAX_LOCATION_LENGTH];
printf("Enter location to delete: ");
scanf("%s", deletelocation);
delete_location(&head, deletelocation);
print_data(head);
// 	char inputlocation[MAX_LOCATION_LENGTH];
//     printf("Enter the location: ");
//     scanf("%s", &inputlocation);
//     // Search for the entered location in the array
//     int found = 0;
//     for ( i = 0; i < NUM_DAYS; i++) {
//         if (strcmp(inputlocation, weatherData[i].location) == 0) {
//             printf("\nData for %s:\n", inputlocation);
//             printf("Date: %s\n", weatherData[i].date);
//             printf("Temperature: %s\n", weatherData[i].temperature);
//             found = 1;
//             break;
//         }
//     }
// 	char inputdate[MAX_DATE_LENGTH];
// 	 printf("Enter the Date: ");
//     scanf("%s", inputdate);

//     for ( i = 0; i < NUM_DAYS; i++) {
//         if (strcmp(inputdate, weatherData[i].date) == 0) {
//             printf("\nData for %s:\n", inputdate);
//             printf("location: %s\n", weatherData[i].location);
//             printf("Temperature: %s\n", weatherData[i].temperature);
//             found = 1;
//             break;
//         }
//     }
//     char inputtemperature[3];
//      printf("Enter the temperature: ");
//     scanf("%s", inputdate);
//      for ( i = 0; i < NUM_DAYS;