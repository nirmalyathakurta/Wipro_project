#include <stdio.h>

#include <stdlib.h>

#include <string.h>

#define NUM_DAYS 10

#define MAX_DATE_LENGTH 11

#define MAX_LOCATION_LENGTH 20

typedef struct WeatherData{

	char date[MAX_DATE_LENGTH];

	char location[MAX_LOCATION_LENGTH];

	char temperature[3];

	struct WeatherData *prev; 

    struct WeatherData * next;

}WeatherData;

// function prototype

WeatherData* createNode(char date[], char location[], char temperature[]);

void insertNode(WeatherData** head, char date[], char location[], char temperature[]);

void search_location(WeatherData* head, char location[]);

void delete_location(WeatherData** head, char location[]);

void print_data(WeatherData* head);

void saveToFile(WeatherData* head, char fileName[]);

void readFileToList(WeatherData** head, char fileName[]);

void editData(WeatherData* head,char location[]);
 
 
int main() {
 
 
   

WeatherData* head=NULL;

char fileName[]="weather_data.txt";

readFileToList(&head ,fileName);
 
int choice;

char location[MAX_LOCATION_LENGTH];

do{

    printf("\n enter weather data\n");

    printf("1.add data \n ");

    printf("2.remove data\n");

    printf("3.search data\n");

    printf("4.edit data\n");

    printf("5.save data\n");

    printf("6.print data\n");

    printf("7.exit\n");

    printf("ENTER YOUR CHOICE\n");

    scanf("%d",&choice);

 
switch (choice)

{

    case 1:

           {

            char date[MAX_DATE_LENGTH];

            char temperature[3];

            printf("enter date (YYYY-MM-DD) \n");

            scanf("%s",date);

            printf("enter location \n");

            scanf("%s",location);

            printf("enter temperature\n");

            scanf("%s",temperature);

            insertNode(&head,date,location,temperature);

            break;

           }
 
     case 2:

     {

        printf("enter the location to delete");

        scanf("%s",location);

        delete_location(&head,location);

        break;

     }      

     case 3:

     {

        printf("enter location to search");

        scanf("%s",location);

        search_location(head,location);

        break;

     }
 
     case 4:

     {

        printf("enter location to edit");

        scanf("%s",location);

        editData(head,location);

        break;

     }
 
     case 5:

     {

        saveToFile(head ,fileName);

        break;
 
     }
 
      case 6:

      {

        print_data(head);

        break;

      }
 
      case 7:

      {

                 printf("exiting\n");

                 break;

      }
 
      default :

                printf("invalid choice\n");


}
 
}
 
while(choice!=7);

WeatherData* curr = head;

while(curr!=NULL){

    WeatherData* temp=curr;

    curr = curr->next;

    free(temp);

}

return 0;

}
 
 
WeatherData* createNode(char date[], char location[], char temperature[]){

    WeatherData* newNode = (WeatherData*)malloc(sizeof(WeatherData));

    if(newNode== NULL){

        printf("Memory allocation failed");

        exit(EXIT_FAILURE);

    }

    strcpy(newNode->date,date);

    strcpy(newNode->location,location);

    strcpy(newNode->temperature,temperature);

    newNode->prev=NULL;

    newNode->next =NULL;

    return newNode;

}
 
void insertNode(WeatherData** head, char date[], char location[], char temperature[]){

    WeatherData* newNode = createNode(date, location, temperature);

    if(*head == NULL){

        *head = newNode;

        return;

    }

    WeatherData *curr = *head;

    while (curr->next!= NULL)

    {

        curr = curr->next;

    }

    curr->next = newNode;

    newNode->prev=curr;

}
 
void search_location(WeatherData* head, char location[]){

    WeatherData* curr= head;

    int found =0;

    while(curr!= NULL){

        if(strcmp(location, curr->location)==0){

            printf("Date: %s, Temperature: %s\n", curr->date, curr->temperature);

            found=1;

        }

        curr= curr->next;

    }

    if(!found){

        printf("no data found");

    }

}
 
void delete_location(WeatherData** head, char location[]){

    WeatherData* curr=*head;

    while(curr!=NULL){

    	if(strcmp(location,curr->location)==0){

    		if(curr->prev==NULL){

    			*head=curr->next;

			}

			else

			{

				curr->prev=curr->next;

			}

			if(curr->next!=NULL){

				curr->next=curr->prev;

			}

			free(curr);

			printf("%s Deleted successfully",location);

            return;

		}

		curr=curr->next;

	}

    printf("no data found for that location %s\n",location);

}
 
 
void print_data(WeatherData* head){

    WeatherData* curr = head;

    printf("weather data\n");

    while (curr!= NULL)

    {

        printf("Date: %s, location: %s, Temperature: %s\n", curr->date, curr->location, curr->temperature);

        curr= curr->next;

    }

}
 
 
void saveToFile(WeatherData* head, char fileName[])

{

    FILE* file=fopen(fileName,"w");

    if(file==NULL){

        printf("error in opening file\n");

        return;
 
    }

    WeatherData* curr = head;

    while(curr!=NULL){

        fprintf(file,"%s %s %s\n",curr->date ,curr->location,curr->temperature);

        curr = curr->next;

    }

    fclose(file);
 
    printf("data saved to FILE %s\n", fileName);

}
 
void readFileToList(WeatherData** head, char fileName[]){

    FILE* file=fopen(fileName ,"r");

    if(file==NULL){

        printf("file does not exist creating new file %s\n",fileName);

        file=fopen(fileName,"w");

        if(file==NULL){

            printf("error creating in file %s\n",fileName);

            return;

        }

        fclose(file);

        return;

    }

    fclose(file);

    file=fopen(fileName ,"r");

    char date[MAX_DATE_LENGTH];

    char location[MAX_LOCATION_LENGTH];

    char temperature[3];
 
    while(fscanf(file, "%s %s %s\n",date ,location,temperature)!=EOF){

        insertNode(head,date,location,temperature);

    }

    fclose(file);

    printf("data is loaded to file\n");

}
 
void editData(WeatherData* head,char location[]){

    WeatherData* curr = head;

    char newTemperature[3];

    int found =0;

    printf("enter new temperature for location %s\n",location);

    scanf("%s",newTemperature);
 
    while(curr!=NULL){

        if(strcmp(location,curr->location)==0){

            strcpy(curr->temperature,newTemperature);

            printf(" edited data for location succusfully %s\n ",location);

            found=1;

            break;

            }

            curr=curr->next;

}
 
if(!found){
 
    printf("no data found found for that location %s /n" ,location);

}
 
}