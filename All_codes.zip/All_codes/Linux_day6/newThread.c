#include <stdio.h>
#include <stdlib.h>
#include <pthread.h>
#include <unistd.h>
#include <semaphore.h>
#include <time.h>

typedef struct raw_device_data {
    float value;
} raw_device_data_t;

typedef struct devdataprocessed {
    time_t timestamp;
    float value;
    struct devdataprocessed* next;
} devdataprocessed_t;


devdataprocessed_t* head = NULL;


sem_t data_available_sem;


raw_device_data_t read_data() {
   
    raw_device_data_t data;
    data.value = rand() % 100;
    return data;
}


void write_processed_data(devdataprocessed_t* data) {
    FILE* file = fopen("processed_data.txt", "a");
    if (file == NULL) {
        perror("fopen");
        return;
    }
    fprintf(file, "%ld, %.2f\n", data->timestamp, data->value);
    fclose(file);
}


void* process_data(void* arg) {
    while (1) {
        sem_wait(&data_available_sem);

        
        raw_device_data_t data = read_data();

        
        devdataprocessed_t* processed_data = (devdataprocessed_t*)malloc(sizeof(devdataprocessed_t));
        processed_data->timestamp = time(NULL);
        processed_data->value = data.value * 1000;

        
        write_processed_data(processed_data);

        processed_data->next = head;
        head = processed_data;
    }
    return NULL;
}


void* build_linked_list(void* arg) {
    while (1) {     
        printf("Linked List Data:\n");
        devdataprocessed_t* current = head;
        while (current != NULL) {
            printf("Time: %ld, Value: %.2f\n", current->timestamp, current->value);
            current = current->next;
        }
        usleep(5000000); 
    }
    return NULL;
}

int main() {
    srand(time(NULL));
    
    sem_init(&data_available_sem, 0, 0);

    pthread_t process_thread, build_list_thread;
    pthread_create(&process_thread, NULL, process_data, NULL);
    pthread_create(&build_list_thread, NULL, build_linked_list, NULL);
    
    // pthread_join(process_thread, NULL);
    // pthread_join(build_list_thread, NULL);

    while (1) {
        printf("Data processing ongoing...\n");
        fflush(stdout); 
        sem_post(&data_available_sem);
        sleep(3); 
    }

    sem_destroy(&data_available_sem);

    devdataprocessed_t* current = head;
    while (current != NULL) {
        devdataprocessed_t* temp = current;
        current = current->next;
        free(temp);
    }
    return 0;
}