#include <stdio.h>
#include <stdlib.h>
#include <pthread.h>
#include <unistd.h>
#include <time.h>

#define BUFFER_SIZE 10
#define MAX_PROCESSED_DATA 10 // Maximum number of processed data to output

typedef struct raw_device_data {
    float value;
} raw_device_data_t;

typedef struct devdataprocessed {
    time_t timestamp;
    float value;
    struct devdataprocessed* next;
} devdataprocessed_t;

// Mutex to protect access to shared buffer and linked list head
pthread_mutex_t buffer_mutex = PTHREAD_MUTEX_INITIALIZER;
pthread_mutex_t list_mutex = PTHREAD_MUTEX_INITIALIZER;

// Buffer for raw data
raw_device_data_t buffer[BUFFER_SIZE];
int in = 0, out = 0; // Indices for buffer

// Head of the linked list
devdataprocessed_t* head = NULL;

// Counter for processed data
int processed_data_count = 0;

// Flag to indicate if processing should stop
int stop_processing = 0;

// Function to read data from a source (replace with your actual reading logic)
raw_device_data_t read_data() {
    // Simulate reading data
    raw_device_data_t data;
    data.value = rand() % 100;  // Generate random value (replace with actual reading)
    return data;
}

// Function to write data to a file (replace with your actual writing logic)
void write_processed_data(devdataprocessed_t* data) {
    FILE* file = fopen("processed_data.txt", "a");
    if (file == NULL) {
        perror("fopen");
        return;
    }

    fprintf(file, "%ld, %.2f\n", data->timestamp, data->value);
    fclose(file);
}

// Function to process data in a separate thread
void* process_data(void* arg) {
    while (!stop_processing) {
        // Acquire mutex to access shared buffer
        pthread_mutex_lock(&buffer_mutex);

        // Check if data is available in the buffer
        if (in != out) {
            // Get data from buffer
            raw_device_data_t data = buffer[out];
            out = (out + 1) % BUFFER_SIZE;

            // Release mutex after accessing buffer
            pthread_mutex_unlock(&buffer_mutex);

            // Process data (scale by 1000)
            devdataprocessed_t* processed_data = (devdataprocessed_t*)malloc(sizeof(devdataprocessed_t));
            processed_data->timestamp = time(NULL);
            processed_data->value = data.value * 1000;

            // Write processed data to file
            write_processed_data(processed_data);

            // Acquire mutex to access linked list head
            pthread_mutex_lock(&list_mutex);

            // Add processed data to the beginning of the list
            processed_data->next = head;
            head = processed_data;

            // Release mutex after adding node to the list
            pthread_mutex_unlock(&list_mutex);

            // Increment processed data counter
            processed_data_count++;
        } else {
            // Release mutex without processing if buffer is empty
            pthread_mutex_unlock(&buffer_mutex);
        }
        
        // Check if maximum processed data count reached
        if (processed_data_count >= MAX_PROCESSED_DATA) {
            stop_processing = 1;
        }

        // Sleep for a short interval (simulate data processing rate)
        usleep(100000); // 100 ms
    }

    return NULL;
}

// Function to print linked list data
void print_linked_list() {
    // Acquire mutex to access linked list
    pthread_mutex_lock(&list_mutex);

    printf("Linked List Data:\n");
    devdataprocessed_t* current = head;
    while (current != NULL) {
        printf("Time: %ld, Value: %.2f\n", current->timestamp, current->value);
        current = current->next;
    }

    // Release mutex after accessing linked list
    pthread_mutex_unlock(&list_mutex);
}

int main() {
    // Initialize random number generator
    srand(time(NULL));

    // Create thread for processing data
    pthread_t processing_thread;
    pthread_create(&processing_thread, NULL, process_data, NULL);

    // Main thread: Generate raw data and add to buffer
    while (!stop_processing) {
        // Generate raw data
        raw_device_data_t data = read_data();

        // Acquire mutex to access shared buffer
        pthread_mutex_lock(&buffer_mutex);

        // Add data to buffer if space is available
        if (((in + 1) % BUFFER_SIZE) != out && ((in + 1) % BUFFER_SIZE) != in) {   
            buffer[in] = data;
            in = (in + 1) % BUFFER_SIZE;
        }

        // Release mutex after adding data
        pthread_mutex_unlock(&buffer_mutex);

        // Sleep for a short interval (simulate data generation rate)
        usleep(500000); // 500 ms
        
        // Print linked list data periodically
        print_linked_list();
    }

    // Wait for the processing thread to finish
    pthread_join(processing_thread, NULL);

    // Clean up: Free memory allocated for processed data
    devdataprocessed_t* current = head;
    while (current != NULL) {
        devdataprocessed_t* temp = current;
        current = current->next;
        free(temp);
    }

    return 0;
}