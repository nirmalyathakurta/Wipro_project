//Ask the user for start and the end point
//calculate the distance..find the route
//keep track of current gps-co ordinates till the target is reached
//make class for tracking gps co-ordinates.it should be navigate from point a and b
//create class gps for for storing coordinates and displaying
//make a calculate function to cal distance from A to B

#include<bits/stdc++.h>

using namespace std;

//gps for tracking the location
class gps {
    protected:
    double latitude;
    double longitude;

    public:
    //construtor
    gps(double lat,double lon):latitude(lat),longitude(lon) {
    }
    //Update latitude and longitude
    void updateloc(double lat,double lon) {
        latitude=lat;
        longitude=lon;
    }
    //Display the current location
    void displayloc() {
        cout<<"Current location:Latitude \n "<<latitude<<",Longitude"<<longitude;
    }
};

class Vehicle:public gps {
    private:
    string startlocation;
    string endlocation;
    double dist;

    public:
    //constructor
    Vehicle(double lat,double lon):gps(lat,lon) {}

    void setRoute(const string& start,const string& end) {
        startlocation=start;
        endlocation=end;
    }

    double calculatedis(double endlat, double endlong) {
        dist=sqrt(pow(latitude-endlat,2)+pow(longitude-endlong,2));
        return dist;
    }
    void navigate(double endlat,double endlong){
        cout<<"Navigating from"<<startlocation<<"latitude:"<<latitude<<"longitude"<<longitude<<"to"<<endlocation<<"latitude"<<latitude<<"longitude endlocation"<<longitude<<endl;
        cout<<"Estimate distance:"<<fixed<<setprecision(2)<<dist<<"units:"<<endl;

        const double threshold=0.1;

        while(dist>threshold) {
            double olddist=dist;
            latitude-=0.01;
            longitude -=0.02;
            dist=calculatedis(endlat,endlong);

            if(olddist<=dist) {
                break;
            }
            displayloc();
        }
        cout<<"Destination reached at "<<endlocation<<"latitude"<<endlat<<"end longitude"<<endlong<<endl;

        //calculate the distance between a and b
         double distAB=sqrt(pow(latitude-endlat,2)+pow(longitude-endlong,2));
         cout<<"Distance b/w a and b: "<<fixed<<setprecision(2)<<distAB<<" units"<<endl;

    }

};

int main() {
    double startlat,startlong,endlat,endlong;
    string start,end;

    cout<<"Enter start location name:\n";
    getline(cin,start);
        
    cout<<"Enter the starting longitude and latitude:\n";
    cin>>startlat>>startlong;

    cout<<"Enter end location name:\n";
    cin.ignore();
    getline(cin,end);

    cout<<"Enter the ending point longitude and latitude:\n";
    cin>>endlat>>endlong;

    Vehicle car(startlat,startlong);
    car.setRoute(start,end);

    double initaldist=car.calculatedis(endlat,endlong);
    car.navigate(endlat,endlong);

    return 0;

    }