#!/bin/bash


hour=$(date +%H)

time() {
    local hour=$1
    if (( hour >= 5 && hour < 12 )); then
        echo "Good Morning"
    elif (( hour >= 12 && hour < 17 )); then
        echo "Good Afternoon"
    elif (( hour >= 17 && hour < 21 )); then
        echo "Good Evening"
    else
        echo "Good Night"
    fi
}

time "$hour"
