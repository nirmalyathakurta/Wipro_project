#!/bin/bash

a=5

myfunc() {
	echo "This is test fucn"
	return
}

plusOne() {
	a=$((a+1))
	return
}

odd_even() {
	echo "Enter a number: "
	read num
	
	if [ $((num%2)) -eq 0 ] ; then
		echo "$num is even"
	else
		echo "$num is odd"
	fi
}

params() {
	x=$#
	echo "$@"
	for x in "$@" 
	do 
		echo "$x"
		
	done
	return
}


myfunc
plusOne
echo "$a"
odd_even
params a 10 15 b
