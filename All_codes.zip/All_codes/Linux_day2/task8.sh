#!/bin/bash
 
while [[ $# -gt 0 ]]; do
  case "$1" in
    -a|--apple)
      echo "Option -a or --apple is present."
      ;;
    -b|--banana)
      echo "Option -b or --banana is present."
      ;;
    -c|--count)
      if [[ -n "$2" ]]; then
        count="$2"
        echo "Count is set to $count."
        shift
      else
        echo "Error: Count requires a value."
        exit 1
      fi
      ;;
    *)
      echo "Unknown option: $1"
      exit 1
      ;;
  esac
  shift
done
