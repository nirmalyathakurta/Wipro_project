// b) anoother program having 2 threads
// 1) read the file from program 1 and scaleee the data comming in
// 2)thread 2 to calculate the average of values every minuuuuuutes and store it in  a data strututre 
// struct {
//     avgvalue
//     timestamp
// };


//define structure
// function to scaling the data
//function for cal avg every minutes
// in main function
// initialised semaphores
// create threads
// joins threads
// destroy semaphores

#include<stdio.h>
#include<stdlib.h>
#include<pthread.h>
#include<unistd.h>
#include<time.h>

#define FILENAME "output.txt"
#define DATA_SIZE 1024

struct Data{
    float AvgValue;
    time_t TimeStamp;
};

// function to scaling the data
void *read_file_and_scale(void *arg){
    while(1){
        FILE *file = fopen(FILENAME,"r");
        if(file ==NULL){
            printf("error in opening file");
            exit(0);
        }
        float data;
        while(fscanf(file,"%*s%f",&data)!=EOF){
            // if (fscanf(file,"%*s%f",&data)==0){
            //     printf("error reading data from file");
            //     exit(0);
            // }
            // here we get data then sclaed by 2(multiply)
            float scaled_data = data*2;
            printf("scaled data: %.2f\n",scaled_data);
        }
        fclose(file);
        sleep(5);
    }
    return NULL;
}

//function for cal avg every minutes
void *calculate_average(void *arg){
    struct Data average_data;
    int count =0;
    float sum =0;

    while(1){
        FILE *file=fopen(FILENAME,"r");
        if (file==NULL){
            printf("error in opeing in file");
            exit(0);
        }
        float sum = 0;
        float count = 0;
        float data;
        while(fscanf(file,"%*s%f",&data)!=EOF){
            sum +=data;
            count++;
        }
        fclose(file);

        //calculate average
        if(count>0){
            average_data.AvgValue=sum/count;
            average_data.TimeStamp=time(NULL);

            // store avg value in data struct
            printf("\nAverage value: %.2f,Timestamp:%ld\n\n",average_data.AvgValue,average_data.TimeStamp);
        
        }
        sleep(5);  //cal avg every min

    }
    return NULL;


}


int main(){
    pthread_t thread1,thread2;

    // create thread
    pthread_create(&thread1,NULL,read_file_and_scale,NULL);
    pthread_create(&thread2,NULL,calculate_average,NULL);
    
    //join threads
    pthread_join(thread1,NULL);
    pthread_join(thread2,NULL);
    return 0;

}