#include <bits/stdc++.h>
using namespace std;

class Log {
public:
    
    static Log& getInstance() {
        if (!instance) {

            instance = new Log();

        }

        return *instance;
    }

    
    void logWrite(const string& message) {
        cout <<"Writing in the log: "<< message << endl;
    }

    void logOperation() {
        
        cout<< "Log is performing log operations."<< endl;

    }

    void deleteLog() {
        delete instance;
    }
    
    Log(const Log&) = delete;

    Log& operator=(const Log&) = delete;

 private:   
    Log() {
        cout<<"Log instance created"<<endl;
    }

    
    ~Log() {
        cout<<"Log instance destroyed"<<endl;
    }
    
    static Log* instance;
    
};

Log* Log::instance = nullptr;


int main() {
    
    Log& log = Log::getInstance();

    log.logWrite("Writing done");
    log.logOperation();

    cout<<"Completed log operation"<<endl;

    log.deleteLog();

    return 0;
}