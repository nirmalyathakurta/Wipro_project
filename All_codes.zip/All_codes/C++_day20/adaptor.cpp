#include <bits/stdc++.h>
using namespace std;

// USB 
class USBDevice {
public:
    void sendDataViaUSB(const std::string& data) {
        std::cout << "Sending data via USB: " << data << std::endl;
    }
};

// HDMI 
class HDMIDevice {
public:
    void displayHDMI(const std::string& video, const std::string& audio) {
        std::cout << "Displaying video via HDMI: " << video << std::endl;
        std::cout << "Audio: " << audio << std::endl;
    }
};


class USBToHDMIAdapterAudio {
private:
    USBDevice usbDevice;

public:
    void sendAudioVideoViaHDMI(const std::string& video, const std::string& audio) {
        
        std::string hdAudio = "HD 5.1 Audio: " + audio;
        std::string hdmiData = "HDMI Video: " + video + ", " + hdAudio;
        usbDevice.sendDataViaUSB(hdmiData);
    }
};


class USBToHDMIAdapterVideo {
private:
    USBDevice usbDevice;

public:
    void sendVideoViaHDMI(const std::string& video) {
       
        std::string stereoVideo = "Stereo Video: " + video;
        usbDevice.sendDataViaUSB(stereoVideo);
    }
};

int main() {
    HDMIDevice hdmiDevice;
    USBToHDMIAdapterAudio usbToHDMIAdapterAudio;
    USBToHDMIAdapterVideo usbToHDMIAdapterVideo;

   
    hdmiDevice.displayHDMI("HD Video", "HD 5.1 Audio");

    
    usbToHDMIAdapterAudio.sendAudioVideoViaHDMI("HD Video", "HD Audio");

 
    usbToHDMIAdapterVideo.sendVideoViaHDMI("HD Video");

    return 0;
}