#include <bits/stdc++.h>

using namespace std;

class Food {
public:
    virtual void prep() = 0;
    virtual void cook() = 0;
    virtual void eat() = 0;
    virtual ~Food() {} 
};

class Roti : public Food {
public:
    void prep() override {
        cout << "Kneading dough." << endl;
    }
    void cook() override {
        cout << "Put it on pan." << endl;
    }
    void eat() override {
        cout << "Yummy." << endl;
    }
};

class Curry : public Food {
public:
    void prep() override {
        cout << "Cut Vegetables and Marinate." << endl;
    }
    void cook() override {
        cout << "Boil with Spices and salt as required." << endl;
    }
    void eat() override {
        cout << "Eat with Roti." << endl;
    }
};

class FoodFactory {
public:
    virtual Food* createRoti() = 0;
    virtual Food* createCurry() = 0;
    virtual ~FoodFactory() {} 
};

class RotiFactory : public FoodFactory {
public:
    Food* createRoti() override {
        return new Roti();
    }
    Food* createCurry() override {
        return nullptr; 
    }
};

class CurryFactory : public FoodFactory {
public:
    Food* createRoti() override {
        return nullptr; 
    }
    Food* createCurry() override {
        return new Curry();
    }
};

int main() {
    FoodFactory* rotifactory = new RotiFactory();
    FoodFactory* curryfactory = new CurryFactory();

    Food* roti = rotifactory->createRoti();
    Food* curry = curryfactory->createCurry();

    if (roti) {
        roti->prep();
        roti->cook();
        roti->eat();
        delete roti;
    }

    if (curry) {
        curry->prep();
        curry->cook();
        curry->eat();
        delete curry;
    }

    delete rotifactory;
    delete curryfactory;

    return 0;
}