#include <bits/stdc++.h>
using namespace std;

class Car {
    public:
        void setBrand(const string& brand) {
            this->brand_ = brand;
        }

        void setColor(const string& color) {
            this->color_ = color;
        }

        void setModel(const string& model) {
            this->model_ = model;
        }

        void setEngine(const string& engine) {
            this->engine_ = engine;
        }

        void display() {
            cout << "Brand: " << brand_ << endl;
            cout << "Color: " << color_ << endl;
            cout << "Model: " << model_ << endl;
            cout << "Engine: " << engine_ << endl;
        }

    private:
        string brand_;
        string color_;
        string model_;
        string engine_;
    };

// Builder 
class carBuilder {
    public:
        virtual void buildBrand(const string& brand) = 0;
        virtual void buildColor(const string& color) = 0;
        virtual void buildModel(const string& model) = 0;
        virtual void buildEngine(const string& engine) = 0;
        virtual Car getResult() = 0;
};

// Concrete Builder
class nissanCarBuilder : public carBuilder {
    public:
        nissanCarBuilder() {
            this->car_ = Car();
        }

        void buildBrand(const string& brand) override {
            car_.setBrand(brand);
        }

        void buildColor(const string& color) override {
            car_.setColor(color);
        }

        void buildModel(const string& model) override {
            car_.setModel(model);
        }

        void buildEngine(const string& engine) override {
            car_.setEngine(engine);
        }

        Car getResult() override {
            return car_;
        }

    private:
        Car car_;
};

// Director
class carAssembler {
    public:
        Car assembleCar(carBuilder& builder) {
            builder.buildBrand("Nissan");
            builder.buildColor("Blue");
            builder.buildModel("GTR");
            builder.buildEngine("High Performance");
            return builder.getResult();
        }
};

int main() {
    nissanCarBuilder nissanBuilder;
    carAssembler assembler;
    Car nissan = assembler.assembleCar(nissanBuilder);

    cout << "Nissan Car Configuration:" << endl;
    nissan.display();

    return 0;
}