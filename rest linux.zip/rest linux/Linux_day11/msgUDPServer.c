#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <sys/types.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <pthread.h>

#define PORT 5000
#define MAX_MSG_SIZE 1024
#define MAX_CLIENTS 10

typedef struct {
    int socket;
    struct sockaddr_in address;
} Client;

Client clients[MAX_CLIENTS];
int num_clients = 0;

//void *handle_client(void *arg);
int get_client_id(struct sockaddr_in client_addr);

int main() {
    int server_socket;
    struct sockaddr_in server_addr;

    server_socket = socket(AF_INET, SOCK_DGRAM, 0);
    if (server_socket < 0) {
        perror("Error creating socket");
        exit(EXIT_FAILURE);
    }

    memset(&server_addr, 0, sizeof(server_addr));
    server_addr.sin_family = AF_INET;
    server_addr.sin_addr.s_addr = INADDR_ANY;
    server_addr.sin_port = htons(PORT);

    if (bind(server_socket, (struct sockaddr *)&server_addr, sizeof(server_addr)) < 0) {
        perror("Error binding address");
        exit(EXIT_FAILURE);
    }

    printf("UDP server started. Listening for incoming messages...\n");

    while (1) {
        struct sockaddr_in client_addr;
        socklen_t client_len = sizeof(client_addr);
        char buffer[MAX_MSG_SIZE];
        int bytes_received = recvfrom(server_socket, buffer, sizeof(buffer), 0, (struct sockaddr *)&client_addr, &client_len);
        if (bytes_received <= 0) {
            perror("Error receiving message");
            continue;
        }

        printf("Client %d: %s", get_client_id(client_addr), buffer);

        sendto(server_socket, "Message received", strlen("Message received"), 0, (struct sockaddr *)&client_addr, client_len);
    }

    close(server_socket);

    return 0;
}


int get_client_id(struct sockaddr_in client_addr) {
    for (int i = 0; i < num_clients; i++) {
        if (memcmp(&clients[i].address, &client_addr, sizeof(struct sockaddr_in)) == 0) {
            return i + 1; 
        }
    }
    
    if (num_clients < MAX_CLIENTS) {
        clients[num_clients].address = client_addr;
        num_clients++;
        return num_clients;
    }
    return -1; 
}