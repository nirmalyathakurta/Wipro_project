#include <linux/module.h>
#include <linux/kernel.h>
#include <linux/init.h>

static char* myname="Namratha";
static int money = 1000000;

module_param(myname,charp,S_IRUGO);
module_param(money,int,S_IRUGO);

MODULE_LICENSE("GPL");
MODULE_AUTHOR("NAMRATHA");
MODULE_DESCRIPTION("HELLO KERNEL");
MODULE_VERSION("0.1");

static int __init hello_start(void)
{
    printk(KERN_INFO "Hello Everyone\n");
    printk(KERN_INFO "Hello Team3\n");
    printk(KERN_INFO "myname is %s\n",myname);
    printk(KERN_INFO "money is %d\n",money);
    return 0;
}

static void __exit hello_end(void)
{
    printk(KERN_INFO "Good byee everyone\n");
    printk(KERN_INFO "Testing.....\n");
}

module_init(hello_start);
module_exit(hello_end);


