```
#include <linux/init.h>
#include <linux/module.h>
#include <linux/cdev.h>
#include <linux/device.h>
#include <linux/kernel.h>
#include <linux/uaccess.h>
#include <linux/fs.h>

#define MAX_DEV 4  // Define the number of devices to create

// Function prototypes for device operations
static int mychardev_open(struct inode *inode, struct file *file);
static int mychardev_release(struct inode *inode, struct file *file);
static long mychardev_ioctl(struct file *file, unsigned int cmd, unsigned long arg);
static ssize_t mychardev_read(struct file *file, char __user *buf, size_t count, loff_t *offset);
static ssize_t mychardev_write(struct file *file, const char __user *buf, size_t count, loff_t *offset);

// Define file operations structure
static const struct file_operations mychardev_fops = {
    .owner = THIS_MODULE,
    .open = mychardev_open,
    .release = mychardev_release,
    .unlocked_ioctl = mychardev_ioctl,
    .read = mychardev_read,
    .write = mychardev_write
};

// Structure to hold device data
struct mychar_device_data {
    struct cdev cdev;
};

// Global variables
static int dev_major = 0;
static struct class *mychardev_class = NULL;
static struct mychar_device_data mychardev_data[MAX_DEV];  // Array to hold data for each device

// Function to set device permissions
static int mychardev_uevent(struct device *dev, struct kobj_uevent_env *env)
{
    add_uevent_var(env, "DEVMODE=%#o", 0666);
    return 0;
}

// Module initialization function
static int __init mychardev_init(void)
{
    int err, i;
    dev_t dev;

    // Allocate a range of character device numbers
    err = alloc_chrdev_region(&dev, 0, MAX_DEV, "mychardev");
    if (err < 0) {
        printk(KERN_ERR "Failed to allocate char device region\n");
        return err;
    }

    dev_major = MAJOR(dev);

    // Create a device class
    mychardev_class = class_create(THIS_MODULE, "mychardev");
    if (IS_ERR(mychardev_class)) {
        unregister_chrdev_region(dev, MAX_DEV);
        return PTR_ERR(mychardev_class);
    }
    mychardev_class->dev_uevent = mychardev_uevent;

    // Initialize and add each device
    for (i = 0; i < MAX_DEV; i++) {
        cdev_init(&mychardev_data[i].cdev, &mychardev_fops);
        mychardev_data[i].cdev.owner = THIS_MODULE;

        err = cdev_add(&mychardev_data[i].cdev, MKDEV(dev_major, i), 1);
        if (err) {
            printk(KERN_ERR "Failed to add cdev %d\n", i);
            while (i--) {
                cdev_del(&mychardev_data[i].cdev);
            }
            class_destroy(mychardev_class);
            unregister_chrdev_region(dev, MAX_DEV);
            return err;
        }

        // Create a device node in /dev
        device_create(mychardev_class, NULL, MKDEV(dev_major, i), NULL, "mychardev-%d", i);
    }

    printk(KERN_INFO "mychardev module loaded\n");
    return 0;
}

// Module cleanup function
static void __exit mychardev_exit(void)
{
    int i;

    // Destroy each device node
    for (i = 0; i < MAX_DEV; i++) {
        device_destroy(mychardev_class, MKDEV(dev_major, i));
        cdev_del(&mychardev_data[i].cdev);
    }

    // Unregister and destroy the device class
    class_unregister(mychardev_class);
    class_destroy(mychardev_class);

    // Release the allocated device numbers
    unregister_chrdev_region(MKDEV(dev_major, 0), MAX_DEV);

    printk(KERN_INFO "mychardev module unloaded\n");
}

// Device open function
static int mychardev_open(struct inode *inode, struct file *file)
{
    printk(KERN_INFO "MYCHARDEV: Device open\n");
    return 0;
}

// Device release function
static int mychardev_release(struct inode *inode, struct file *file)
{
    printk(KERN_INFO "MYCHARDEV: Device close\n");
    return 0;
}

// Device ioctl function
static long mychardev_ioctl(struct file *file, unsigned int cmd, unsigned long arg)
{
    printk(KERN_INFO "MYCHARDEV: Device ioctl\n");
    return 0;
}

// Device read function
static ssize_t mychardev_read(struct file *file, char __user *buf, size_t count, loff_t *offset)
{
    uint8_t *data = "Hello from the kernel world!\n";
    size_t datalen = strlen(data);

    printk(KERN_INFO "Reading device: %d\n", MINOR(file->f_path.dentry->d_inode->i_rdev));

    if (count > datalen) {
        count = datalen;
    }

    if (copy_to_user(buf, data, count)) {
        return -EFAULT;
    }

    return count;
}

// Device write function
static ssize_t mychardev_write(struct file *file, const char __user *buf, size_t count, loff_t *offset)
{
    size_t maxdatalen = 30, ncopied;
    uint8_t databuf[maxdatalen];

    printk(KERN_INFO "Writing device: %d\n", MINOR(file->f_path.dentry->d_inode->i_rdev));

    if (count < maxdatalen) {
        maxdatalen = count;
    }

    ncopied = copy_from_user(databuf, buf, maxdatalen);

    if (ncopied == 0) {
        printk(KERN_INFO "Copied %zd bytes from the user\n", maxdatalen);
    } else {
        printk(KERN_ERR "Couldn't copy %zd bytes from the user\n", ncopied);
    }

    databuf[maxdatalen] = 0;

    printk(KERN_INFO "Data from the user: %s\n", databuf);

    return count;
}

// Module metadata
MODULE_LICENSE("GPL");
MODULE_AUTHOR("Oleg Kutkov <elenbert@gmail.com>");

// Specify initialization and cleanup functions
module_init(mychardev_init);
module_exit(mychardev_exit);
```