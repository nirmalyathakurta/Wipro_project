#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <arpa/inet.h>
#include <pthread.h>
#include <semaphore.h>

#define PORT 8080
#define BUFFER_SIZE 1024
#define MAX_CLIENTS 100

typedef struct {
    struct sockaddr_in address;
    int id;
    int active;
} Client;

Client clients[MAX_CLIENTS];
int client_count = 0;
sem_t client_sem; // Semaphore for client management
sem_t rw_sem;     // Semaphore for reader-writer synchronization

void add_client(struct sockaddr_in *client_addr) {
    clients[client_count].address = *client_addr;
    clients[client_count].id = client_count + 1;
    clients[client_count].active = 1;
    client_count++;
}

int find_client(struct sockaddr_in *client_addr) {
    for (int i = 0; i < client_count; i++) {
        if (clients[i].address.sin_addr.s_addr == client_addr->sin_addr.s_addr &&
            clients[i].address.sin_port == client_addr->sin_port) {
            return i;
        }
    }
    return -1;
}

void list_users() {
    sem_wait(&client_sem);
    printf("List of connected clients:\n");
    for (int i = 0; i < client_count; i++) {
        if (clients[i].active) {
            printf("Client %d - IP: %s, Port: %d\n", clients[i].id,
                   inet_ntoa(clients[i].address.sin_addr), ntohs(clients[i].address.sin_port));
        }
    }
    sem_post(&client_sem);
}

void broadcast(int sockfd, char *message) {
    sem_wait(&client_sem);
    for (int i = 0; i < client_count; i++) {
        if (clients[i].active) {
            sendto(sockfd, message, strlen(message), 0, (struct sockaddr *)&clients[i].address, sizeof(clients[i].address));
        }
    }
    sem_post(&client_sem);
}

void kill_client(int client_id) {
    sem_wait(&client_sem);
    if (client_id >= 1 && client_id <= client_count && clients[client_id - 1].active) {
        clients[client_id - 1].active = 0;
        printf("Client %d has been disconnected.\n", client_id);
    } else {
        printf("Invalid client ID.\n");
    }
    sem_post(&client_sem);
}

void *server_shell(void *arg) {
    int sockfd = *((int *)arg);
    char command[BUFFER_SIZE];

    printf("Server Commands:\n");
    printf("  - list users\n");
    printf("  - broadcast <message>\n");
    printf("  - kill <client_id>\n");
    printf("\n");

    while (1) {
        printf("server> ");
        fgets(command, BUFFER_SIZE, stdin);
        command[strcspn(command, "\n")] = 0; // Remove the newline character

        if (strncmp(command, "list users", 10) == 0) {
            list_users();
        } else if (strncmp(command, "broadcast ", 10) == 0) {
            broadcast(sockfd, command + 10);
        } else if (strncmp(command, "kill ", 5) == 0) {
            int client_id = atoi(command + 5);
            kill_client(client_id);
        } else {
            printf("Unknown command: %s\n", command);
        }
    }

    return NULL;
}

void handle_client(int sockfd, struct sockaddr_in *client_addr, socklen_t len, char *buffer) {
    sem_wait(&client_sem);
    int client_index = find_client(client_addr);
    if (client_index == -1) {
        add_client(client_addr);
        client_index = client_count - 1;
        printf("New client connected: Client %d\n", clients[client_index].id);
    }
    sem_post(&client_sem);

    if (!clients[client_index].active) {
        return;
    }

    printf("Received request from Client %d: %s\n", clients[client_index].id, buffer);

    // Respond back to the client
    char response[BUFFER_SIZE];
    snprintf(response, BUFFER_SIZE, "Server: %s request from Client %d received", buffer, clients[client_index].id);
    sendto(sockfd, response, strlen(response), 0, (struct sockaddr *)client_addr, len);
}

int main(int argc, char *argv[]) {
    if (argc != 2 || strcmp(argv[1], "dataserverconsole") != 0) {
        fprintf(stderr, "Usage: %s dataserverconsole\n", argv[0]);
        exit(EXIT_FAILURE);
    }

    int sockfd;
    char buffer[BUFFER_SIZE];
    struct sockaddr_in server_addr, client_addr;
    socklen_t len;

    printf("Server is starting...\n");

    if ((sockfd = socket(AF_INET, SOCK_DGRAM, 0)) < 0) {
        perror("Socket creation failed");
        exit(EXIT_FAILURE);
    }

    memset(&server_addr, 0, sizeof(server_addr));
    memset(&client_addr, 0, sizeof(client_addr));

    server_addr.sin_family = AF_INET;
    server_addr.sin_addr.s_addr = INADDR_ANY;
    server_addr.sin_port = htons(PORT);

    if (bind(sockfd, (const struct sockaddr *)&server_addr, sizeof(server_addr)) < 0) {
        perror("Bind failed");
        close(sockfd);
        exit(EXIT_FAILURE);
    }

    sem_init(&client_sem, 0, 1); // Binary semaphore for client operations
    sem_init(&rw_sem, 0, 1);     // Binary semaphore for read-write synchronization

    pthread_t shell_thread;
    pthread_create(&shell_thread, NULL, server_shell, &sockfd);

    while (1) {
        len = sizeof(client_addr);
        int n = recvfrom(sockfd, buffer, BUFFER_SIZE, 0, (struct sockaddr *)&client_addr, &len);
        buffer[n] = '\0';
        handle_client(sockfd, &client_addr, len, buffer);
    }

    close(sockfd);
    sem_destroy(&client_sem);
    sem_destroy(&rw_sem);
    return 0;
}