#include <stdio.h>
#include <pthread.h>
#include<stdlib.h>
 
 
#define FILENAME "sri.txt"
 
pthread_mutex_t m = PTHREAD_MUTEX_INITIALIZER;
FILE *file;
char buffer[100];
 
 
void *writeFile(void *param)
{
   fseek(file,0,SEEK_SET);
   //fgets(buffer,100,file);
   //printf("The content on the buffer is : %s",buffer);
   pthread_mutex_lock(&m);
   fprintf(file,"hey there hellwo all \n");
   pthread_mutex_unlock(&m);

 
   return NULL;
}
 
 
void *readFile(void *param)
{
    fseek(file,0,SEEK_SET);
   fgets(buffer,100,file);
   pthread_mutex_lock(&m);
   printf("The content on the buffer is : %s",buffer);
    pthread_mutex_unlock(&m);
   return NULL;
 
 
}
 
int main()
{
     file=fopen(FILENAME,"w+");
    if(file==NULL)
    {
        printf("error opening the fule ");
        exit(1);
    }
    if(feof(file)){
        printf("End - of the file reached\n");
    }
    else{
        printf("file opend in w+ mode /n");
    }
 
   
    pthread_t tid1,tid2;

    pthread_create(&tid2,NULL,writeFile,NULL);
    pthread_create(&tid1,NULL,readFile,NULL);
    pthread_join(tid1,NULL);
    pthread_join(tid2,NULL);
 
 
 
  
}