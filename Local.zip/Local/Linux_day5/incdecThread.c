#include <stdio.h>
#include <pthread.h>

pthread_mutex_t mutex = PTHREAD_MUTEX_INITIALIZER;
int a = 0;
int b = 0;

void *increment_counter(void *arg) {
    for (int i = 0; i < 1000; ++i) {
        pthread_mutex_lock(&mutex); // Lock the mutex before accessing the critical section
        a++;
        pthread_mutex_unlock(&mutex); // Unlock the mutex after accessing the critical section
    }
    pthread_exit(NULL);
}

void *decrement_counter(void *arg) {
    for (int i = 0; i < 1000; ++i) {
        pthread_mutex_lock(&mutex); // Lock the mutex before accessing the critical section
        b--;
        pthread_mutex_unlock(&mutex); // Unlock the mutex after accessing the critical section
    }
    pthread_exit(NULL);
}

int main() {
    pthread_t thread1, thread2;
    
    pthread_create(&thread1, NULL, increment_counter, NULL);
    pthread_create(&thread2, NULL, decrement_counter, NULL);
    
    pthread_join(thread1, NULL);
    pthread_join(thread2, NULL);
    
    printf("Value of a: ", a);
    printf("Value of b: ", b);

    
    return 0;
}