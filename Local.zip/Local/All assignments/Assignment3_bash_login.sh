#!/bin/bash

login_file="/var/log/auth.log"

output_file="login_attempts.txt"

#using grep, sed and awk

grep "sshd. *failed" "$login_file" | sed -E 's/. *sshd. *failed password for ([^]+) from ([^]+) port [0-9]+ ssh2/\1 from \2/' | awk '{print "user:", $1, "IP:", $4, "error:", $5" "$6" "$7" "$8" "$9}' > "$output_file"

echo "login attempts and error messages extracted to $output_file"

