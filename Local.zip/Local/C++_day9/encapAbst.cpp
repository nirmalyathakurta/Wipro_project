#include <bits/stdc++.h>
using namespace std;

class Vehicle {
    public:
        void display(int speed) {
            cout<<"Speed: "<<speed<<"km/h"<<endl;
        }
};

class Brake {
    public:
        void applyBrake(int &speed) {
            if(speed >= 10) {
                speed -= 10;
                cout<<"Break applied. Current speed is: "<<speed<<"km/h"<<endl;
            }
            else {
                cout<<"Speed is low"<<endl;
            }
        }
};

class Accelerate {
    public:
        void start() {
            cout<<"Accelerating"<<endl;
        }
        
        void stop() {
            cout<<"Decelereting"<<endl;
    }

};

class Clutch { 
    protected:
        bool isClutchEngaged;
    
    public:
        Clutch(): isClutchEngaged(false) {}

        void engageClutch() {
            isClutchEngaged = true;
            cout<<"Clutch engaged"<<endl;
        }

        void disengageClutch() {
            isClutchEngaged = false;
            cout<<"Clutch disengaged"<<endl;
        }

};

class Gear: public Clutch {
    protected:
        int gear;
    public:
        Gear(): gear(0) {}

        void changeGear(int newGear) {
            gear = newGear;
            cout<<"Gear changed to: "<< gear << endl;
        }
};

class Park {
    public:
        void checkPark(int speed) {
            if(speed == 0) {
                cout<<"Vehicle is parked"<<endl;
            }
            else {
                cout<<"Vehicle is not parked"<<endl<<"Speed: "<<speed<< "km/h"<<endl;
            }
        }
};

int main() {
    Vehicle v;
    Brake br;
    Accelerate acc;
    Gear g;
    Park p;

    int speed = 30;

    v.display(speed);

    br.applyBrake(speed);

    v.display(speed);

    acc.start();

    g.engageClutch();
    g.changeGear(2);
    g.disengageClutch();

    speed+= 20;

    v.display(speed);

    br.applyBrake(speed);

    v.display(speed);

    acc.stop();

    g.engageClutch();
    g.changeGear(1);
    g.disengageClutch();

    speed -= 10;

    v.display(speed);

    p.checkPark(speed);

    return 0;

}

