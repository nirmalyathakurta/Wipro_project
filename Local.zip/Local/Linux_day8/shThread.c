// create a program which has three threads
// 1) read a shared memory
// 2) write to shared memory
// 3) to write the read data into a file

// use semaphore to sync up the threads
// b) anoother program having 2 threads
// 1) read the file from program 1 and scaleee the data comming in
// 2)thread 2 to calculate the average of values every minuuuuuutes and store it in  a data strututre 
// struct {
//     avgvalue
//     timestamp
// };


// global variable shread memory
// semaphores for read write file
//function for reader thread
//function to writer thread
//function to file writer thread
// in main function
// initialised semaphores
// create threads
// joins threads
// destroy semaphores


#include<stdio.h>
#include<stdlib.h>
#include<pthread.h>
#include<semaphore.h>
#include<unistd.h>
#include<string.h>

#define BUFFER_SIZE 1024
#define FILENAME "output.txt"

char shared_memory[BUFFER_SIZE];
sem_t sem_read,sem_write,sem_file;

//function for reader thread
void *reader(void *arg){
    while(1){
        sem_wait(&sem_read); // wait for semaphore to indicate read  permission
        printf("reading from shared memory : %s\n",shared_memory);
        sem_post(&sem_write); // read is done
        sleep(2);
    }
    return NULL;
}

//function to writer thread
void *writer(void *arg){
     while(1){
        sem_wait(&sem_write); // wait for semaphore to indicate write permission
        float ran=rand()%100;
         sprintf(shared_memory , "%.2f",ran);
       // printf("data written by thread ");
        printf("writing from shared memory : %s\n",shared_memory);
        sem_post(&sem_file); // ready for writing in file
        sleep(2);
    }
    return NULL;

}

// function to file writer thread
void *file_writer(void *arg){
   while(1){
    sem_wait(&sem_file); //data is ready for writing
    // file opertaion
    FILE *fp =fopen(FILENAME,"a"); //opeing file
    if(fp == NULL){
        printf("error opening file");
        exit(EXIT_FAILURE);
    } 
    fprintf(fp, "%s\n", shared_memory);
    fclose(fp);
    printf("writing to file: %s\n", shared_memory);

    sem_post(&sem_read);
    sleep(2);
   }
   return NULL;
}

int main() {
    // Initialize semaphores
    sem_init(&sem_read, 0, 0);
    sem_init(&sem_write, 0, 1); 
    sem_init(&sem_file, 0, 0); 

    // Create threads
    pthread_t reader_thread, writer_thread, file_writer_thread;
    pthread_create(&reader_thread, NULL, reader, NULL); 
    pthread_create(&writer_thread, NULL, writer, NULL); 
    pthread_create(&file_writer_thread, NULL, file_writer, NULL); 

    // Join threads 
    pthread_join(reader_thread, NULL); 
    pthread_join(writer_thread, NULL); 
    pthread_join(file_writer_thread, NULL); 

    // Destroy semaphores
    sem_destroy(&sem_read); 
    sem_destroy(&sem_write); 
    sem_destroy(&sem_file); 

    return 0;
}