#include <bits/stdc++.h>
using namespace std;

struct weatherStructure {
    string date;
    string location;
    string temperature;
    
};


class WeatherData {
private:
    queue<weatherStructure> que;

public:
    void insertData(const string& date, const string& location, const string& temperature) {
        weatherStructure newData;
        newData.date = date;
        newData.location = location;
        newData.temperature = temperature;
        que.push(newData);
    }

    
    void printData() const {
        queue<weatherStructure> temp = que;
        while (!temp.empty()) {
            weatherStructure data = temp.front();
            cout << "Date: " << data.date << ", Location: " << data.location << ", Temperature: " << data.temperature << endl;
            temp.pop();
        }
    }

    
    void searchData(const string& location) {
        queue<weatherStructure> temp;
        bool found = false;
        while (!que.empty()) {
            weatherStructure data = que.front();
            if (data.location == location) {
                cout << "Date: " << data.date << ", Temperature: " << data.temperature << endl;
                found = true;
            }
            temp.push(data);
            que.pop();
        }
        if (!found) {
            cout << "No data found for location: " << location << endl;
        }
        que = temp;
    }

    void deleteData(const string& location) {
        queue<weatherStructure> temp;
        while (!que.empty()) {
            weatherStructure data = que.front();
            if (data.location != location) {
                temp.push(data);
            }
            que.pop();
        }
        que = temp;
        cout << "Data for location " << location << " deleted successfully" << endl;
    }
};

int main() {
    WeatherData weatherData;
    cout << "Enter weather data:\n";
    for (int i = 0; i < 2; ++i) {
        string date;
        string location;
        string temperature;

        cout << "Date " << i + 1 << " (YYYY-MM-DD): ";
        getline(cin, date);
        
        cout << "Location " << i + 1<< ": ";
        getline(cin, location);
        
        cout << "Temperature " << i + 1 << ": ";
        getline(cin, temperature);       

        weatherData.insertData(date, location, temperature);
    }

    cout << "Weather data entered:\n";
    weatherData.printData();

    char searchLocation[20];
    cout << "Enter location to search: ";
    cin >> searchLocation;
    cout << "Weather data for " << searchLocation << " location:\n";
    weatherData.searchData(searchLocation);

    char deleteLocation[20];
    cout << "Enter location to delete: ";
    cin >> deleteLocation;
    weatherData.deleteData(deleteLocation);

    cout << "Remaining weather data:\n";
    weatherData.printData();

    return 0;
}