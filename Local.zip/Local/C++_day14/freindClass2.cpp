#include <bits/stdc++.h>

using namespace std;
 
class tc; // Forward declaration of class tc
 
class myclass {

    private:
        int x;

    protected:
        int y;

    public:
        myclass() {

            func(); // Calling func() in constructor
        }

        void func() {
            x=11;

            y=12;
        }

    friend void myfunc(myclass &mfrnd);

    friend void myfunc(tc &mfrnd); // Declaring myfunc as friend to tc

};
 
class tc {

    private:
        int x;

    protected:
        int y;

        friend void myfunc(myclass &mfrnd); // Declaring myfunc as friend to myclass

        friend void myfunc(tc &mfrnd);

};
 
void myfunc(myclass &mfrnd) {

    cout<<"X value in myclass is "<<mfrnd.x<<endl;

    cout<<"Y value in myclass is "<<mfrnd.y<<endl;

}
 
void myfunc(tc &mfrnd) {

    cout<<"X value in tc is "<<mfrnd.x<<endl;

    cout<<"Y value in tc is "<<mfrnd.y<<endl;

}
 
int main() {

    myclass mc;

    tc mtc;

    myfunc(mc); // Calling myfunc with mc object

    myfunc(mtc); // Calling myfunc with mtc object

    return 0;

}
