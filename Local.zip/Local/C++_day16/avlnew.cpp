#include<iostream>

#include<cstdio>

#include<sstream>

#include<algorithm>

#define pow2(n) (1 << (n))

using namespace std;

struct avl//node declaration

{

    int d;

    struct avl* l;

    struct avl* r;

}*r;

class mavl_tree

{

public://declare functions

    int height(avl*);

    int difference(avl*);

    avl* rr_rotat(avl*);

    avl* ll_rotat(avl*);

    avl* lr_rotat(avl*);

    avl* rl_rotat(avl*);

    avl* balance(avl*);

    avl* insert(avl*, int);

    void printtree(avl*, int);

    void inorder(avl*);

    void preorder(avl*);

    void postorder(avl*);

    mavl_tree()

    {

        r = NULL;

    }

};

int mavl_tree::height(avl* t)

{

    int h = 0;

    if (t != NULL)

    {

        int l_height = height(t->l);

        int r_height = height(t->r);

        int max_height = max(l_height, r_height);

        h = max_height + 1;

    }

    return h;

}

int mavl_tree::difference(avl* t)//calculte difference between left and right tree

{

    int l_height = height(t->l);

    int r_height = height(t->r);

    int b_factor = l_height - r_height;

    return b_factor;

}

avl* mavl_tree::rr_rotat(avl* parent)//right right rotation

{

    avl* t;

    t = parent->r;

    parent->r = t->l;

    t->l = parent;

    cout << "Right-Right Rotation";

    return t;

}

avl* mavl_tree::ll_rotat(avl* parent)//left left rotation

{

    avl* t;

    t = parent->l;

    parent->l = t->r;

    t->r = parent;

    cout << "Left-Left Rotation";

    return t;

}

avl* mavl_tree::lr_rotat(avl* parent)//left right rotation

{

    avl* t;

    t = parent->l;

    parent->l = rr_rotat(t);

    cout << "Left-Right Rotation";

    return ll_rotat(parent);

}

avl* mavl_tree::rl_rotat(avl* parent)//right left rotation

{

    avl* t;

    t = parent->r;

    parent->r = ll_rotat(t);

    cout << "Right-Left Rotation";

    return rr_rotat(parent);

}

avl* mavl_tree::balance(avl* t)

{

    int bal_factor = difference(t);

    if (bal_factor > 1)

    {

        if (difference(t->l) > 0)

            t = ll_rotat(t);

        else

            t = lr_rotat(t);

    }

    else if (bal_factor < -1)

    {

        if (difference(t->r) > 0)

            t = rl_rotat(t);

        else

            t = rr_rotat(t);

    }

    return t;

}

avl* mavl_tree::insert(avl* r, int v)

{

    if (r == NULL)

    {

        r = new avl;

        r->d = v;

        r->l = NULL;

        r->r = NULL;

        return r;

    }

    else if (v < r->d)

    {

        r->l = insert(r->l, v);

        r = balance(r);

    }

    else if (v >= r->d)

    {

        r->r = insert(r->r, v);

        r = balance(r);

    }

    return r;

}

void mavl_tree::printtree(avl* p, int l)//show the tree

{

    int i;

   

    if (p != NULL)

    {

 

        printtree(p->r, l + 1);

        cout << " ";

        if (p == r)

            cout << "Root -> ";

        for (i = 0; i < l && p != r; i++)

            cout << " ";

        cout << p->d;

        printtree(p->l, l + 1);

    }

}

void mavl_tree::inorder(avl* t)

{

    if (t == NULL)

        return;

    inorder(t->l);

    cout << t->d << " ";

    inorder(t->r);

}

void mavl_tree::preorder(avl* t)

{

    if (t == NULL)

        return;

    cout << t->d << " ";

    preorder(t->l);

    preorder(t->r);

}

void mavl_tree::postorder(avl* t)

{

    if (t == NULL)

        return;

    postorder(t->l);

    postorder(t->r);

    cout << t->d << " ";

}

int main()

{

    int c, i;

    mavl_tree avl;

    while (1)

    {

        cout << "Tree Creation Options\n";

        cout << "=====================\n";

        cout << "1.Add tree node" << endl;

        cout << "2.Print Balanced AVL Tree" << endl;

 

        cout << "Tree Navigation Options\n";

        cout << "=======================\n";

 

        cout << "3.InOrder traversal" << endl;

        cout << "4.PreOrder traversal" << endl;

        cout << "5.PostOrder traversal" << endl;

        cout << "6.Exit" << endl;

        cout << "Enter your Choice: ";

        cin >> c;

        switch (c) 

        {

           case 1:

              cout << "Enter value to be inserted: ";

              cin >> i;

              r = avl.insert(r, i);

              break;

           case 2:

              if (r == NULL)

              {

                 cout << "Tree is Empty" << endl;

                 continue;

              }

                 cout << "Balanced AVL Tree:" << endl;

                 cout << "===============\nPrinting Tree Begin\n================\n";

                 avl.printtree(r, 1);

                 cout << endl;

                 cout << "===============\nPrinting Tree End\n================\n";

                 break;

           case 3:

              cout << "Inorder Traversal:" << endl;

              avl.inorder(r);

              cout << endl;

              break;

           case 4:

              cout << "Preorder Traversal:" << endl;

              avl.preorder(r);

              cout << endl;

              break;

           case 5:

              cout << "Postorder Traversal:" << endl;

              avl.postorder(r);

              cout << endl;

              break;

           case 6:

              exit(1);

              break;

           default:

              cout << "Wrong Choice" << endl;

        }

    }

    return 0;

}