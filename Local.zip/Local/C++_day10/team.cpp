#include <bits/stdc++.h>
using namespace std;

class ScoreCard {
public:
    virtual void display() {} 
};

// Derived class for a player
class Player : public ScoreCard {
protected:
    string name;
    string weapon;
    int score;

public:
    Player(const string& playerName, const string& playerWeapon) : name(playerName), weapon(playerWeapon), score(0) {}

    void setScore(int playerScore) {
        score = playerScore;
    }
    int getScore() {
        return score;
    }

    void display() {
        cout << "Player: " << name << ", Weapon: " << weapon << ", Score: " << score << endl;
    }
};

// Derived class for a team
class Team : public ScoreCard {
private:
    string teamName;
    Player* players[5]; 
    int numPlayers;
    int teamScore;

public:
    Team(const string& name) : teamName(name), numPlayers(0), teamScore(0) {}

    void addPlayer(Player* player) {
        if(numPlayers < 5) {
            players[numPlayers++] = player;
        }
    }

    void updateTeamScore() {
        teamScore = 0;
        for(int i = 0; i < numPlayers; ++i) {
            teamScore += players[i]->getScore();
        }
    }

    void display() {
        cout << "Team: " << teamName << ", Team Score: " << teamScore <<endl;
    }
};

int main() {
    
    Player* p1 = new Player("Sunny", "Gun");
    Player* p2 = new Player("Priya", "Sword");
    Player* p3 = new Player("Elvish Presly", "Guitar");

    Team t1("Team A");
    Team t2("Team B");

    t1.addPlayer(p1);
    t1.addPlayer(p2);
    t2.addPlayer(p3);

    p1->setScore(10);
    p2->setScore(20);
    p3->setScore(15);

    t1.updateTeamScore();
    t2.updateTeamScore();

    ScoreCard* scoreCards[5] = {p1, p2, p3, &t1, &t2};
    for(int i = 0; i < 5; ++i) {
        scoreCards[i]->display();
    }

    delete p1;
    delete p2;
    delete p3;

    return 0;
}