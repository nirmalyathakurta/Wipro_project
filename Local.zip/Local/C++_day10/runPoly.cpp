#include <bits/stdc++.h>
using namespace std;
 
class Lifeform {
public:
    int legs, teeth, eyes, nose, ears;
    char breather, eat;
 
    virtual void sound() {
        cout << "Animal sound here" << endl;
    };
 
  virtual  void food() {
        cout << "Food type" << endl;
    }
 
   virtual   void habitat() {
        cout << "Dwelling type" << endl;
    }
 
    void breathe(){
        cout << "Breathe Air";
    }
};
 
class Cat {
public:
   virtual void sound()  {
        cout << "meow" << endl;
    }
 
   virtual void food()  {
        cout << "The cat is milk drink" << endl;
    }
 
  virtual  void habitat()  {
        cout << "Lives anywhere" << endl;
    }
     void breathe(){
        cout << "Breathe Air";
    }
};
 
class Fish : public Lifeform {
public:
    void sound()  {
        cout << "bubbles" << endl;
    }
 
    void food()  {
        cout << "Plankton to other fishes" << endl;
    }
 
    void habitat()  {
        cout << "Lives in water" << endl;
    }
     void breathe(){
        cout << "Breathe Air";
    }
};
 
class tiger: public Lifeform, public Cat{
    public:
    void sound()  {
        cout << "Roar" << endl;
    }
 
    void food()  {
        cout << "Non Veg" << endl;
    }
 
    void habitat()  {
        cout << "Lives in jungle" << endl;
    }
     void breathe(){
        cout << "Breathe jungle air";
    }
};
 
int main() {
 
    //runtime polymorphism with multiple inheritance
tiger t;
Lifeform* lf=&t;
lf->sound();  //compile time binding.
lf->food();   //virtual function of lifeform runtime polymorphism.all virtual functions
lf->habitat();
lf->breathe();
Cat* cat=&t; // this also becomes rtp.
cat->breathe(); // this becomes rtp
cat->habitat(); //virtual functions
 
   
    return 0;
}