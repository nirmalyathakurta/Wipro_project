#include <bits/stdc++.h>
using namespace std;
 
 
 
class lifeform {
public:
    int legs,teeth,eyes,nose,ears;
    char inhale, eat;
 
 
    virtual void sound() {
        cout<< "Animal sound here";
    }
 
    virtual void food() {cout<< "Food type ";}
    virtual void habitat() {cout<< "Dwelling type";}
    virtual void breathe() {cout<<"Breathe";}
};
 //base class
class cat : lifeform {
    public:
        void sound() { cout<< "meow" ;}
        void food() {
            cout<< "The cat is meat eater";
        }
        void breathe() {cout<<"Breathe air";}
        void habitat(){ cout<< "Lives anywhere  "; }
};
class fish : lifeform {
    public:
        void sound() { cout<< "bubbles" ;}
        void food() { cout<< "Plankton to Other fishes";}
        void habitat() { cout<< "Lives  in water "; }
        void breathe() {cout<<"Breathe air";}
};
 
 
int main() {
    lifeform* lf= new cat();
    lf->sound();
    lf->breathe();
    lf->food();
}