#include <bits/stdc++.h>
using namespace std;

class Printer {
public:
    virtual void print() const {};
};

class DotMatrixPrinter : public Printer {
public:
    void print() const {
        std::cout << "Printing using Dot Matrix printer." << std::endl;
    }
};

class InkjetPrinter : public Printer {
public:
    void print() const {
        std::cout << "Printing using Inkjet printer." << std::endl;
    }
};

class LaserJetPrinter : public Printer {
public:
    void print() const {
        std::cout << "Printing using LaserJet printer." << std::endl;
    }
};

class ThreeDPrinter : public Printer {
public:
    void print() const {
        std::cout << "Printing using 3D printer." << std::endl;
    }
};

/*void printWithPrinter(const Printer& printer) {
    printer.print();
}*/

int main() {
    DotMatrixPrinter dotMatrix;
    InkjetPrinter inkjet;
    LaserJetPrinter laserJet;
    ThreeDPrinter threeDPrinter;

    Printer* printer;

    printer=&dotMatrix;
    printer->print();

    printer=&inkjet;
    printer->print();

    printer=&laserJet;
    printer->print();

    printer=&threeDPrinter;
    printer->print();

    return 0;
}