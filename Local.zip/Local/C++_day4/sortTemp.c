//bubble sort on double linked list which means sort my temp or data
//take parametre as temp and data for sorting

//make a function bubble sort pass weatherdata
//take input 

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#define NUM_DAYS 10
#define MAX_DATE_LENGTH 11
#define MAX_LOCATION_LENGTH 20
typedef struct WeatherData {
	char date[MAX_DATE_LENGTH];
	char location[MAX_LOCATION_LENGTH];
	char temperature[3];
	struct WeatherData *prev; 
    struct WeatherData * next;
} WeatherData;
// function prototype
WeatherData* createNode(char date[], char location[], char temperature[]);
void insertNode(WeatherData** head, char date[], char location[], char temperature[]);
void search_location(WeatherData* head, char location[]);
void delete_location(WeatherData** head, char location[]);
void print_data(WeatherData* head);
void saveToFile(WeatherData* head, char fileName[]);
void readFileToList(WeatherData** head, char fileName[]);
void editData(WeatherData* head,char location[]);
void bubbleSort(WeatherData** head,int sortlocation);
 
 
int main() {

    WeatherData* head=NULL;
    char fileName[]="weather_data.txt";
    readFileToList(&head ,fileName);
 
    int choice;
    char location[MAX_LOCATION_LENGTH]; 
    do {
        printf("\n enter weather data\n");
        printf("1.add data \n ");
        printf("2.remove data\n");
        printf("3.search data\n");
        printf("4.edit data\n");
        printf("5.save data\n");
        printf("6.Bubble Sorting Location \n");
        printf("7.Bubble Sorting TEmperature \n");
        printf("8.exit\n");
        printf("ENTER YOUR CHOICE\n");
        scanf("%d",&choice);

        switch (choice) {
            case 1: {
                char date[MAX_DATE_LENGTH];
                char temperature[3];
                printf("enter date (YYYY-MM-DD) \n");
                scanf("%s",date);
                printf("enter location \n");
                scanf("%s",location);
                printf("enter temperature\n");
                scanf("%s",temperature);
                insertNode(&head,date,location,temperature);
                break;
            }
 
            case 2: {
                printf("enter the location to delete");
                scanf("%s",location);
                delete_location(&head,location);
                break;
            }      
            case 3: {  
                printf("enter location to search");
                scanf("%s",location);
                search_location(head,location);
                break;
            }
 
            case 4: {
                printf("enter location to edit");
                scanf("%s",location);
                editData(head,location);
                break;
            }
 
            case 5: {
                saveToFile(head ,fileName);
                break;
            }
 
            case 6: {
                bubbleSort(&head,1); //sort by location
                print_data(head); //print sorted location
                break;
            }
            case 7: {
                bubbleSort(&head,0); //sort by temperature
                print_data(head); //print sorted temperature
                break;
            }
            case 8: {
                printf("exiting\n");
                break;
            }
            default:
                printf("invalid choice\n");
        }
    } while(choice!=8);

    WeatherData* curr = head;
    while(curr!=NULL) {
        WeatherData* temp=curr;
        curr = curr->next;
        free(temp);
    }
    return 0;
}
 
 
WeatherData* createNode(char date[], char location[], char temperature[]) {
    WeatherData* newNode = (WeatherData*)malloc(sizeof(WeatherData));
    if(newNode== NULL) {
        printf("Memory allocation failed");
        exit(EXIT_FAILURE);
    }
    strcpy(newNode->date,date);
    strcpy(newNode->location,location);
    strcpy(newNode->temperature,temperature);
    newNode->prev=NULL;
    newNode->next =NULL;
    return newNode;
}
 
void insertNode(WeatherData** head, char date[], char location[], char temperature[]) {
    WeatherData* newNode = createNode(date, location, temperature);
    if(*head == NULL) {
        *head = newNode;
        return;
    }
    WeatherData *curr = *head;
    while (curr->next!= NULL) {
        curr = curr->next;
    }
    curr->next = newNode;
    newNode->prev=curr;
}
 
void search_location(WeatherData* head, char location[]) {
    WeatherData* curr= head;
    int found =0;
    
    while(curr!= NULL) {
        if(strcmp(location, curr->location)==0) {
            printf("Date: %s, Temperature: %s\n", curr->date, curr->temperature);
            found=1;
        }
        curr= curr->next;
    }

    if(!found) {
        printf("no data found");
    }
}
 
void delete_location(WeatherData** head, char location[]) {
    WeatherData* curr=*head;
    while(curr!=NULL){
    	if(strcmp(location,curr->location)==0) {
    		if(curr->prev==NULL){
    			*head=curr->next;
			}
			else {
				curr->prev=curr->next;
			}
			if(curr->next!=NULL) {
				curr->next=curr->prev;
			}
			free(curr);
			printf("%s Deleted successfully",location);
            return;
		}
		curr=curr->next;
	}
    printf("no data found for that location %s\n",location);
}
 
 
void print_data(WeatherData* head) {
    WeatherData* curr = head;
    printf("weather data\n");
    while (curr!= NULL) {
        printf("Date: %s, location: %s, Temperature: %s\n", curr->date, curr->location, curr->temperature);
        curr= curr->next;
    }
}
 
 
void saveToFile(WeatherData* head, char fileName[]) {
    FILE* file=fopen(fileName,"w");
    if(file==NULL) {
        printf("error in opening file\n");
        return;
 
    }
    WeatherData* curr = head;
    while(curr!=NULL) {
        fprintf(file,"%s %s %s\n",curr->date ,curr->location,curr->temperature);
        curr = curr->next;
    }
    fclose(file);
 
    printf("data saved to FILE %s\n", fileName);
}
 
void readFileToList(WeatherData** head, char fileName[]) {
    FILE* file=fopen(fileName ,"r");
    if(file==NULL) {
        printf("file does not exist creating new file %s\n",fileName);
        file=fopen(fileName,"w");
        if(file==NULL) {
            printf("error creating in file %s\n",fileName);
            return;
        }
        fclose(file);
        return;
    }
    fclose(file);
    file=fopen(fileName ,"r");
    char date[MAX_DATE_LENGTH];
    char location[MAX_LOCATION_LENGTH];
    char temperature[3];
 
    while(fscanf(file, "%s %s %s\n",date ,location,temperature)!=EOF) {
        insertNode(head,date,location,temperature);
    }
    fclose(file);
    printf("data is loaded to file\n");
}
 
void editData(WeatherData* head,char location[]) {
    WeatherData* curr = head;
    char newTemperature[3];
    int found =0;
    printf("enter new temperature for location %s\n",location);
    scanf("%s",newTemperature);
 
    while(curr!=NULL) {
        if(strcmp(location,curr->location)==0) {
            strcpy(curr->temperature,newTemperature);
            printf(" edited data for location succusfully %s\n ",location);
            found=1;
            break;
        }
        curr=curr->next;
    }
 
    if(!found) {
        printf("no data found found for that location %s /n" ,location);
    }
 
}

void bubbleSort(WeatherData** head,int sortlocation) {
    
    //printf("%s",head->temperature);
    int swap;
    WeatherData *ptr1;
    WeatherData *ptr2;

    //checking for empty list
    if(*head==NULL) {
        return;
    }
    ptr2=NULL;

    do {
        swap=0;
        ptr1=*head;

            
        while(ptr1->next!=ptr2) {
            //compared node based on sorting choice
            int cmp=0;
           if(sortlocation) {
                cmp=strcmp(ptr1->location,ptr1->next->location); 
            }
            else {
                cmp=strcmp(ptr1->temperature,ptr1->next->temperature); 
            }
            if(cmp>0) {
                WeatherData *temp=ptr1->next;      //swapping the data if needed
                ptr1->next=temp->next;
                if(ptr1->next!=NULL) {
                    ptr1->next->prev=ptr1;
                }
                temp->prev=ptr1->prev;
                temp->next=ptr1;
                if(temp->prev==NULL) {
                    temp->prev->next=temp;
                }
                else {
                    *head=temp;
                }
                ptr1->prev=temp;
                swap=1;
            } 
            else {
                ptr1=ptr1->next;
            }

        }
        ptr2=ptr1; //move ptr2 to lats sorted node 
    } while(swap);
        
}

