#include <stdio.h>
#include <stdlib.h>
#include <time.h>  // for rand() (used for computer moves)

#define BOARD_SIZE 3

// Structure to represent a Tic Tac Toe cell
typedef struct {
    char value;  // 'X', 'O', or empty (' ')
} Cell;

// Structure to represent the entire Tic Tac Toe board
typedef struct {
    Cell cells[BOARD_SIZE][BOARD_SIZE];
} Board;

// Function prototypes
void initializeBoard(Board* board);
void displayBoard(Board board);
int checkWin(Board board, char player);
int isFull(Board board);
int getPlayerMove(Board board);
int getComputerMove(Board board);
void play(Board* board);

int main() {
    Board board;

    // Choose game mode (player vs. player or player vs. computer)
    int mode;
    printf("Choose game mode:\n");
    printf("1. Player vs. Player\n");
    printf("2. Player vs. Computer\n");
    printf("Enter your choice: ");
    scanf("%d", &mode);

    while (mode != 1 && mode != 2) {
        printf("Invalid choice. Please enter 1 or 2.\n");
        scanf("%d", &mode);
    }

    initializeBoard(&board);
    play(&board, mode);

    return 0;
}

// Initializes the board with empty cells
void initializeBoard(Board* board) {
    for (int i = 0; i < BOARD_SIZE; i++) {
        for (int j = 0; j < BOARD_SIZE; j++) {
            board->cells[i][j].value = ' ';
        }
    }
}

// Displays the current state of the board
void displayBoard(Board board) {
    printf("\n");
    for (int i = 0; i < BOARD_SIZE; i++) {
        for (int j = 0; j < BOARD_SIZE; j++) {
            printf("| %c ", board.cells[i][j].value);
        }
        printf("|\n");
    }
    printf("\n");
}

// Checks if a player has won (horizontally, vertically, or diagonally)
int checkWin(Board board, char player) {
    // Check rows
    for (int i = 0; i < BOARD_SIZE; i++) {
        int count = 0;
        for (int j = 0; j < BOARD_SIZE; j++) {
            if (board.cells[i][j].value == player) {
                count++;
            } else {
                count = 0;
            }
        }
        if (count == BOARD_SIZE) {
            return 1;
        }
    }

    // Check columns
    for (int j = 0; j < BOARD_SIZE; j++) {
        int count = 0;
        for (int i = 0; i < BOARD_SIZE; i++) {
            if (board.cells[i][j].value == player) {
                count++;
            } else {
                count = 0;
            }
        }
        if (count == BOARD_SIZE) {
            return 1;
        }
    }

    // Check diagonals
    int countDiagonal1 = 0;
    int countDiagonal2 = 0;
    for (int i = 0; i < BOARD_SIZE; i++) {
        if (board.cells[i][i].value == player) {
            countDiagonal1++;
        }
        if (board.cells[i][BOARD_SIZE - i - 1].value == player) {
            countDiagonal2++;
        }
    }
    if (countDiagonal1 == BOARD_SIZE || countDiagonal2 == BOARD_SIZE) {
        return 1;
    }

    return 0;
}

// Checks if the board is full
int isFull(Board board) {
    for (int i = 0; i < BOARD_SIZE; i++) {
        for (int j = 0; j < BOARD_SIZE; j++) {
            if (board.cells[i][j].value == ' ') {
                return 0;
            }
        }
    }
    return 1;
}

// Gets a valid move from the player
int getPlayerMove(Board board) {
    int row, col;
    printf("Enter row and column (0-%d): ", BOARD_SIZE - 1);
    scanf("%d %d", &row, &col);
    while (row < 0 || row >= BOARD_SIZE || col < 0 || col >= BOARD_SIZE || board.cells[row][col].value != ' ') {
        printf("Invalid move. Enter row and column again: ");
        scanf("%d %d", &row, &col);
    }
    return row * BOARD_SIZE + col;
}

// Gets a random valid move from the computer
int getComputerMove(Board board) {
    int move;
    do {
        move = rand() % (BOARD_SIZE * BOARD_SIZE);
    } while (board.cells[move / BOARD_SIZE][move % BOARD_SIZE].value != ' ');
    return move;
}

// Executes the game based on the chosen mode
void play(Board* board, int mode) {
    char currentPlayer = 'X';
    int gameOver = 0;

    while (!gameOver) {
        displayBoard(*board);

        int move;
        if (currentPlayer == 'X' || mode == 1) {
            move = getPlayerMove(*board);
        } else {
            move = getComputerMove(*board);
        }

        board->cells[move / BOARD_SIZE][move % BOARD_SIZE].value = currentPlayer;

        if (checkWin(*board, currentPlayer)) {
            displayBoard(*board);
            printf("Player %c wins!\n", currentPlayer);
            gameOver = 1;
        } else if (isFull(*board)) {
            displayBoard(*board);
            printf("It's a tie!\n");
            gameOver = 1;
        }

        currentPlayer = (currentPlayer == 'X') ? 'O' : 'X';
    }
}
