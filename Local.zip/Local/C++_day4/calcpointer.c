//datastructure add ,sub,mutliplt, and divide
#include<stdio.h>
//Function prototypes
int add(int a,int b);
int sub(int a,int b);
int multi(int a,int b);
int divide(int a,int b);

struct mops{
    int (*add)(int,int);
    int (*sub)(int,int);
    int (*multi)(int,int);
    int (*divide)(int,int);
};

int add(int a,int b)
{
   return a+b;
    //printf("\n Add of %d and %d \n ",x,y,x+y);
}
int sub(int a,int b)
{
   return a-b;
   
}
int multi(int a,int b){
    return a*b;
}
int divide(int a,int b){
    if(b!=0)
    return a/b;
    else{
        printf("Error : Division by zero");
        return 0;
    }
}
int callback(int x,int y,int (*operte)(int,int))
{
    //(*ptr)(); // callback function
    return operte(x,y);
}

int main(){
    int a,b;
    struct mops opert;//={add,sub,multi,divide}
    //printf("Address of struct %p,%p,%p,%p",&opert.add,&opert.sub,&opert.multi,&opert.divide)

    opert.add=&add;
    opert.sub=&sub;
    opert.multi=&multi;
    opert.divide=&divide;

    

    /*printf("Enter your choice\n");
    scanf("%d",&c);*/

    printf("Enter two no : \n");
    scanf("%d %d",&a,&b);
    
   printf("%d %d %d %d", callback(a,b,opert.add),callback(a,b,opert.sub),callback(a,b,opert.multi),callback(a,b,opert.divide));

   /*printf("Add of %d + %d=%d \n",a,b,opert.add(a,b));
    printf("Sub of %d - %d=%d \n",a,b,opert.sub(a,b));
    printf("Multiple of %d * %d=%d \n",a,b,opert.multi(a,b));
    printf("Divide of %d / %d=%d \n ",a,b,opert.divide(a,b));
    */
    /*
    switch(c){
        case 1:  {
                    printf("Add of %d + %d=%d \n",a,b,opert.add(a,b));
                
                break;

        case 2:  printf("Sub of %d - %d=%d \n",a,b,opert.sub(a,b));
                    break;

        case 3: printf("Multiple of %d * %d=%d \n",a,b,opert.multi(a,b));
        break;

        case 4: printf("Divide of %d / %d=%d \n ",a,b,opert.divide(a,b));

        break;

        default: printf("Invalid choice");
        break;
    }
    */
    return 0;

}