#include <bits/stdc++.h>

using namespace std;
 
class vehicle {

private:

    string colour;

    string rcNumber;

    string vinNumber;

    string owner;

    string makeModel;

    int year;
 
public:

    vehicle(const string clr, const string rc, const string vin, const string own, const string mm, int yr) {

        this->colour = const_cast<string&>(clr);

        this->rcNumber = const_cast<string&>(rc);

        this->vinNumber = const_cast<string&>(vin);

        this->owner = const_cast<string&>(own);

        this->makeModel = const_cast<string&>(mm);

        this->year = yr;

    }
 
    

    void setColour(const string clr) {

        colour = const_cast<string&>(clr);

    }
 
    void setRCNumber(const string rc) {

        rcNumber = const_cast<string&>(rc);

    }
 
    void setVINNumber(const string vin) {

        vinNumber = const_cast<string&>(vin);

    }
 
    void setOwner(const string own) {

        owner = const_cast<string&>(own);

    }
 
    void setMakeModel(const string mm) {

        makeModel = const_cast<string&>(mm);

    }
 
    void setYear(int yr) {

        year = yr;

    }
 
 
    string getColour() const {

        return colour;

    }
 
    string getRCNumber() const {

        return rcNumber;

    }
 
    string getVINNumber() const {

        return vinNumber;

    }
 
    string getOwner() const {

        return owner;

    }
 
    string getMakeModel() const {

        return makeModel;

    }
 
    int getYear() const {

        return year;

    }

};
 
int main() {

    vehicle answer("Green", "9090", "XYX233", "Rakesh", "toyota", 2022);
 
    

    cout << "Initialstate:" << endl;

    cout << "colour: " << answer.getColour() << endl;

    cout << "rcnumber: " << answer.getRCNumber() << endl;

    cout << "vinumber: " << answer.getVINNumber() << endl;

    cout << "owner: " << answer.getOwner() << endl;

    cout << "model: " << answer.getMakeModel() << endl;

    cout << "year: " << answer.getYear() << endl;
 
   

    answer.setColour("orange");

    answer.setOwner("prashanth");
 
    

    cout << "\nUpdated State:" << endl;

    cout << "Colour: " << answer.getColour() << endl;

    cout << "Owner: " << answer.getOwner() << endl;
 
    return 0;

}
