#include <iostream>
Using namespace std;

class test {

private :
	int id;

public :
	void myfunc() const {
		const_cast <test *> (this)->id = 6;
	}
 
    int getid() const { return id };
};
 
int main() {

	test tst(2);

	cout << “Id is : “ << tst.getid() << “\n”;

	tst.myfunc();

	cout << id is : “<< tst.getid() << “\n”;

}
 
 
}
