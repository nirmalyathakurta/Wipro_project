#include <bits/stdc++.h>
using namespace std;

int main() {
    int i = 8;
    char j = 'z';

    i = i+j;

    float b = i + 20.0;

    cout<<"i="<<i<<'\n'<<"j="<<j<<'\n'<<"b="<<b<<'\n';
    return 0;
}