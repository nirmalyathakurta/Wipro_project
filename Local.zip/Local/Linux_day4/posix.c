#include <stdio.h>
#include <unistd.h>
#include <stdlib.h>
 
int main() {
printf("POSIX version is set to %ld\n", _POSIX_VERSION);
printf("Your system supports POSIX1003.1c threads,\n");

#ifdef _POSIX_THREAD_PRIORITY_SCHEDULING
    printf("including support for priority scheduling\n");
#else
    printf("but does not support priority scheduling\n");
#endif

//}
exit(EXIT_SUCCESS);
}