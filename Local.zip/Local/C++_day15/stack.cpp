#include <bits/stdc++.h>
using namespace std;

struct weatherStructure {
    string date;
    string location;
    string temperature;
    
    weatherStructure(const string& d, const string& loc, const string& temp): date(d),location(loc), temperature(temp) {}
};


class WeatherData {
private:
    stack<weatherStructure> st;

public:
    void insertData(const string& date, const string& location, const string& temperature) {
       st.emplace(date, location, temperature);
    }

    
    void printData() const {
        stack<weatherStructure> temp = st;
        while (!temp.empty()) {
            weatherStructure data = temp.top();
            cout << "Date: " << data.date << ", Location: " << data.location << ", Temperature: " << data.temperature << endl;
            temp.pop();
        }
    }

    
    void searchData(const string& location) {
        stack<weatherStructure> temp;
        bool found = false;
        while (!st.empty()) {
            weatherStructure data = st.top();
            if (data.location == location) {
                cout << "Date: " << data.date << ", Temperature: " << data.temperature << endl;
                found = true;
            }
            temp.push(data);
            st.pop();
        }
        if (!found) {
            cout << "No data found for location: " << location << endl;
        }
        st = temp;
    }

    void deleteData(const string& location) {
        stack<weatherStructure> temp;
        while (!st.empty()) {
            weatherStructure data = st.top();
            if (data.location != location) {
                temp.push(data);
            }
            st.pop();
        }
        st = temp;
        cout << "Data for location " << location << " deleted successfully" << endl;
    }
};

int main() {
    WeatherData weatherData;
    cout << "Enter weather data:\n";
    for (int i = 0; i < 3; ++i) {
        string date;
        string location;
        string temperature;

        cout << "Date " << i + 1 << " (YYYY-MM-DD): ";
        getline(cin, date);
        
        cout << "Location " << i + 1<< ": ";
        getline(cin, location);
        
        cout << "Temperature " << i + 1 << ": ";
        getline(cin, temperature);       

        weatherData.insertData(date, location, temperature);
    }

    cout << "Weather data entered:\n";
    weatherData.printData();

    string searchLocation;
    cout << "Enter location to search: ";
    cin >> searchLocation;
    cout << "Weather data for " << searchLocation << " location:\n";
    weatherData.searchData(searchLocation);

    string deleteLocation;
    cout << "Enter location to delete: ";
    cin >> deleteLocation;
    weatherData.deleteData(deleteLocation);

    cout << "Remaining weather data:\n";
    weatherData.printData();

    return 0;
}