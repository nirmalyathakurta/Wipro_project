#include <bits/stdc++.h>
using namespace std;

struct node {
  int key;
  struct node *left;
  struct node *right;
};

struct node* newnode(int key) {
    struct node* n = new node;
    n->key=key;
    n->left=NULL;
    n->right=NULL;
    return n;
    
}

// Addnode
struct node* add(struct node* node, int key) {
 
    if(node==NULL) return newnode(key);
    
    if(key < node->key) node->left=add(node->left,key);
    
    else if(key > node->key) node->right=add(node->right,key);
 
    return node;
}

// Find node with key value
struct node* find(struct node* root, int key) {
    
    if(root == NULL || root->key == key) return root;
 
    if(root->key < key) return find(root->right,key);
 
    return  find(root->left,key);
 
}

// Deletion of a node using key value
struct node* deleteNode(struct node* root, int key) {
    if(root == NULL) return root;

    if(key < root->key) {
        root->left = deleteNode(root->left, key);
    }

    else if(key > root->key) {
        root->right = deleteNode(root->right, key);
    }

    else {
        if(root->left == nullptr) {
            struct node* temp = root->right;
            delete root;
            return temp;
        }

        else if(root->right == nullptr) {
            struct node* temp = root->left;
            delete root;
            return temp;
        }

        struct node* temp = root->right;

        while(temp->left != nullptr) temp = temp->left;

        root->key = temp->key;

        root->right = deleteNode(root->right, temp->key);
    }
    
    return root;
}

// Inorder traversal of the tree
void inorder(struct node* root) {
    
    if(root == NULL) return;
    inorder(root->left);
    cout<<root->key<<"  ";
    inorder(root->right);
    
}

// Level order treaversal of tree
void levelorderTraversal(node* root) {
    if(root == nullptr) {
        cout<<"tree is empty."<<endl;
 
    }
 
    queue<node*> q;
    q.push(root);
 
    while(!q.empty()) {
        int size = q.size();
 
        while(size>0) {
            node* node = q.front();
            q.pop();
            cout<<node->key<<" "<<endl;
 
            if(node->left != nullptr) {
                q.push(node->left); 
            }
 
            if(node->right != nullptr) {
                q.push(node->right);
            }
            
            size--;
        }
        
        cout<<endl;
    }
}

int main() {
    
    struct node* root = nullptr;
    
    root=add(root,10);
    add(root,15);
    add(root,20);
    add(root,25);
    add(root,30);

    cout<<"Inorder traversal of BST: "<<endl;
    inorder(root); cout<<endl;
    
    int findKey;

    cout<<"Enter the key value: ";
    cin>>findKey;
    
    struct node* found = find(root, findKey);
    
    if(found) {
        cout<<"Level order traversal before key value: "<<endl;
        levelorderTraversal(root);

        cout<<"Key value: "<<findKey<<" found in BST"<<endl;
        deleteNode(root, findKey);

        cout<<"Key has been deleted"<<endl;
        cout<<"New traversal of BST:"<<endl;
        inorder(root);

        cout<<"\nNew Level Order: "<<endl;
        levelorderTraversal(root);
    } 

    else {  
        cout<<"Key value: "<<findKey<<" not found"<<endl;
        cout<<"New traversal of BST:"<<endl;
        inorder(root);
        levelorderTraversal(root);
    }

    return 0;

}
