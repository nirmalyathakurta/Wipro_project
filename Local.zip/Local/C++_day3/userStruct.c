#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#define NUM_DAYS 10
#define MAX_DATE_LENGTH 11
#define MAX_LOCATION_LENGTH 20
 
typedef struct {
	char date[MAX_DATE_LENGTH];
	char location[MAX_LOCATION_LENGTH];
	char temperature[3];
} WeatherData;
 
void readWeatherData(WeatherData *data) {
	int i;
	printf("enter weather data:\n");
	for( i=0;i<NUM_DAYS;i++){
		printf("Date %d (YYYY-MM-DD): ",i+1);
		scanf("%s",data[i].date);
		printf("Location %d :",i+1);
		scanf("%s",data[i].location);
		printf("Temperature %d:", i+1);
		scanf("%s",data[i].temperature);
 
 
	}
}
 
int main() {
	int i;
    WeatherData weatherData[NUM_DAYS];

/*	 = {
        {"2024-04-01", "Location1", "25"},
        {"2024-04-01", "Location2", "27c"},
        {"2024-04-02", "Location1", "28c"},
        {"2024-04-02", "Location2", "35c"},
        {"2024-04-03", "Location5", "29c"},
        {"2024-04-04", "Location6", "30c"},
        {"2024-04-06", "Location10", "32c"},
        {"2024-04-07", "Location1", "25"},
        {"2024-04-09", "Location3", "36c"},
        {"2024-04-11", "Location1", "27c"}
};*/
    readWeatherData(weatherData);
 
/*
char inputlocation[MAX_LOCATION_LEGNTH];
    char input_location = (char)malloc(MAX_LOCATION_LENGTH * sizeof(char));
    if (input_location == NULL) {
        printf("Memory allocation failed.");
        return 1;
    }
*/
	char inputlocation[MAX_LOCATION_LENGTH];
    printf("Enter the location: ");
    scanf("%s", &inputlocation);
    // Search for the entered location in the array
    int found = 0;
    for ( i = 0; i < NUM_DAYS; i++) {
        if (strcmp(inputlocation, weatherData[i].location) == 0) {
            printf("\nData for %s:\n", inputlocation);
            printf("Date: %s\n", weatherData[i].date);
            printf("Temperature: %s\n", weatherData[i].temperature);
            found = 1;
            break;
        }
    }
	char inputdate[MAX_DATE_LENGTH];
	 printf("Enter the Date: ");
    scanf("%s", inputdate);

    for ( i = 0; i < NUM_DAYS; i++) {
        if (strcmp(inputdate, weatherData[i].date) == 0) {
            printf("\nData for %s:\n", inputdate);
            printf("location: %s\n", weatherData[i].location);
            printf("Temperature: %s\n", weatherData[i].temperature);
            found = 1;
            break;
        }
    }
    char inputtemperature[3];
     printf("Enter the temperature: ");
    scanf("%s", inputdate);
     for ( i = 0; i < NUM_DAYS; i++) {
        if (strcmp(inputtemperature, weatherData[i].temperature) == 0) {
            printf("\nData for %s:\n", inputtemperature);
            printf("Date: %s\n", weatherData[i].date);
            printf("Location: %s\n", weatherData[i].location);
            found = 1;
            break;
        }
    }

for ( i = 0; i < NUM_DAYS; i++) {
        if (strcmp(inputlocation,weatherData[i].location) == 0) {
    		if (!found) {
        		printf("\nData for %s: \n", inputlocation);
        		found=1;
        	}
        	printf("Date: %s, temperature: %s\n",weatherData[i].date, weatherData[i].temperature);
        }
    }
    if(!found){
    	printf("\n Data for %s not found.\n",inputlocation);
	}
   // free(input_location); // Free dynamically allocated memory
    return 0;
}