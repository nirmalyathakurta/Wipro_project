#include <bits/stdc++.h>
using namespace std;

class Employee {
protected:
    string name;
    int ID;
    Employee* reportingManager;
public:
    Employee(const string& empName, const int& empID) : name(empName), ID(empID), reportingManager(nullptr) {}

    void setReportingManager(Employee* manager) {
        this->reportingManager=manager;
    }

    virtual void updateStatus() {}

    virtual void promote() {
        cout << "Employee " << name<<" "<<ID << " has been promoted." << endl;
    }

    string getName() { return name; }
    
    int getID() { return ID; }

    void displayManager() {
        if(reportingManager != nullptr ) {
            cout<<name<<" "<<ID<< " has "<<reportingManager->getName()<<" "<<reportingManager->getID()<<" as the reporting manager"<<endl;
        }
        else {
            cout<<name<<" "<<ID<<" currently has no reporting manager"<<endl;
        }
    }
};

class Reporter : public Employee {
public:
    Reporter(const string& empName, const int& empID) : Employee(empName, empID) {}

    void updateStatus() {
        cout << "Reporter " << name<<" "<< ID << " is updating daily status." <<endl;
    }
};

class Manager : public Employee {
public:
    Manager(const string& empName, const int& empID) : Employee(empName, empID) {}

    void updateStatus() {
        cout << "Manager " << name<<" "<< ID << " is receiving daily status updates." <<endl;
    }

    void promote() override {
        cout << "Manager " << name<<" "<< ID << " is promoting the employee."<<endl;
    }
};

int main() {
    Employee* emp1 = new Reporter("Alice", 101);
    Employee* emp2 = new Manager("Bob", 102);
    Employee** emp3 = &emp2;

   

    emp1->updateStatus();
    
    emp2->updateStatus();
    emp2->promote();
    emp1->promote();  
    emp1->setReportingManager(emp2);
    emp1->displayManager();

    emp2->setReportingManager((*emp3));
    emp2->displayManager();

    delete emp1;
    delete emp2;

    return 0;
}