#include <iostream>
#include <fstream>
#include <string>
#include <sstream> // For stringstream
using namespace std;

// Forward declarations
class employee;
class Manager;
struct Node;

// Function prototypes
void displayEmployeeDetails(employee* emp);
void bubbleSortByName(Node* head);

// Employee class
class employee {
protected:
    string name;
    int ID;
public:
    employee(const string& empName, int empID) : name(empName), ID(empID) {}
    string getName() { return name; }
    int getID() { return ID; }
    virtual void displayDetails() {
        cout << "Employee: " << name << " ID: " << ID << endl;
    }
    virtual void promote(const string& newDesignation) {}
    virtual void demote(const string& newDesignation) {}
    virtual ~employee() {}
};

// Manager class
class Manager : public employee {
protected:
    string designation;
public:
    Manager(const string& empName, const int& empID, const string& empDesignation) : employee(empName, empID), designation(empDesignation) {}
    void displayDetails() override {
        cout << "Manager: " << name << " ID: " << ID << " Designation: " << designation << endl;
    }
    void promote(const string& newDesignation) override {
        cout << "Manager " << name << " " << ID << " has been promoted to " << newDesignation << "." << endl;
        designation = newDesignation;
    }
    void demote(const string& newDesignation) override {
        cout << "Manager " << name << " " << ID << " has been demoted to " << newDesignation << "." << endl;
        designation = newDesignation;
    }
};

// Node structure for linked list
struct Node {
    employee* data;
    Node* next;
};

// EmployeeList class
class employeeList {
private:
    Node* head;
public:
    employeeList() : head(nullptr) {}
    void addEmployee(employee* emp);
    void displayAllEmployees();
    void bubbleSortByName();
    void promoteEmployee(int empID, const string& newDesignation);
    void demoteEmployee(int empID, const string& newDesignation);
    void deleteEmployee(int empID);
    void printFinalResultsToFile(const string& filename);
};

// Function to add an employee to the list
void employeeList::addEmployee(employee* emp) {
    Node* newNode = new Node;
    newNode->data = emp;
    newNode->next = head;
    head = newNode;
}

// Function to display all employees in the list
void employeeList::displayAllEmployees() {
    Node* current = head;
    while (current != nullptr) {
        displayEmployeeDetails(current->data);
        current = current->next;
    }
}

// Function to display details of an employee
void displayEmployeeDetails(employee* emp) {
    emp->displayDetails();
}

// Function to perform bubble sort by employee name
void employeeList::bubbleSortByName() {
    if (head == nullptr || head->next == nullptr) {
        // List is empty or has only one element, no need to sort
        return;
    }

    bool swapped;
    Node* current;
    Node* last = nullptr;

    do {
        swapped = false;
        current = head;

        while (current->next != last) {
            // Compare current and next node's employee names
            if (current->data->getName() > current->next->data->getName()) {
                // Swap data if the current name is greater than the next name
                employee* temp = current->data;
                current->data = current->next->data;
                current->next->data = temp;
                swapped = true;
            }
            current = current->next;
        }
        last = current;
    } while (swapped);
}

// Function to promote an employee
void employeeList::promoteEmployee(int empID, const string& newDesignation) {
    Node* current = head;
    while (current != nullptr) {
        if (Manager* manager = dynamic_cast<Manager*>(current->data)) {
            if (manager->getID() == empID) {
                manager->promote(newDesignation);
                break;
            }
        }
        current = current->next;
    }
}

// Function to demote an employee
void employeeList::demoteEmployee(int empID, const string& newDesignation) {
    Node* current = head;
    while (current != nullptr) {
        if (Manager* manager = dynamic_cast<Manager*>(current->data)) {
            if (manager->getID() == empID) {
                manager->demote(newDesignation);
                break;
            }
        }
        current = current->next;
    }
}

// Function to delete an employee by ID
void employeeList::deleteEmployee(int empID) {
    Node* current = head;
    Node* prev = nullptr;

    while (current != nullptr) {
        if (current->data->getID() == empID) {
            // Employee found, delete the node
            if (prev == nullptr) {
                // If the employee to delete is the head of the list
                head = current->next;
            } else {
                prev->next = current->next;
            }
            delete current->data; // Free memory for employee object
            delete current; // Free memory for node
            return;
        }
        prev = current;
        current = current->next;
    }
    cout << "Employee with ID " << empID << " not found." << endl;
}

// Function to print final results to a file
void employeeList::printFinalResultsToFile(const string& filename) {
    ofstream outputFile(filename);

    if (!outputFile.is_open()) {
        cout << "Unable to open file for writing." << endl;
        return;
    }

    streambuf* coutbuf = cout.rdbuf();
    cout.rdbuf(outputFile.rdbuf());

    displayAllEmployees();

    cout.rdbuf(coutbuf);
    outputFile.close();

    cout << "Final employee details have been written to " << filename << "." << endl;
}

int main() {
    employeeList empList;
    string name, designation;
    int ID;

    char choice;
    do {
        cout << "Enter employee name: ";
        cin >> name;
        cout << "Enter employee ID: ";
        cin >> ID;
        cout << "Enter employee designation: ";
        cin >> designation;
        

        employee* emp = new Manager(name, ID, designation);
        empList.addEmployee(emp);

        cout << "Do you want to promote/demote this employee? (p/d/n): ";
        cin >> choice;

        if (choice == 'p' || choice == 'P') {
            string newDesignation;
            cout << "Enter new designation for promotion: ";
            cin >> newDesignation;
            empList.promoteEmployee(ID, newDesignation);
        }
        else if (choice == 'd' || choice == 'D') {
            string newDesignation;
            cout << "Enter new designation for demotion: ";
            cin >> newDesignation;
            empList.demoteEmployee(ID, newDesignation);
        }

        

        cout << "Do you want to delete employee? (r/n): ";
        cin >> choice;
        if(choice == 'r' || choice == 'R') {
            cout << "Enter the employee ID to delete: ";
            empList.deleteEmployee(ID);

        }

        cout << "Do you want to add another employee? (y/n): ";
        cin >> choice;
    } while (choice == 'y' || choice == 'Y');

    // Sort employees by name
    empList.bubbleSortByName();

    // Delete employee
    int empIDToDelete;
    cout << "Enter the employee ID to delete: ";
    cin >> empIDToDelete;
    empList.deleteEmployee(empIDToDelete);

    // Print final results to a file
    empList.printFinalResultsToFile("final_results.txt");

    return 0;
}