#include <iostream>
using namespace std;
template <class T> void bubblesort(T a[], int arrsize) { 
    int i,j;
    for(i=0;i<arrsize-1;i++)
        for( j=arrsize-1;i<j;j--)
            if(a[j]< a[j-1]) swap(a[j],a[j-1]);
}

int main() {
    int x[10]= { 1,23,5,7,4,3,99,101,76,54 };
    int as =sizeof(x)/sizeof(x[0]);
    int b;
    bubblesort<int>(x,as);
    cout<< "Array after Bubbling \n";
    for(b=0;b<as ;b++) {
        cout<< x[b] << "  ";
    }
    cout<< "\n";
    return 0;
}