#include<bits/stdc++.h>
using namespace std;

class employee{
protected:
    string name;
    int ID;
    employee* reportingManager;

public:  
    employee(const string& empName,int empID): name(empName), ID(empID), reportingManager(nullptr) {}

    virtual void updatestatus(){}

    virtual void promote(const string& newDesignation){
        cout << "Employee " << name << " " << ID << " has been promoted to " << newDesignation << "." << endl;
    }

    virtual void demote(const string& newDesignation){
        cout << "Employee " << name << " " << ID << " has been demoted to " << newDesignation << "." << endl;
    }

    string getName(){
        return name;
    }  

    int getID(){
        return ID;
    }

    void setReportingManager(employee* manager){
        this->reportingManager = manager;
    }

    void displayManager(){
        if(reportingManager != nullptr){
            cout << name << " " << ID << " has " << reportingManager->getName() << " " << reportingManager->getID() << " as the reporting manager" << endl;
        }
        else{
            cout << name << " " << ID << " currently has no reporting manager" << endl;
        }
    }

    virtual void displayDetails(){
        cout << "Employee " << name << " " << ID << endl;
    }

    virtual void displayDetails(bool isNull){
        if(isNull){
            cout << "No employee exists in the company" << endl;
        }
        else{
            displayDetails();
        }
    }
};

class Manager : public employee{
protected:
    string designation;

public:
    Manager(const string& empName, const int& empID, const string& empDesignation): employee(empName, empID), designation(empDesignation) {}

    void updatestatus() override{
        cout << designation << " " << name << " " << ID << " is receiving daily status updates." << endl;
    }

    void promote(const string& newDesignation) override{
        cout << designation << " " << name << " " << ID << " has been promoted to " << newDesignation << "." << endl;
        designation = newDesignation;
    }

    void demote(const string& newDesignation) override{
        cout << designation << " " << name << " " << ID << " has been demoted to " << newDesignation << "." << endl;
        designation = newDesignation;
    }

    void displayDetails() override{
        cout << designation << " " << name << " " << ID << endl;
    }
};

struct Node{
    employee* data;
    Node* next;
};

class employeeList{
private:
    Node* head;

    void swap(Node* a, Node* b){
        employee* temp = a->data;
        a->data = b->data;
        b->data = temp;
    }

public:
    employeeList(): head(nullptr) {}

    void addemployee(employee* emp){
        Node* newNode = new Node;
        newNode->data = emp;
        newNode->next = head;
        head = newNode;
    }

    void displayAllEmployee(){
        Node* current = head;
        while(current != nullptr){
            current->data->displayDetails();
            current = current->next;
        }
    }

    void bubbleSortByID(){
        int n = 0;
        Node* current = head;
        while(current != nullptr){
            n++;
            current = current->next;
        }

        for(int i = 0; i < n - 1; i++){
            Node* current = head;
            for(int j = 0; j < n - i - 1; j++){
                if(current->data->getID() > current->next->data->getID()){
                    swap(current, current->next);
                }
                current = current->next;
            }
        }
    }

    void bubbleSortByName(){
        int n = 0;
        Node* current = head;
        while(current != nullptr){
            n++;
            current = current->next;
        }

        for(int i = 0; i < n - 1; i++){
            Node* current = head;
            for(int j = 0; j < n - i - 1; j++){
                if(current->data->getName() > current->next->data->getName()){
                    swap(current, current->next);
                }
                current = current->next;
            }
        }
    }
};

int main(){
    employeeList empList;
    char name[10]; 
    string designation;
    int ID;
    char choice;

    do{
        cout << "Enter employee name: ";
        cin>>name;
        cout << "Enter employee ID: ";
        cin >> ID;
        cin.ignore();
        cout << "Enter employee designation: ";
        getline(cin,designation);

        employee* emp = new Manager(name, ID, designation);
        empList.addemployee(emp);

        cout << "Do you want to promote or demote this employee? (p/d/n): ";
        cin >> choice;

        if(choice == 'p' || choice == 'P'){
            string newDesignation;
            cout << "Enter new designation for promotion: ";
            cin.ignore();
            getline(cin,newDesignation);
            emp->promote(newDesignation);
        }
        else if(choice == 'd' || choice == 'D'){
            string newDesignation;
            cout << "Enter new designation for demotion: ";
            cin.ignore();
            getline(cin,newDesignation);
            emp->demote(newDesignation);
        }

        cout << "Do you want to add another employee? (y/n): ";
        cin >> choice;
    } while(choice == 'y' || choice == 'Y');

    cout << "Sorting employees by ID:" << endl;
    empList.bubbleSortByID();
    empList.displayAllEmployee();

    cout << "Sorting employees by name:" << endl;
    empList.bubbleSortByName();
    empList.displayAllEmployee();

    return 0;
}