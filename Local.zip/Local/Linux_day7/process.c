#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <time.h>
#include <sys/shm.h>
#include <sys/types.h>
#include <sys/ipc.h>

#define SIZE 1024

void kill(char* s) {
    perror(s);
    exit(1);
}

typedef struct processData {
    time_t timestamp;
    float value;
    struct processData* next;
} process;

int main() {
    key_t key = 1234;

    int shmid1 = shmget(key, SIZE, IPC_CREAT | 0666);

    if(shmid1==-1) kill("shmget");

    float* ptr1 = shmat(shmid1, NULL, 0);
    if(ptr1 == (void*)-1) kill("shmat");

    int shmid2 = shmget(key, SIZE, IPC_CREAT | 0666);

    if(shmid2==-1) kill("shmget");

    process* ptr2 = shmat(shmid2, NULL, 0);
    if(ptr2==(void*)-1) kill("shmat");

    while(1) {
        float read_data = *ptr1;

        process processed_data;
        processed_data.timestamp = time(NULL);
        processed_data.value = read_data*1000;

        *ptr2=processed_data;

        usleep(500000);
    }
    


    if(shmdt(ptr1)==-1) kill("shmdt");

    if(shmdt(ptr2)==-1) kill("shmdt");
    if(shmctl(shmid2, IPC_RMID, NULL) == -1) kill("shmctl");

    return 0;

}