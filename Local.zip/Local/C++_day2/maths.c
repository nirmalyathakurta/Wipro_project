#include<stdio.h>
#include<math.h>

int afunc(int x, float *arr) {
	arr[0] = pow(x,2);
	arr[1] = pow(x,3);
	arr[2] = pow(x, 0.5);
	
}

int main() {
	int x = 10;
	float arr[3];
	afunc(x, arr);
	printf("\n Square of %d is %f", x, arr[0]);
	printf("\n Cube of %d is %f", x, arr[1]);
	printf("\n Square root of %d is %f", x, arr[2]);
	return 0;
}
