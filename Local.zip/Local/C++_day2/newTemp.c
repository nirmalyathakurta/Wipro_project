#include <stdio.h>
#include <string.h>

#define MAX_LOCATIONS 5
#define MAX_DAYS 10

int main() {
    char dates[MAX_LOCATIONS][MAX_DAYS][10];
    char locations[MAX_LOCATIONS][10];
    float temperatures[MAX_LOCATIONS][MAX_DAYS];

    strcpy(dates[0][0], "2024-04-01");
    strcpy(locations[0], "Mumbai");
    temperatures[0][0] = 20.5;
// Sample data (replace with your actual data collection)
    strcpy(dates[0][1], "2024-04-01");
    strcpy(locations[1], "Kolkata");
    temperatures[0][1] = 25.2;

//use switch case to retrive the data
    int choice;
    float search_temp;
    char search_date[11], search_location[20];

    printf("Select search option:\n");
    printf("By date\n");
    printf("By location\n");
    printf("By temperature\n");
    printf("Enter your choice: ");
    scanf("%d", &choice);

    switch (choice) {
        case 1:
            printf("Enter date (YYYY-MM-DD): ");
            scanf("%s", search_date);
            for (int i = 0; i < MAX_LOCATIONS; i++) {
                for (int j = 0; j < MAX_DAYS; j++) {
                    if (strcmp(dates[i][j], search_date) == 0) {
                        printf("Location: %s, Temperature: %.2f\n", locations[i], temperatures[i][j]);
                    }
                }
            }
            break;
        case 2:
            printf("Enter location: ");
            scanf("%s", search_location);
            for (int i = 0; i < MAX_LOCATIONS; i++) {
                if (strcmp(locations[i], search_location) == 0) {
                    for (int j = 0; j < MAX_DAYS; j++) {
                        printf("Date: %s, Temperature: %.2f\n", dates[i][j], temperatures[i][j]);
                    }
                }
            }
            break;
        case 3:
            printf("Enter temperature: ");
            scanf("%f", &search_temp);
            for (int i = 0; i < MAX_LOCATIONS; i++) {
                for (int j = 0; j < MAX_DAYS; j++) {
                    if (temperatures[i][j] == search_temp) {
                        printf("Date: %s, Location: %s\n", dates[i][j], locations[i]);
                    }
                }
            }
            break;
        default:
            printf("Invalid choice!\n");
    }

    return 0;
}
