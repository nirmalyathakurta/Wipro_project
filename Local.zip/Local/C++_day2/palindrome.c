#include<stdio.h>
#include<string.h>
#include<stdlib.h>

void palindrome( char *input) {
	char *ptr, *rev; 
    ptr = input; 
    while (*ptr != '\0') { 
        ++ptr; 
    } 
    --ptr; 
    for (rev = input; ptr >= rev;) { 
        if (*ptr == *rev) { 
            --ptr; 
            rev++; 
        } 
        else
            break; 
    } 
    if (rev > ptr) 
        printf("String is Palindrome"); 
    else
        printf("String is not a Palindrome");
}

int main() {
	char *input;
	input = (char*)malloc(25 * sizeof(char));
	printf("\n Enter the string: ");
	scanf("%[^\n]",input);
	palindrome(input);
	return 0;
}

