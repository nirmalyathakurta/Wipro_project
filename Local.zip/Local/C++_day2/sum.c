
/*define int pointer
allocate memory
get input
add odd positions
add even positions
add all elements or numbers
print all three results*/

#include<stdio.h>
#include<stdlib.h>
int main()
{
	int *arr;
	int size, num, sum_odd = 0, sum_even = 0, sum_all = 0;     
	printf("\n Enter the number of elements: ");
	scanf("%d", &size);
	arr = (int*)malloc(size * sizeof(int));
	printf("\n Enter %d elements:", size);
	for(int i=1;i<=size;i++)
	{
		scanf("%d",arr);
		sum_all += *arr;
		if(i%2==0)
		{
			sum_even += *arr;
		}else{
			sum_odd += *arr;
		}
		arr++;
	}
	printf("\n Sum of all elements: %d", sum_all);
	printf("\n Sum of even elements: %d", sum_even);
	printf("\n Sum of odd elements: %d", sum_odd);
	return 0;
}
