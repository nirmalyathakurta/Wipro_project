// given int value
// find factorial using recursion

#include<stdio.h>
int factorial(int x) {
	if(x == 0)
	{
		return 1;
	}else{
		return x*factorial(x-1);
	}
}

int main() {
	int x=5;
	printf("\n %d \n", factorial(x));
}
