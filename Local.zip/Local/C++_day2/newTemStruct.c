#include<stdio.h>
#include<stdlib.h>
#include<string.h>
 
#define NUM_DAYS 10
#define MAX_DATA_SIZE 11
#define MAX_LOCATION_LENGTH 20
 
struct weatherData {
    char date[MAX_DATA_SIZE];
    char location[MAX_LOCATION_LENGTH];
    char temperature[10];
};
 
int main() {
    struct weatherData data[NUM_DAYS]={
        {"2024-04-01","Location1","25c"},
        {"2024-04-02","Location2","28c"},
        {"2024-04-02","Location3","29c"},
        {"2024-04-03","Location4","26c"},
        {"2024-04-04","Location5","24c"},
        {"2024-04-05","Location6","22c"},
        {"2024-04-06","Location7","21c"},
        {"2024-04-07","Location8","35c"},
        {"2024-04-08","Location9","27c"},
        {"2024-04-09","Location10","58c"},
 
    };
 
    char *input_location=(char*)malloc(MAX_LOCATION_LENGTH*sizeof(char));
 
    printf("ENter the location:\n");
    scanf("%s",input_location);
 
    int founded=0;
    for(int i=0;i<NUM_DAYS;i++) {
        if(strcmp(input_location,data[i].location)==0) {
            printf("\n Data for %s:\n",input_location);
            printf("Date:%s\n",data[i].date);
            printf("Temperature:%s\n",data[i].temperature);
            founded=1;
        }
    }
    if(!founded) {
        printf("\n Data for %s not found.\n",input_location);
 
    }
    free(input_location);
    return 0;
}