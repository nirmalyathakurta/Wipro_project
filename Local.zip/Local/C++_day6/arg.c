#include <stdio.h>
#include <stdlib.h>

int add(int a, int b) {
    printf("%d", a+b);
}
 
int main (int argc, char *argv[] ) { // or **argv[] 
    int j=0;
    printf("Total arguments to the program are : %d\n", argc);
 
    for (j=0; j<argc; j++) {
        printf("%s”\n",argv[j]);
    }
    if(argv[1]=="+") {
        add((atoi)argv[2],(atoi)argv[3]);
    }
    return 0;
}