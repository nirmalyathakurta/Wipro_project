#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>

typedef struct Contact {
    char name[50];
    char phone[20];
    char address[100];
    struct Contact* next;
    struct Contact* prev;
} Contact;

/*Contact* createContact() {
    Contact* newContact = (Contact*)malloc(sizeof(Contact));
    if (newContact == NULL) {
        printf("Memory allocation failed.\n");
        exit(EXIT_FAILURE);
    }
    newContact->name = (char*)malloc(50 * sizeof(char));
    printf("Enter name: ");
    scanf("%s", newContact->name);
    
    printf("Enter phone number: ");
    scanf("%s", newContact->phone);
    
    newContact->address = (char*)malloc(100 * sizeof(char));
    printf("Enter address: ");
    scanf("%s", newContact->address);
    
    printf("Enter age: ");
    scanf("%d", &newContact->age);
    
    newContact->next = NULL;
    return newContact;
}*/

char* generateRandomName(char* name) {
    char* names[] = {"Raj", "Neel", "Rocky", "Sarah", "Dev", "Lica", "Mitak", "Olive", "Brian", "Jess", "Dan", "Sidha", "Jacob", "Emma", "Stone", "Medha"};
    strcpy(name, names[rand() % (sizeof(names) / sizeof(names[0]))]);
}

void generateRandomPhone(char *phoneNumber) {
    sprintf(phoneNumber, "%03d-%04d-%04d", rand() % 1000, rand() % 10000, rand() % 10000);
}   

char* generateRandomAddress(char* address) {
    char* addresses[] = {"123 Main St", "456 main St", "789 abc St", "321 Lime St", "654 ABCD St", "111 Cherry St", "22 Cedar St", "3 Pine St", "4 Oak St"};
    strcpy(address, addresses[rand() % (sizeof(addresses) / sizeof(addresses[0]))]);
}

Contact* createEntry() {
    Contact* newEntry = (Contact*)malloc(sizeof(Contact));
    if(newEntry == NULL) exit(-1);
    generateRandomName(newEntry->name);
    generateRandomPhone(newEntry->phone);
    generateRandomAddress(newEntry->address);
    newEntry->next=NULL;
    return newEntry;
}

Contact* buildAddressBook(int numNodes, const char *listType) {
    Contact* head = NULL;
    Contact* current = NULL;

    // for singly list
    if(strcmp(listType, "singly")==0) {
        for (int i = 0; i < numNodes; ++i) {
            Contact* newEntry = createEntry();
            if (head == NULL) {
                head = newEntry;
                current = newEntry;
            } else {
                current->next = newEntry;
                current = newEntry;
            }
        }
    }

     // for doubly list
    if(strcmp(listType, "doubly")==0) {
        for (int i = 0; i < numNodes; ++i) {
            Contact* newEntry = createEntry();
            if (head == NULL) {
                head = newEntry;
                current = newEntry;
            } else {
                current->next = newEntry;
                current->prev = newEntry;
                current = newEntry;
            }
        }
    }

    // for circular list
    if (strcmp(listType, "circular") == 0 && head != NULL) {
            for (int i = 0; i < numNodes; ++i) {
            Contact* newEntry = createEntry();
            if (head == NULL) {
                head = newEntry;
                current = newEntry;
            } else {
                current->next = head;
                current = newEntry;
            }
        }
                
    }

    return head;
}
void printList(Contact* head) {
    Contact* current = head;
    int count =1 ;
    while ( head!=NULL) {
        printf("Contact %d:\n", count++);
        printf("Name: %s\nPhone_No.: %s\nAddress: %s\n\n", head->name, head->phone, head->address);
        head=head->next;
        if(current == head) break;
    }
}

/*void freeList(Contact* head) {
    if(head==NULL) return;
    Contact* current= head;
    Contact* temp;
    do {
        temp = current;
        current = current-> next;
        free(temp->name);
        free(temp->address);
        free(temp);
    } while(current != head );  

}*/

void listCheck(const char* listype) {
    if(strcmp(listype, "singly")!=0 && strcmp(listype, "doubly")!=0 && strcmp(listype, "circular")!=0) {
        printf("Invalid list type\n");
        exit(-1);
    }
}

int main(int argc, char* argv[]) {
    if(argc != 3) {
        printf("Usage: %s<number_of_node> <List_type\n",argv[0]);
        return 1;
    }

    int numNodes = atoi(argv[1]);
    const char *listtype= argv[2];

    listCheck(listtype);

    Contact* head= buildAddressBook(numNodes,listtype);

    printf("Address Book:\n");
    printList(head);

    return 0;
}