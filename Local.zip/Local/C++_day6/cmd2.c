#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>

// Define a structure
typedef struct AddressBook {
    char name[50];
    char phone[15];
    struct AddressBook* next;
} AddressBook;

// Function for generating random phone numbers
void generateRandomPhoneNumber(char *phoneNumber) {
    sprintf(phoneNumber, "%03d-%04d-%04d", rand() % 1000, rand() % 10000, rand() % 10000);
}

// Function to generate a random name
void generateRandomName(char *name) {
    char *names[] = {"John", "Jane", "Michael", "Emily", "David", "Emma", "Sarah", "Christopher", "Olivia", "James"};
    strcpy(name, names[rand() % (sizeof(names) / sizeof(names[0]))]);
}

// Function to create a new address book entry
AddressBook* createEntry() {
    AddressBook* newEntry = (AddressBook*)malloc(sizeof(AddressBook));
    generateRandomName(newEntry->name);
    generateRandomPhoneNumber(newEntry->phone);
    newEntry->next = NULL;
    return newEntry;
}

// Function to build the address book linked list with a specified number of nodes
AddressBook* buildAddressBook(int numNodes, const char *listType) {
    AddressBook* head = NULL;
    AddressBook* current = NULL;
    
    srand(time(NULL));
    
    for (int i = 0; i < numNodes; i++) {
        AddressBook* newEntry = createEntry();
        if (head == NULL) {
            head = newEntry;
            current = newEntry;
        } else {
            current->next = newEntry;
            current = newEntry;
        }
        //circular linked list function
        if(strcmp(listType,"circular")==0 && head!=NULL){
        current->next=head;
        }
    }
    
    
    return head;
}

// Function to print the address book linked list
void printAddressBook(AddressBook* head) {
    AddressBook* current=head;
    while (head != NULL) {
        printf("Name: %s, Phone: %s\n", head->name, head->phone);
        head = head->next;
        if(current==head)
        break;
    }
}

int main(int argc, char *argv[]) {
    if (argc != 3) {
        printf("Usage: %s <number_of_nodes> <type_of_list>\n", argv[0]);
        return 1;
    }

    int numNodes = atoi(argv[1]);
    char* listType = argv[2];

    if (strcmp(listType, "singly") != 0 && strcmp(listType, "doubly") != 0 && strcmp(listType, "circular") != 0) {
        printf("Invalid list type. Please specify either 'singly' or 'doubly'.\n");
        return 1;
    }

    AddressBook* addressBook = buildAddressBook(numNodes,listType);

    printf("Address Book:\n");
    printAddressBook(addressBook);

    return 0;
}