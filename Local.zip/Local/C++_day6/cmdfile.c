//Function for listing files
//Deleting files
//renaming files

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <dirent.h>

// List all the files in the directory 
void listingFiles(const char *directory) {
    DIR *dir = opendir(directory);
    if(dir == NULL) {
        perror("opendir");
        return;
    }
    struct dirent *name;
    while((name = readdir(dir))!=NULL) {
        printf("%s\n",name->d_name);
    }
    closedir(dir);
}

// Delete a specific file in the directory
int deleteFile(const char *filename) {
    if(remove(filename)==0) {
        printf("%s Deleted sucessfully\n",filename);
        return 0;

    }
    else {
        perror("remove");
        return 1;
    }
}

// Rename a specific file in the directory
int renameFile(const char *ofilename, const char *nfilename)  {
    if(rename(ofilename,nfilename)==0) {
        printf("%s Renamed to %s sucessfully",ofilename,nfilename);
        return 0;
    }   
    else {
        perror("rename");
        return 1;
    } 
}

int main(int argc,char *argv[]) {
    if ( argc < 2) {
        printf("Usage: %s <command> <arguments>\n", argv[0]);
        printf("Commands available: \n");
        printf("1) List\n");
        printf("2) Delete\n");
        printf("2) Rename\n");
        return 1;
    }
    
    if(strcmp(argv[1], "List")==0) {
        if(argc == 2) listingFiles(".");
        else listingFiles(argv[2]);

    }

    else if(strcmp(argv[1], "Delete")==0) {
        if(argc != 3) {
            printf("Usage: %s delete <file>\n", argv[0]);
            return 1;
        }
        deleteFile(argv[2]);
    }

    else if (strcmp(argv[1],"Rename")==0) {
        if(argc != 4) {
            printf("Usage: %s rename <old> <new>\n",argv[0]);
            return 1;
        }
        renameFile(argv[2], argv[3]);
    }

    else {
        printf("Invalid command: %s\n", argv[1]);
        return 1;
    }
    return 0;  
}