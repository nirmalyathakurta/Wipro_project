#include <bits/stdc++.h>
using namespace std;

class Singleton {

public:

    // Static method to access the singleton instance

    static Singleton& getInstance()

    {

        // If the instance doesn't exist, create it

        if (!instance) {

            instance = new Singleton();

        }

        return *instance;

    }
 
    void someOperation()

    {

        std::cout

            << "Singleton is performing some operation."

            << std::endl;

    }
 
    Singleton(const Singleton&) = delete;

    Singleton& operator=(const Singleton&) = delete;
 
private:

    Singleton()

    {

        std::cout << "Singleton instance created."

            << std::endl;

    }
 
    ~Singleton()

    {

        std::cout << "Singleton instance destroyed."

            << std::endl;

    }
 
    static Singleton* instance;

};
 
// Initialize the static instance variable to nullptr

Singleton* Singleton::instance = nullptr;
 
int main()

{

    // Access the Singleton instance

    Singleton& singleton = Singleton::getInstance();
    //Singleton newSingleton;
    // Use the Singleton instance

    singleton.someOperation();
 
 
    return 0;

}