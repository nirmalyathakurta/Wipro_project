#include <stdio.h>

void removeDuplicates(int arr[], int *size) {
    int j, k, newSize = *size;
    
    // Loop through the array
    for (int i = 0; i < newSize; i++) {
        // Check for duplicates
        for (j = i + 1; j < newSize;) {
            if (arr[i] == arr[j]) {
                // Shift elements to the left to remove the duplicate
                for (k = j; k < newSize; k++) {
                    arr[k] = arr[k + 1];
                }
                newSize--; // Decrease size of the array
            } else {
                j++;
            }
        }
    }
    
    *size = newSize; // Update the original size
}

int main() {
    int arr[100], size;
    
    // Input the size of the array
    printf("Enter the size of the array: ");
    scanf("%d", &size);
    
    // Input the elements of the array
    printf("Enter %d elements of the array:\n", size);
    for (int i = 0; i < size; i++) {
        scanf("%d", &arr[i]);
    }
    
    // Print the original array
    printf("Original array: ");
    for (int i = 0; i < size; i++) {
        printf("%d ", arr[i]);
    }
    printf("\n");
    
    // Remove duplicates
    removeDuplicates(arr, &size);
    
    // Print the array after removing duplicates
    printf("Array after removing duplicates: ");
    for (int i = 0; i < size; i++) {
        printf("%d ", arr[i]);
    }
    printf("\n");
    
    return 0;
}
