#include<stdio.h>
void main() {
    const volatile int myvar = 50;
    int *iptr=(int*) &myvar;
    printf("value of myvar %d\n",myvar);
}