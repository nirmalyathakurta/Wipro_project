#include<stdio.h> 
#include<math.h> 
void circum(float radius); 
void VOS(float radius); 
void SOS(float radius); 
const PI=22/7; 
float a=3.1415; 
int main() {
    float radius; 
    scanf("%f",&radius); 
    float c=PI*radius*radius; 
    printf("Area of circle: %f\n",c); 
    circum(radius); 
    VOS(radius); 
    SOS(radius); 
    printf("hello world\n"); 
} 
void circum(float radius) { 
    float circ=2*a*radius; 
    printf("%f is circum of circle\n", circ); 
} 
void VOS(float radius) { 
    float volume=(4/3)*PI*pow(radius,3); 
    printf("Volume of sphere is %f\n",volume); 
} 
void SOS(float radius) { 
    float value=4*PI*pow(radius,2); 
    printf("Surface area of sphere: %f\n",value); 
} //volume of sphere with given radius //surface value of sphere
