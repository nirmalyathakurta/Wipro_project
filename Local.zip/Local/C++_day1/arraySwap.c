#include <stdio.h>

#define MAX_SIZE 100

void swapArrays(int arr1[], int arr2[], int size) {
    int temp;
    for (int i = 0; i < size; i++) {
        temp = arr1[i];
        arr1[i] = arr2[i];
        arr2[i] = temp;
    }
}

int main() {
    int arr1[MAX_SIZE], arr2[MAX_SIZE], size;

    printf("Enter the size of the arrays: ");
    scanf("%d", &size);    
    
    printf("Enter %d elements of the first array:\n", size);
    for (int i = 0; i < size; i++) {
        scanf("%d", &arr1[i]);
    }
    
    printf("Enter %d elements of the second array:\n", size);
    for (int i = 0; i < size; i++) {
        scanf("%d", &arr2[i]);
    }
    
    printf("\nOriginal Arrays:\n");
    printf("First Array: ");
    for (int i = 0; i < size; i++) {
        printf("%d ", arr1[i]);
    }
    printf("\nSecond Array: ");
    for (int i = 0; i < size; i++) {
        printf("%d ", arr2[i]);
    }
    printf("\n");
    
    swapArrays(arr1, arr2, size); // calling the swapping function
    
    printf("\nSwapped Arrays:\n");
    printf("First Array: ");
    for (int i = 0; i < size; i++) {
        printf("%d ", arr1[i]);
    }
    printf("\nSecond Array: ");
    for (int i = 0; i < size; i++) {
        printf("%d ", arr2[i]);
    }
    printf("\n");
    
    return 0;
}
