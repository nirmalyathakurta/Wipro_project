#include <stdio.h>
#include <stdlib.h>
#include <ctype.h>  

// to check mismatch of two words
int is_word_match(const char *word1, const char *word2) {
    int i = 0;
    while (word1[i] && word2[i]) {
        if (tolower(word1[i]) != tolower(word2[i])) {
            return 0;
        }
        i++;
    }
    // Check if both words have reached their ends simultaneously
    return word1[i] == '\0' && word2[i] == '\0';
}

int main() {
    FILE *fp;
    char *word, *temp, ch;
    int count = 0;

    // Get the word to search from the user
    printf("Enter the word to search: ");
    word = (char *)malloc(sizeof(char) * 100);  
    if (word == NULL) {
        fprintf(stderr, "Memory allocation failed!\n");
        return 1;
    }
    fgets(word, 100, stdin);  
    
    temp = word;
    while (*temp && *temp != '\n') {
        temp++;
    }
    *temp = '\0';  

    // opening the text file from the system s
    fp = fopen("example.txt", "r");
    if (fp == NULL) {
        fprintf(stderr, "Error opening file: example.txt\n");
        free(word);  
        return 1;
    }

    temp = (char *)malloc(sizeof(char) * 100);  
    if (temp == NULL) {
        fprintf(stderr, "Memory allocation failed!\n");
        fclose(fp);
        free(word);  
        return 1;
    }

    while ((ch = fgetc(fp)) != EOF) {
        int i = 0;
        while (isalnum(ch) && ch != EOF) {  
            temp[i++] = ch;
            ch = fgetc(fp);
        }
        temp[i] = '\0';  

        // check for capital, block letters etc.
        if (is_word_match(word, temp)) {
            count++;
        } else {
            
            for (i = 0; temp[i]; i++) {
                temp[i] = tolower(temp[i]);
            }
            if (is_word_match(word, temp)) {
                count++;
            }
        }

        i = 0;
    }

    free(temp);  
    fclose(fp);  

    if (count > 0) {
        printf("The word '%s' (including different capitalizations) appears %d times in the file.\n", word, count);
    } else {
        printf("The word '%s' was not found in the file.\n", word);
    }

    free(word); 

    return 0;
}
