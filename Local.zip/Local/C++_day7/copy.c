// Program takes name of two files
// Read from first file and write data on second file
// Use file pointers 

#include <stdio.h>
#include <stdlib.h>

int main() {
    char *src, *dest;
    char *buffer;
    size_t bufferSize = 1024;

    printf("Enter first file name: ");
    if(scanf("%ms", &src) != 1) {
        fprintf(stderr, "Error reading");
        return 1;
    }

    printf("Enter second file name: ");
    if(scanf("%ms", &dest) != 1) {
        fprintf(stderr, "Error reading");
        free(src);
        return 1;
    }

    buffer = malloc(bufferSize*sizeof(char));

    FILE* f1 = fopen(src, "rb");
    FILE* f2 = fopen(dest, "wb");

    if(f1==NULL) {
        fprintf(stderr, "Error opening %s\n", src);
    }
    else if (f2==NULL) {
        fprintf(stderr, "Error opening %s\n", dest);
        free(src);
        free(dest);
        free(buffer);
    }
    else {
        while(fgets(buffer, bufferSize, f1) != NULL) {
            if(fputs(buffer, f2)==EOF) {
                fprintf(stderr, "Error opening %s\n", dest);
                break;
            }
        
        }
        fclose(f1);
        fclose(f2);
        printf("File copied successfully");   
    }
    
    free(src);
    free(dest);
    free(buffer);

    return 0;
}