//define the structure myavges
// create functions to fill structure data
//define function to fill the arrays with random inputs
//create function to generate random integer
//main function

#include<stdio.h>
#include<stdlib.h>
#include<stdarg.h>
#include<string.h>
#include<time.h>


struct myavges{
char *petrol;
double avgmileage;
int startvalue;
int filledvalue;
};

struct myavges *create_random(const char *fmt,...){
    va_list args;
    va_start(args, fmt);

    struct myavges *avges = malloc(sizeof(struct myavges));

    avges->petrol = calloc(10,sizeof(char));
    strcpy(avges->petrol, va_arg(args, char*));

    avges->avgmileage = (double)rand()/RAND_MAX*15 + 5;
    avges->startvalue = rand()%90000 + 10000;
    avges->filledvalue = avges->startvalue + rand()%5000 + 1000;

    va_end(args);
    return avges;
    
}

int main(){
    struct myavges *avges_array[10];

     srand(time(NULL));

    for(int i=0;i<10; i++){
        char brand_name[10];
        sprintf(brand_name,"Brand %d", i+1);
        avges_array[i] = create_random("s",brand_name);
    }

    for(int i=0;i<10;i++){
        printf("Petrol Brand %d: %s\n", i+1, avges_array[i]->petrol);
        printf("Average Mileage %d(km/L): %.2f\n",i+1, avges_array[i]->avgmileage);
        printf("Starting meter reading %d: %d\n",i+1, avges_array[i]->startvalue);
        printf("\n");
    }

    for(int i=0; i<10; i++){
        free(avges_array[i]->petrol);
        free(avges_array[i]);
    }
    return 0;
}