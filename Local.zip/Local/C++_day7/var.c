#include<stdio.h>
#include <stdarg.h>
 
int call_sumfunc_with_unknownparams(int no, ...) {

  va_list va;
  int sum = 0;
  int i;
 
  va_start(va,no);
 
  for (i=0;i<no;i++) {
    sum += va_arg(va, int);
  }
 
  va_end(va);
  return sum;
}
 
 
void main (void) {
    printf("message….\n");
    printf("sum: %d\n", call_sumfunc_with_unknownparams(2,3,4,5,6,7,9));
 
    printf("Sum: %d\n", call_sumfunc_with_unknownparams(2,3,4,5,6,8)); 
 
}
