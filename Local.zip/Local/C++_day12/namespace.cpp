#include <bits/stdc++.h>

namespace sales {
    double cal(double price, int quantity) {
        return price * quantity;
    }
}

namespace salesman {
    double cal(double salary, double commission, double totalSales) {
        return salary + (commission * totalSales);
    }
}

namespace products {
    double cal(double cost, int quantity) {
        return cost * quantity;
    }
}

namespace product_sales {
    double cal(double price, int quantity) {
        return price * quantity;
    }
}

namespace total_turnover {
    double cal(double salesRev, double productRev) {
        return salesRev + productRev;
    }
}

namespace profit {
    double cal(double totalRev, double totalCost) {
        return totalRev - totalCost;
    }
}

using namespace std;
using sales::cal;
using salesman::cal;
using products::cal;
using product_sales::cal;
using total_turnover::cal;
using profit::cal;

int main() {
    double price = 20.0;
    int quantity = 200;
    double salary = 2000.0;
    double commission = 0.1;
    double cost = 5.0;
    double salesRev = 5000.0;
    double productRev = 3000.0;
    double totalCost = 2000.0;

    double totalSales = sales::cal(price, quantity);  
    cout << "Total sales: " << totalSales << endl;

    double totalSalary = salesman::cal(salary, commission, totalSales);  
    cout << "Salesman salary: " << totalSalary << endl;

    double totalProductCost = products::cal(cost, quantity);   
    cout << "Total product cost: " << totalProductCost << endl;

    double totalProductRev = product_sales::cal(price, quantity);  
    cout << "Total product revenue: " << totalProductRev << endl;

    double turnOver = total_turnover::cal(salesRev, productRev);  
    cout << "Total rev and product rev: " << turnOver << endl;

    double profitAmt = profit::cal(turnOver, totalCost);  
    cout << "Profit: " << profitAmt << endl;

    return 0;
}