#include <bits/stdc++.h>
using namespace std;

class Mains {
    public:
        int main(int a) { cout<<a<<endl; return 0; }

        int main(char* a) { cout<<a<<endl; return 0; }

        int main(int a, int b) { cout<<a<<","<<b<<endl; return 0; }
};

int main() {
    Mains main;
    main.main(3);
    main.main("hello");
    main.main(3,6);
}