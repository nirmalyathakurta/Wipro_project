#include <iostream>
using namespace std;

template <typename T> class myarr {
  private :
    T*ptr;
    int size;
  public:
    myarr(T arr[],int size);
    T greatest(T x, T y);
    void showarr();
};

template <typename T> myarr<T>::myarr(T arr[], int size) {
  ptr = new T[size];
  this->size=size;
  int i;
  for(i=0; i<size; i++) ptr[i]=arr[i];
}

template <typename T> void myarr<T>::showarr() {
  int i;
  for(i=0; i<size; i++)  cout<<ptr[i]<<" ";
  cout<<endl;
}

template <typename T> T myarr<T>::greatest(T x, T y) {
  if(ptr[x] > ptr[y]) return ptr[x];
  else return ptr[y];
}

int main() {
  int x[5] = {1,4,5,6,10};
  char c[2] = {'a','b'};
  myarr<int>a(x,5);
  myarr<char>b(c,2);
  a.showarr();
  b.showarr();
  cout<<"Greatest of two numbers is: "<<a.greatest(2,4)<<endl;
  cout<<"Greatest of two characters is: "<<b.greatest(0,1)<<endl;
  return 0;
}