#include <iostream>
#include <list>
using namespace std;
 
int main() {
    list <int> mylist{12,90, 4, 67};
    for (auto i:mylist) {
        cout<< i << “\n”;
    }
    cout<< "Nodein thefront is "<< mylist.front()<<endl;
    cout<< "Node in the nack is" << mylist.back()<<endl;
 
    mylist.push_front(45);
    mylist.push_front(47);
    for(auto i:mylist) {
        cout<<i<<"\n";
    }
    cout<<"\n";
    
    mylist.push_back(4);
    for(auto i:mylist) {
        cout<<i<<"\n";
    }
    cout<<"\n";
    mylist.push_back(56);
    for(auto i:mylist) {
        cout<<i<<"\n";
    }
    cout<<"\n";
    mylist.pop_back();
 
    mylist.pop_front();
    for(auto i:mylist) {
        cout<<i<<"\n";
    }
    cout<<"\n";
 
    mylist.sort();
    for(auto i:mylist) {
        cout<<i<<"\n";
    }
    cout<<"\n";
 
    mylist.reverse();
    for(auto i:mylist) {
        cout<<i<<"\n";
    }
    cout<<"\n";
    return 0;
}