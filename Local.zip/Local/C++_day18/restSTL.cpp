#include <bits/stdc++.h>
using namespace std;

int main() {
  int a[4]= {-1,4,9,6};
  int b[4];
  int c[5] = {0};
  iota(c, c+5, 10);

  for(int i=0; i<5; i++) {
    cout<<c[i]<<endl;
  }

  copy_n(a,4,b);

  for(int i =0; i<4; i++) cout<<" "<<b[i];

    // all_of(a, a+4,[](int x){return x > 0;})?
    // cout<< "Elements all good" : cout<< "We have some bad elements too";

    // any_of(a, a+4,[](int x){return x < 0;})?
    // cout<< "We have some bad elements too " :  cout<< "Elements all good";

    // none_of(a, a+4,[](int x){return x < 0;})?
    // cout<< "We have some bad elements too " :  cout<< "Elements all good";


return 0;

}