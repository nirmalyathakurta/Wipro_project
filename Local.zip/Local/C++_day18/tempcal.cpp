#include <bits/stdc++.h>
using namespace std;

template <typename T> class Calculator {
    public:
        T add(T a, T b) {
            return a+b;
        }
        
        T sub(T a, T b) {
            return a-b;
        }

        T mult(T a, T b) {
            return a*b;
        }

        T div(T a, T b) {
            if(b==0) {
                cout<<"Error dividing by 0"<<endl;
                return 0;
            }
            return a/b;
        }
};

int main() {
    Calculator<int> calc;

    cout<<"Calculator operations for interger: "<<endl;

    cout<<"Addition: "<<calc.add(10,5)<<endl;
    cout<<"Substration: "<<calc.sub(10,5)<<endl;
    cout<<"Multiplication: "<<calc.mult(10,5)<<endl;
    cout<<"Division: "<<calc.div(10,5)<<endl;
    cout<<"Division: "<<calc.div(10,0)<<endl;

    Calculator<double> doublecalc;

    cout<<"Calculator operations for double: "<<endl;

    cout<<"Addition: "<<doublecalc.add(10.2,5.2)<<endl;
    cout<<"Substration: "<<doublecalc.sub(10.2,5.2)<<endl;
    cout<<"Multiplication: "<<doublecalc.mult(10.2,5.2)<<endl;
    cout<<"Division: "<<doublecalc.div(10.2,5.2)<<endl;
    cout<<"Division: "<<doublecalc.div(10.2,0.0)<<endl;

    return 0;
}