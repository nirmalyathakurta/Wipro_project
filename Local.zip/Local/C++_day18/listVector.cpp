
#include<bits/stdc++.h>
using namespace std;

int main() {

    list <vector<int>> lv;  // Linked list of vectors

    vector <int> vect;

    vect.push_back(5);

    vect.push_back(25);

    vect.push_back(8);

    lv.push_back(vect);  // => Add this to the list of vectors


    vector<int> vect2;

    vect2.push_back(35);

    vect2.push_back(895);

    vect2.push_back(876);

    lv.push_back(vect2);



    for (auto v: lv) {

        vector <int>ev =v;

        cout<< "======="<<endl;

        for (auto ve: ev) {

            cout<< ve<< endl;

        }

        cout<< "===== EoV ==="<<endl;

    }

}