#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <pthread.h>
#include <semaphore.h>
#include <time.h>

#define BUFFER_SIZE 10
#define MAX_PROCESSED_DATA 10 // Maximum number of processed data to output

typedef struct raw_device_data {
    float value;
} raw_device_data_t;

typedef struct devdataprocessed {
    time_t timestamp;
    float value;
    struct devdataprocessed* next;
} devdataprocessed_t;

// Buffer for raw data
raw_device_data_t buffer[BUFFER_SIZE];
int in = 0, out = 0; // Indices for buffer

// Head of the linked list
devdataprocessed_t* head = NULL;

// Semaphore to control buffer access
sem_t buffer_sem;

// Semaphore to signal when new data is available
sem_t data_available_sem;

// Semaphore to signal when data has been processed
sem_t data_processed_sem;

// Counter for processed data
int processed_data_count = 0;

// Flag to indicate if processing should stop
int stop_processing = 0;

// Function to read data from a source (replace with your actual reading logic)
raw_device_data_t read_data() {
    // Simulate reading data
    raw_device_data_t data;
    data.value = rand() % 100;  // Generate random value (replace with actual reading)
    return data;
}

// Function to write data to a file (replace with your actual writing logic)
void write_processed_data(devdataprocessed_t* data) {
    FILE* file = fopen("sem.txt", "r+");
    if (file == NULL) {
        perror("fopen");
        return;
    }

    fprintf(file, "%ld, %.2f\n", data->timestamp, data->value);
    fclose(file);
}

// Function to read and write data
void* read_write_data(void* arg) {
    while (!stop_processing) {
        // Generate raw data
        raw_device_data_t data = read_data();

        // Wait until space is available in the buffer
        sem_wait(&buffer_sem);

        // Add data to buffer
        buffer[in] = data;
        in = (in + 1) % BUFFER_SIZE;

        // Signal that new data is available
        sem_post(&data_available_sem);

        // Sleep for a short interval (simulate data generation rate)
        usleep(500000); // 500 ms
    }

    return NULL;
}

// Function to process data
void* process_data(void* arg) {
    while (!stop_processing) {
        // Wait until new data is available
        sem_wait(&data_available_sem);

        // Get data from buffer
        raw_device_data_t data = buffer[out];
        out = (out + 1) % BUFFER_SIZE;

        // Process data (scale by 1000)
        devdataprocessed_t* processed_data = (devdataprocessed_t*)malloc(sizeof(devdataprocessed_t));
        processed_data->timestamp = time(NULL);
        processed_data->value = data.value * 1000;

        // Write processed data to file
        write_processed_data(processed_data);

        // Acquire semaphore to access linked list head
        sem_wait(&data_processed_sem);

        // Add processed data to the beginning of the list
        processed_data->next = head;
        head = processed_data;

        // Release semaphore after adding node to the list
        sem_post(&data_processed_sem);

        // Increment processed data counter
        processed_data_count++;

        // Check if maximum processed data count reached
        if (processed_data_count >= MAX_PROCESSED_DATA) {
            stop_processing = 1;
        }
    }

    return NULL;
}

// Function to build the linked list
void* build_linked_list(void* arg) {
    while (!stop_processing) {
        // Acquire semaphore to access linked list
        sem_wait(&data_processed_sem);

        printf("Linked List Data:\n");
        devdataprocessed_t* current = head;
        while (current != NULL) {
            printf("Time: %ld, Value: %.2f\n", current->timestamp, current->value);
            current = current->next;
        }

        // Release semaphore after accessing linked list
        sem_post(&data_processed_sem);

        // Sleep for a short interval (simulate building linked list rate)
        usleep(200000); // 200 ms
    }

    return NULL;
}

int main() {
    // Initialize random number generator
    srand(time(NULL));

    // Initialize semaphores
    sem_init(&buffer_sem, 0, BUFFER_SIZE);
    sem_init(&data_available_sem, 0, 0);
    sem_init(&data_processed_sem, 0, 1); // Initially available

    // Create threads for reading/writing data, processing data, and building linked list
    pthread_t read_write_thread, process_thread, build_list_thread;
    pthread_create(&read_write_thread, NULL, read_write_data, NULL);
    pthread_create(&process_thread, NULL, process_data, NULL);
    pthread_create(&build_list_thread, NULL, build_linked_list, NULL);

    // Wait for the processing thread to finish
    pthread_join(process_thread, NULL);

    // Clean up: Destroy semaphores
    sem_destroy(&buffer_sem);
    sem_destroy(&data_available_sem);
    sem_destroy(&data_processed_sem);

    // Free memory allocated for processed data
    devdataprocessed_t* current = head;
    while (current != NULL) {
        devdataprocessed_t* temp = current;
        current = current->next;
        free(temp);
    }

    return 0;
}