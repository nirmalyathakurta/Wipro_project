#!/bin/bash

calc_area() {
	length=$1
	width=$2
	
	area=$(( length * width ))
	
	echo " The area of rectangle is: $area"
}

echo "Enter length: "
read x
echo "Enter width: "
read y
calc_area $x $y
