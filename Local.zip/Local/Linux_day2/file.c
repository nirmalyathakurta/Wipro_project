#include <stdio.h>
#include <stdlib.h>
#include <sys/types.h>
#include <dirent.h>
#include <sys/stat.h>
#include <unistd.h>
#include <string.h>
#include <pwd.h>


struct FileNode {
    char *filename;
    long size;             
    long created_date;      
    char permissions[10];   
    char owner[20];         
    struct FileNode *next;  
};


struct FileNode* createNode(char *filename, long size, long created_date, char *permissions, char *owner) {
    
    struct FileNode* newNode = (struct FileNode*)malloc(sizeof(struct FileNode));
    
    newNode->filename = strdup(filename);
    
    newNode->size = size;
    newNode->created_date = created_date;
    strcpy(newNode->permissions, permissions);
    strcpy(newNode->owner, owner);
    
    newNode->next = NULL;
   
    return newNode;
}


void insertNode(struct FileNode **head, char *filename, long size, long created_date, char *permissions, char *owner) {
    
    if (*head == NULL) {
        *head = createNode(filename, size, created_date, permissions, owner);
        return;
    }
    
    struct FileNode *current = *head;
    while (current->next != NULL) {
        current = current->next;
    }
    
    current->next = createNode(filename, size, created_date, permissions, owner);
}


void printList(struct FileNode *head) {
 
    struct FileNode *current = head;
    while (current != NULL) {
        
        printf("File Name: %s, Size: %ld bytes, Created Date: %ld, Permissions: %s, Owner: %s\n", 
                current->filename, current->size, current->created_date, current->permissions, current->owner);
      
        current = current->next;
    }
}

int main() {
    struct dirent *entry;
    DIR *dir = opendir(".");
    
    if (dir == NULL) {
        perror("Error opening directory");
        return 1;
    }
   
    struct FileNode *head = NULL;

   
    while ((entry = readdir(dir)) != NULL) {
        if (entry->d_type == DT_REG) {
            struct stat file_stat;
            char *filename = entry->d_name;
            
            if (stat(filename, &file_stat) == -1) {
                perror("Error getting file stat");
                continue;
            }
            
            char permissions[10];
            sprintf(permissions, "%o", file_stat.st_mode & 0777);
           
            struct passwd *owner_info = getpwuid(file_stat.st_uid);
            char owner[20];
            strcpy(owner, owner_info->pw_name);
            
            insertNode(&head, filename, (long)file_stat.st_size, (long)file_stat.st_ctime, permissions, owner);
        }
    }

    closedir(dir);

    
    printList(head);

    struct FileNode *temp;
    while (head != NULL) {
        temp = head;
        head = head->next;
        free(temp->filename);
        free(temp);
    }

    return 0;
}