#!/bin/bash

echo -n "Enter the name of the file: "
read file_name

permissions=$(stat -c "%A" "$file_name")
numeric_permissions=$(stat -c "%a" "$file_name")
owner=${permissions:1:3}
group=${permissions:4:3}
other=${permissions:7:3}

echo "File permissions: $owner"
echo "Group permissions: $group"
echo "Other permissions: $other"
echo "Numeric permissions: $numeric_permissions"

[ -w "$file_name" ] && W="yes" || W="No"
[ -x "$file_name" ] && X="yes" || X="No"
[ -r "$file_name" ] && R="yes" || R="No"

[ -w "$file_name" ] && [ "${permissions:5:1}" != "-" ] && GW="yes" || GW="no"
[ -x "$file_name" ] && [ "${permissions:6:1}" != "-" ] && GX="yes" || GX="no"
[ -r "$file_name" ] && [ "${permissions:7:1}" != "-" ] && GR="yes" || GR="no"

[ -w "$file_name" ] && [ "${permissions:8:1}" != "-" ] && OW="yes" || OW="no"
[ -x "$file_name" ] && [ "${permissions:9:1}" != "-" ] && OX="yes" || OX="no"
[ -r "$file_name" ] && [ "${permissions:10:1}" != "-" ] && OR="yes" || OR="no"

echo "$file_name permissions"
echo "Owner:"
echo "Write: $W"
echo "Execute: $X"
echo "Read: $R"

echo "Group:"
echo "Write: $GW"
echo "Execute: $GX"
echo "Read: $GR"

echo "Other:"
echo "Write: $OW"
echo "Execute: $OX"
echo "Read: $OR"
