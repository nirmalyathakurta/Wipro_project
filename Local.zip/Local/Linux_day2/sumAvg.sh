#!/bin/bash

# Function to calculate the sum of numbers
calculate_sum() {
    local sum=0
    for num in "$@"; do
        sum=$((sum + num))
    done
    echo $sum
}

# Function to calculate the average of numbers
calculate_average() {
    local sum=$1
    local count=$2
    local average=$((sum / count))
    echo $average
}

# Main program

# Define the numbers
numbers=(5 10 15)

# Calculate the sum
sum=$(calculate_sum "${numbers[@]}")

# Count the number of elements
count=${#numbers[@]}

# Calculate the average
average=$(calculate_average $sum $count)

# Print the sum and average
echo "The sum of the numbers is: $sum"
echo "The average of the numbers is: $average"
