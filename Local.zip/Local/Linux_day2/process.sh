#!/bin/bash


display_process_details() {
    local process_name=$1
    echo "Process details for: $process_name"
    ps -ef | grep "$process_name"
}


echo "Enter the process name: "
read process_name
display_process_details "$process_name"
