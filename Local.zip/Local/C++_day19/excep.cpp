#include <iostream>
#include <stdexcept>

using namespace std;
int main() {
    try {
        intx=5;int y=0;
        if (y==0) {
            throw runtime_error("Divide by zero not allowed");
        }
    }
    cout<< "x/y result is :" << (x/y);
    catch(const exception& ex) {
        cout<< "Exception" << e.what() << endl;
    }
    return 0;
    
}